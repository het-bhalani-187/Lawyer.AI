import React from 'react';
import { Header } from './components/Header';
import { TabNavigation } from './components/TabNavigation';
import { ChatInterface } from './components/ChatInterface';
import { StrategyRoom } from './components/StrategyRoom';
import { FindLawyer } from './components/FindLawyer';
import { LegalAwareness } from './components/LegalAwareness';
import { DocumentAnalysis } from './components/DocumentAnalysis';
import { useTheme } from './hooks/useTheme';
import { useActiveTab } from './hooks/useActiveTab';

function App() {
  const { isDark, toggleTheme } = useTheme();
  const { activeTab, setActiveTab } = useActiveTab();

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'chat':
        return <ChatInterface />;
      case 'strategy':
        return <StrategyRoom />;
      case 'lawyer':
        return <FindLawyer />;
      case 'awareness':
        return <LegalAwareness />;
      case 'documents':
        return <DocumentAnalysis />;
      default:
        return <ChatInterface />;
    }
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDark 
        ? 'bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100' 
        : 'bg-gradient-to-br from-slate-50 via-white to-slate-100 text-slate-900'
    }`}>
      {/* Ambient Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className={`absolute -top-40 -right-40 w-80 h-80 rounded-full opacity-20 blur-3xl ${
          isDark ? 'bg-gold-500' : 'bg-primary-500'
        }`} />
        <div className={`absolute -bottom-40 -left-40 w-80 h-80 rounded-full opacity-20 blur-3xl ${
          isDark ? 'bg-primary-500' : 'bg-gold-500'
        }`} />
      </div>

      <Header isDark={isDark} toggleTheme={toggleTheme} />
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <TabNavigation 
            activeTab={activeTab} 
            setActiveTab={setActiveTab}
            isDark={isDark}
          />
          <main className="pb-16">
            <div className="animate-fade-in">
              {renderActiveComponent()}
            </div>
          </main>
        </div>
      </div>

      {/* Footer */}
      <footer className={`relative z-10 border-t ${
        isDark ? 'border-slate-800 bg-slate-950/50' : 'border-slate-200 bg-white/50'
      } backdrop-blur-xl`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className={`text-sm ${
              isDark ? 'text-slate-400' : 'text-slate-600'
            }`}>
              © 2024 NyayGPT. Empowering justice through artificial intelligence.
            </p>
            <p className={`text-xs mt-2 ${
              isDark ? 'text-slate-500' : 'text-slate-500'
            }`}>
              Built for the Indian legal system with precision and care.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;