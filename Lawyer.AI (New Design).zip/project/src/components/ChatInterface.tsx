import React, { useState } from 'react';
import { Send, Mic, Paperclip, Bot, User, Sparkles, Zap } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

export const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "🎯 Namaste! I'm NyayGPT, your premier legal strategist for Indian jurisprudence. With the precision of a Supreme Court advocate and the accessibility of modern AI, I'm here to navigate the complexities of Indian law with you.\n\nWhether you're facing a legal challenge, seeking strategic counsel, or simply need clarity on your rights, I'm equipped to provide sharp, actionable insights. What legal matter shall we conquer today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate bot response with typing indicator
    setTimeout(() => {
      setIsTyping(false);
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: `⚖️ **Legal Analysis Complete**\n\nI've processed your query with the precision of a seasoned advocate. Here's my strategic assessment:\n\n**🎯 Legal Position:**\nYour matter falls under [relevant provisions of Indian law]. Based on established precedents and current jurisprudence, here's my sharp analysis:\n\n**📋 Immediate Strategic Recommendations:**\n1. **Primary Action:** [Specific legal step with section references]\n2. **Precedent Leverage:** Consider citing landmark cases like [example case name]\n3. **Tactical Advantage:** File under Section [X] for maximum procedural benefit\n\n**⚡ Power Move:**\nThis approach gives you the strongest legal foundation while maintaining strategic flexibility.\n\n**💡 Pro Insight:** The opposing party's likely response and how to counter it effectively.\n\n*Ready to dive deeper into any aspect of this strategy?*`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botResponse]);
    }, 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="elegant-card rounded-3xl overflow-hidden shadow-elegant-xl">
        {/* Chat Header */}
        <div className={`px-8 py-6 bg-gradient-to-r ${
          messages.length > 1 
            ? 'from-primary-600 to-primary-700 dark:from-gold-600 dark:to-gold-700' 
            : 'from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative p-3 bg-white/20 rounded-2xl backdrop-blur-sm">
                <Bot className="w-7 h-7 text-white" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                </div>
              </div>
              <div>
                <h2 className="text-white font-serif font-semibold text-xl">
                  Legal Consultation Chamber
                </h2>
                <p className="text-white/80 text-sm font-medium">
                  Your personal legal strategist is online
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-white/60 animate-pulse" />
              <span className="text-white/80 text-sm font-medium">AI Powered</span>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="h-[500px] overflow-y-auto p-8 space-y-6 bg-gradient-to-b from-slate-50/50 to-white dark:from-slate-900/50 dark:to-slate-950">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex animate-slide-up ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-4 max-w-4xl ${
                message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}>
                <div className={`p-3 rounded-2xl shadow-elegant transition-all duration-300 hover:scale-105 ${
                  message.type === 'user'
                    ? 'bg-gradient-to-br from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600'
                    : 'bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700'
                }`}>
                  {message.type === 'user' ? (
                    <User className="w-6 h-6 text-white" />
                  ) : (
                    <Bot className="w-6 h-6 text-slate-600 dark:text-slate-300" />
                  )}
                </div>
                <div className={`p-6 rounded-3xl shadow-elegant-lg backdrop-blur-sm transition-all duration-300 hover:shadow-elegant-xl ${
                  message.type === 'user'
                    ? 'bg-gradient-to-br from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white'
                    : 'bg-white/80 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 border border-slate-200/50 dark:border-slate-700/50'
                }`}>
                  <div className="prose prose-sm max-w-none">
                    <p className="whitespace-pre-wrap leading-relaxed font-medium">
                      {message.content}
                    </p>
                  </div>
                  <div className={`flex items-center justify-between mt-4 pt-3 border-t ${
                    message.type === 'user'
                      ? 'border-white/20'
                      : 'border-slate-200/50 dark:border-slate-700/50'
                  }`}>
                    <span className={`text-xs font-medium ${
                      message.type === 'user'
                        ? 'text-white/70'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                    {message.type === 'bot' && (
                      <div className="flex items-center space-x-1">
                        <Zap className="w-3 h-3 text-primary-500 dark:text-gold-500" />
                        <span className="text-xs font-medium text-primary-600 dark:text-gold-600">
                          AI Generated
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start animate-slide-up">
              <div className="flex items-start space-x-4 max-w-4xl">
                <div className="p-3 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700 shadow-elegant">
                  <Bot className="w-6 h-6 text-slate-600 dark:text-slate-300" />
                </div>
                <div className="bg-white/80 dark:bg-slate-800/80 p-6 rounded-3xl shadow-elegant-lg backdrop-blur-sm border border-slate-200/50 dark:border-slate-700/50">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                    <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
                      Analyzing your legal query...
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t border-slate-200/50 dark:border-slate-700/50 p-6 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl">
          <div className="flex items-end space-x-4">
            <button className="elegant-button p-4 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition-all duration-300 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800">
              <Paperclip className="w-5 h-5" />
            </button>
            
            <div className="flex-1 relative">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Describe your legal situation or ask any question about Indian law..."
                className="w-full px-6 py-4 border border-slate-300/50 dark:border-slate-600/50 rounded-2xl bg-white/80 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 placeholder-slate-500 dark:placeholder-slate-400 focus:ring-2 focus:ring-primary-500 dark:focus:ring-gold-500 focus:border-transparent resize-none backdrop-blur-sm shadow-elegant transition-all duration-300 font-medium"
                rows={1}
                style={{ minHeight: '56px', maxHeight: '120px' }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = '56px';
                  target.style.height = target.scrollHeight + 'px';
                }}
              />
            </div>

            <button
              onClick={toggleRecording}
              className={`elegant-button p-4 rounded-2xl transition-all duration-300 ${
                isRecording
                  ? 'bg-red-500 text-white shadow-elegant-lg shadow-red-500/25 scale-110'
                  : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Mic className="w-5 h-5" />
            </button>

            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isTyping}
              className="elegant-button p-4 bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white rounded-2xl hover:from-primary-600 hover:to-primary-700 dark:hover:from-gold-600 dark:hover:to-gold-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-elegant-lg transition-all duration-300 disabled:hover:scale-100"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};