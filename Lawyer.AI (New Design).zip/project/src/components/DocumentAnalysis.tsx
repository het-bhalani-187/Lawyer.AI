import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, XCircle, AlertTriangle, Download, Eye, Zap, Crown, Shield } from 'lucide-react';

interface AnalysisResult {
  id: string;
  fileName: string;
  fileType: string;
  status: 'analyzing' | 'completed' | 'error';
  uploadDate: string;
  summary: string;
  keyFindings: string[];
  riskLevel: 'low' | 'medium' | 'high';
  recommendations: string[];
  confidenceScore: number;
}

export const DocumentAnalysis: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>([
    {
      id: '1',
      fileName: 'employment-contract.pdf',
      fileType: 'Employment Contract',
      status: 'completed',
      uploadDate: '2024-01-15',
      summary: 'Comprehensive employment agreement with several non-standard clauses requiring strategic attention and negotiation.',
      keyFindings: [
        'Non-compete clause extends beyond legal limits (18 months vs. standard 6 months)',
        'Overtime compensation structure lacks clarity and specificity',
        'Notice period exceeds industry standard (3 months vs. 1 month)',
        'Intellectual property rights are clearly defined and comprehensive',
        'Termination clauses favor employer disproportionately'
      ],
      riskLevel: 'medium',
      recommendations: [
        'Negotiate reduction of non-compete period to 6 months maximum',
        'Request detailed clarification on overtime payment structure',
        'Propose 1-month notice period with mutual agreement clause',
        'Add employee protection clauses for wrongful termination'
      ],
      confidenceScore: 94
    },
    {
      id: '2',
      fileName: 'property-deed.pdf',
      fileType: 'Property Document',
      status: 'completed',
      uploadDate: '2024-01-12',
      summary: 'Property sale deed appears legally sound with minor documentation gaps that should be addressed before transaction.',
      keyFindings: [
        'Clear title verification completed successfully',
        'Property taxes are current and up to date',
        'Missing recent encumbrance certificate (critical)',
        'Survey settlement details are accurate and verified',
        'No pending litigation or disputes found'
      ],
      riskLevel: 'low',
      recommendations: [
        'Obtain encumbrance certificate for last 30 years before transaction',
        'Verify property boundaries with recent survey documentation',
        'Ensure all stamp duty payments are completed as per state regulations',
        'Consider title insurance for additional protection'
      ],
      confidenceScore: 97
    }
  ]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const newAnalysis: AnalysisResult = {
        id: Date.now().toString(),
        fileName: file.name,
        fileType: 'Legal Document',
        status: 'analyzing',
        uploadDate: new Date().toISOString().split('T')[0],
        summary: '',
        keyFindings: [],
        riskLevel: 'low',
        recommendations: [],
        confidenceScore: 0
      };
      
      setAnalysisResults(prev => [newAnalysis, ...prev]);
      
      setTimeout(() => {
        setAnalysisResults(prev => prev.map(result => 
          result.id === newAnalysis.id 
            ? {
                ...result,
                status: 'completed',
                summary: 'AI-powered document analysis completed successfully. Comprehensive legal review with strategic recommendations provided.',
                keyFindings: [
                  'Document structure and format verified',
                  'Legal compliance assessment completed',
                  'Risk factors identified and categorized',
                  'Strategic opportunities highlighted'
                ],
                recommendations: [
                  'Review highlighted sections with legal counsel',
                  'Consider strategic amendments for better protection',
                  'Implement recommended safeguards before execution'
                ],
                confidenceScore: 92
              }
            : result
        ));
      }, 3500);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'high': return 'text-red-600 dark:text-red-400 bg-gradient-to-r from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 border-red-200 dark:border-red-800';
      case 'medium': return 'text-amber-600 dark:text-amber-400 bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 border-amber-200 dark:border-amber-800';
      case 'low': return 'text-emerald-600 dark:text-emerald-400 bg-gradient-to-r from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/20 border-emerald-200 dark:border-emerald-800';
      default: return 'text-slate-600 dark:text-slate-400 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-900/20 dark:to-slate-800/20 border-slate-200 dark:border-slate-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-6 h-6 text-emerald-500" />;
      case 'error': return <XCircle className="w-6 h-6 text-red-500" />;
      case 'analyzing': return <div className="w-6 h-6 border-2 border-primary-500 dark:border-gold-500 border-t-transparent rounded-full animate-spin" />;
      default: return <FileText className="w-6 h-6 text-slate-400" />;
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 95) return 'text-emerald-600 dark:text-emerald-400';
    if (score >= 85) return 'text-primary-600 dark:text-gold-400';
    if (score >= 75) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center space-x-4 mb-4">
          <div className="p-3 bg-gradient-to-br from-primary-500/20 to-primary-600/20 dark:from-gold-500/20 dark:to-gold-600/20 rounded-2xl">
            <Shield className="w-8 h-8 text-primary-600 dark:text-gold-500" />
          </div>
          <div>
            <h1 className="text-4xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-2">
              AI Document Intelligence
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 font-medium">
              Advanced legal document analysis powered by artificial intelligence
            </p>
          </div>
        </div>
      </div>

      {/* Upload Area */}
      <div className="mb-10">
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`elegant-card border-2 border-dashed rounded-3xl p-16 text-center transition-all duration-300 cursor-pointer hover:scale-[1.01] ${
            dragActive
              ? 'border-primary-500 dark:border-gold-500 bg-gradient-to-br from-primary-50 to-primary-100 dark:from-gold-900/10 dark:to-gold-800/10 shadow-elegant-xl'
              : 'border-slate-300 dark:border-slate-600 hover:border-slate-400 dark:hover:border-slate-500'
          }`}
        >
          <div className={`transition-all duration-300 ${dragActive ? 'scale-110' : ''}`}>
            <Upload className={`w-16 h-16 mx-auto mb-6 ${
              dragActive ? 'text-primary-500 dark:text-gold-500' : 'text-slate-400 dark:text-slate-600'
            }`} />
            <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-3">
              Drop Your Legal Documents Here
            </h3>
            <p className="text-slate-600 dark:text-slate-400 mb-6 text-lg leading-relaxed max-w-md mx-auto">
              Upload contracts, agreements, legal notices, or any legal document for comprehensive AI-powered analysis
            </p>
            <div className="space-y-3">
              <button className="elegant-button bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white px-8 py-4 rounded-2xl hover:from-primary-600 hover:to-primary-700 dark:hover:from-gold-600 dark:hover:to-gold-700 shadow-elegant-lg font-semibold text-lg">
                Browse Files
              </button>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Supports PDF, DOC, DOCX • Maximum 10MB
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Analysis Results */}
      <div className="space-y-8">
        {analysisResults.map((result) => (
          <div key={result.id} className="elegant-card rounded-3xl overflow-hidden shadow-elegant-xl">
            {/* Header */}
            <div className="p-8 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 border-b border-slate-200/50 dark:border-slate-700/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(result.status)}
                  <div>
                    <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-slate-100">
                      {result.fileName}
                    </h3>
                    <div className="flex items-center space-x-4 text-slate-600 dark:text-slate-400 mt-1">
                      <span className="font-medium">{result.fileType}</span>
                      <span>•</span>
                      <span>Uploaded {new Date(result.uploadDate).toLocaleDateString('en-IN')}</span>
                      {result.status === 'completed' && (
                        <>
                          <span>•</span>
                          <div className="flex items-center space-x-1">
                            <Zap className="w-4 h-4 text-primary-500 dark:text-gold-500" />
                            <span className={`font-semibold ${getConfidenceColor(result.confidenceScore)}`}>
                              {result.confidenceScore}% Confidence
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {result.status === 'completed' && (
                    <span className={`px-4 py-2 rounded-xl text-sm font-bold border shadow-elegant ${getRiskColor(result.riskLevel)}`}>
                      {result.riskLevel.toUpperCase()} RISK
                    </span>
                  )}
                  <button className="elegant-button p-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Eye className="w-5 h-5" />
                  </button>
                  <button className="elegant-button p-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Download className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Content */}
            {result.status === 'completed' && (
              <div className="p-8 space-y-8">
                {/* Summary */}
                <div className="bg-gradient-to-br from-primary-50 to-primary-100 dark:from-primary-900/20 dark:to-primary-800/20 p-6 rounded-2xl border border-primary-200/50 dark:border-primary-700/50">
                  <h4 className="text-xl font-serif font-bold text-primary-900 dark:text-primary-300 mb-3 flex items-center">
                    <Crown className="w-6 h-6 mr-2" />
                    Executive Analysis Summary
                  </h4>
                  <p className="text-primary-800 dark:text-primary-400 leading-relaxed font-medium text-lg">
                    {result.summary}
                  </p>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                  {/* Key Findings */}
                  <div className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 p-6 rounded-2xl border border-amber-200/50 dark:border-amber-700/50">
                    <h4 className="text-xl font-serif font-bold text-amber-900 dark:text-amber-300 mb-4 flex items-center">
                      <AlertTriangle className="w-6 h-6 mr-2" />
                      Critical Findings
                    </h4>
                    <ul className="space-y-3">
                      {result.keyFindings.map((finding, index) => (
                        <li key={index} className="flex items-start">
                          <div className="w-2 h-2 bg-amber-500 rounded-full mt-2 mr-4 flex-shrink-0" />
                          <span className="text-amber-800 dark:text-amber-400 font-medium leading-relaxed">{finding}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Recommendations */}
                  <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/20 p-6 rounded-2xl border border-emerald-200/50 dark:border-emerald-700/50">
                    <h4 className="text-xl font-serif font-bold text-emerald-900 dark:text-emerald-300 mb-4 flex items-center">
                      <CheckCircle className="w-6 h-6 mr-2" />
                      Strategic Recommendations
                    </h4>
                    <ul className="space-y-3">
                      {result.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start">
                          <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-4 flex-shrink-0" />
                          <span className="text-emerald-800 dark:text-emerald-400 font-medium leading-relaxed">{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-6 border-t border-slate-200/50 dark:border-slate-700/50 flex flex-wrap gap-4">
                  <button className="elegant-button bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white px-6 py-3 rounded-xl hover:from-primary-600 hover:to-primary-700 dark:hover:from-gold-600 dark:hover:to-gold-700 shadow-elegant-lg font-semibold">
                    Consult Expert Lawyer
                  </button>
                  <button className="elegant-button border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 px-6 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 shadow-elegant font-semibold">
                    Download Full Report
                  </button>
                  <button className="elegant-button border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 px-6 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 shadow-elegant font-semibold">
                    Share Analysis
                  </button>
                </div>
              </div>
            )}

            {/* Loading State */}
            {result.status === 'analyzing' && (
              <div className="p-16 text-center">
                <div className="mb-6">
                  <div className="w-16 h-16 border-4 border-primary-500 dark:border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-6" />
                  <h4 className="text-2xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-3">
                    AI Analysis in Progress...
                  </h4>
                  <p className="text-slate-600 dark:text-slate-400 text-lg max-w-md mx-auto leading-relaxed">
                    Our advanced AI is conducting a comprehensive legal review of your document, analyzing compliance, risks, and strategic opportunities.
                  </p>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-slate-500 dark:text-slate-400">
                  <Zap className="w-4 h-4" />
                  <span>Powered by legal AI intelligence</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {analysisResults.length === 0 && (
        <div className="text-center py-16">
          <FileText className="w-20 h-20 text-slate-400 dark:text-slate-600 mx-auto mb-6" />
          <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-3">
            No Documents Analyzed Yet
          </h3>
          <p className="text-slate-600 dark:text-slate-400 text-lg max-w-md mx-auto leading-relaxed">
            Upload your first legal document to experience the power of AI-driven legal analysis and strategic insights.
          </p>
        </div>
      )}
    </div>
  );
};