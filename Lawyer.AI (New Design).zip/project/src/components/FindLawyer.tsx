import React, { useState } from 'react';
import { Search, Star, MapPin, Award, Phone, Mail, Filter, Crown, Zap, Shield } from 'lucide-react';

interface Lawyer {
  id: string;
  name: string;
  specialization: string[];
  experience: number;
  rating: number;
  location: string;
  court: string;
  cases_won: number;
  phone: string;
  email: string;
  image: string;
  notable_cases: string[];
  fees_range: string;
  tier: 'elite' | 'senior' | 'experienced';
}

export const FindLawyer: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('all');
  const [selectedLawyer, setSelectedLawyer] = useState<Lawyer | null>(null);

  const lawyers: Lawyer[] = [
    {
      id: '1',
      name: 'Adv. Priya Sharma',
      specialization: ['Criminal Law', 'Corporate Crime', 'White Collar Crime'],
      experience: 15,
      rating: 4.9,
      location: 'Delhi High Court',
      court: 'Supreme Court of India',
      cases_won: 342,
      phone: '+91 98765 43210',
      email: 'priya.sharma@lawfirm.com',
      image: 'https://images.pexels.com/photos/5668882/pexels-photo-5668882.jpeg?auto=compress&cs=tinysrgb&w=300',
      notable_cases: ['State v. XYZ Corp (2023)', 'Economic Offences Tribunal Case #245'],
      fees_range: '₹50,000 - ₹2,00,000',
      tier: 'elite'
    },
    {
      id: '2',
      name: 'Adv. Rajesh Kumar',
      specialization: ['Civil Law', 'Property Disputes', 'Family Law'],
      experience: 22,
      rating: 4.7,
      location: 'Mumbai High Court',
      court: 'Bombay High Court',
      cases_won: 578,
      phone: '+91 99887 76543',
      email: 'rajesh.kumar@advocates.in',
      image: 'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=300',
      notable_cases: ['Landmark Property Rights Case (2022)', 'Family Court Appeals #156-2023'],
      fees_range: '₹25,000 - ₹1,50,000',
      tier: 'senior'
    },
    {
      id: '3',
      name: 'Adv. Meera Patel',
      specialization: ['Labor Law', 'Employment Disputes', 'Industrial Law'],
      experience: 12,
      rating: 4.8,
      location: 'Gujarat High Court',
      court: 'Labor Tribunal',
      cases_won: 234,
      phone: '+91 97654 32109',
      email: 'meera.patel@laborlaw.co.in',
      image: 'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=300',
      notable_cases: ['Industrial Disputes Act Case #445', 'Worker Rights Landmark Judgment'],
      fees_range: '₹15,000 - ₹75,000',
      tier: 'experienced'
    }
  ];

  const specializations = ['all', 'Criminal Law', 'Civil Law', 'Corporate Law', 'Labor Law', 'Family Law', 'Property Law'];

  const filteredLawyers = lawyers.filter(lawyer => {
    const matchesSearch = lawyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lawyer.specialization.some(spec => spec.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSpecialization = selectedSpecialization === 'all' || 
                                 lawyer.specialization.includes(selectedSpecialization);
    return matchesSearch && matchesSpecialization;
  });

  const getTierBadge = (tier: string) => {
    switch (tier) {
      case 'elite':
        return {
          icon: Crown,
          text: 'Elite Counsel',
          className: 'bg-gradient-to-r from-gold-500 to-gold-600 text-white'
        };
      case 'senior':
        return {
          icon: Shield,
          text: 'Senior Advocate',
          className: 'bg-gradient-to-r from-primary-500 to-primary-600 text-white'
        };
      case 'experienced':
        return {
          icon: Zap,
          text: 'Experienced',
          className: 'bg-gradient-to-r from-emerald-500 to-emerald-600 text-white'
        };
      default:
        return {
          icon: Award,
          text: 'Advocate',
          className: 'bg-gradient-to-r from-slate-500 to-slate-600 text-white'
        };
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center space-x-4 mb-4">
          <div className="p-3 bg-gradient-to-br from-primary-500/20 to-primary-600/20 dark:from-gold-500/20 dark:to-gold-600/20 rounded-2xl">
            <Crown className="w-8 h-8 text-primary-600 dark:text-gold-500" />
          </div>
          <div>
            <h1 className="text-4xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-2">
              Elite Legal Counsel Network
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 font-medium">
              Connect with India's most distinguished legal professionals
            </p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="mb-8">
        <div className="elegant-card p-8 rounded-3xl shadow-elegant-xl">
          <div className="flex flex-col lg:flex-row gap-6">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-6 h-6" />
              <input
                type="text"
                placeholder="Search by advocate name, specialization, or court..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-6 py-4 border border-slate-300/50 dark:border-slate-600/50 rounded-2xl bg-white/80 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-primary-500 dark:focus:ring-gold-500 focus:border-transparent backdrop-blur-sm shadow-elegant transition-all duration-300 text-lg font-medium"
              />
            </div>
            <div className="flex items-center space-x-3">
              <Filter className="text-slate-400 w-6 h-6" />
              <select
                value={selectedSpecialization}
                onChange={(e) => setSelectedSpecialization(e.target.value)}
                className="px-6 py-4 border border-slate-300/50 dark:border-slate-600/50 rounded-2xl bg-white/80 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-primary-500 dark:focus:ring-gold-500 focus:border-transparent backdrop-blur-sm shadow-elegant transition-all duration-300 font-medium"
              >
                {specializations.map(spec => (
                  <option key={spec} value={spec}>
                    {spec === 'all' ? 'All Specializations' : spec}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Lawyer Directory */}
        <div className="xl:col-span-2 space-y-6">
          {filteredLawyers.map((lawyer) => {
            const tierBadge = getTierBadge(lawyer.tier);
            const TierIcon = tierBadge.icon;
            
            return (
              <div
                key={lawyer.id}
                onClick={() => setSelectedLawyer(lawyer)}
                className="elegant-card p-8 rounded-3xl shadow-elegant-lg hover:shadow-elegant-xl transition-all duration-300 cursor-pointer group hover:scale-[1.02]"
              >
                <div className="flex items-start space-x-6">
                  <div className="relative">
                    <img
                      src={lawyer.image}
                      alt={lawyer.name}
                      className="w-24 h-24 rounded-2xl object-cover shadow-elegant transition-all duration-300 group-hover:scale-105"
                    />
                    <div className={`absolute -top-2 -right-2 p-2 rounded-xl shadow-elegant ${tierBadge.className}`}>
                      <TierIcon className="w-4 h-4" />
                    </div>
                  </div>
                  
                  <div className="flex-1 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-2">
                          {lawyer.name}
                        </h3>
                        <div className="flex items-center space-x-4 mb-3">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-5 h-5 ${
                                  i < Math.floor(lawyer.rating)
                                    ? 'text-gold-400 fill-current'
                                    : 'text-slate-300 dark:text-slate-600'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-slate-600 dark:text-slate-400 font-medium">
                            {lawyer.rating} • {lawyer.cases_won} cases won
                          </span>
                        </div>
                      </div>
                      <div className={`px-4 py-2 rounded-xl shadow-elegant ${tierBadge.className}`}>
                        <div className="flex items-center space-x-2">
                          <TierIcon className="w-4 h-4" />
                          <span className="text-sm font-bold">{tierBadge.text}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center text-slate-600 dark:text-slate-400 space-x-4">
                      <div className="flex items-center">
                        <MapPin className="w-5 h-5 mr-2" />
                        <span className="font-medium">{lawyer.location}</span>
                      </div>
                      <span>•</span>
                      <span className="font-medium">{lawyer.court}</span>
                      <span>•</span>
                      <span className="font-medium">{lawyer.experience} years experience</span>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {lawyer.specialization.map((spec, index) => (
                        <span
                          key={index}
                          className="bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-600 text-slate-700 dark:text-slate-300 px-4 py-2 rounded-xl text-sm font-medium shadow-elegant"
                        >
                          {spec}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-200/50 dark:border-slate-700/50">
                      <div className="text-slate-600 dark:text-slate-400">
                        <span className="text-sm">Consultation Fees: </span>
                        <span className="font-bold text-lg text-slate-900 dark:text-slate-100">{lawyer.fees_range}</span>
                      </div>
                      <button className="elegant-button bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white px-6 py-3 rounded-xl hover:from-primary-600 hover:to-primary-700 dark:hover:from-gold-600 dark:hover:to-gold-700 shadow-elegant-lg font-semibold">
                        View Profile
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Lawyer Profile Panel */}
        <div className="xl:col-span-1">
          <div className="elegant-card rounded-3xl shadow-elegant-xl sticky top-24 overflow-hidden">
            {selectedLawyer ? (
              <div>
                {/* Profile Header */}
                <div className="p-8 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 border-b border-slate-200/50 dark:border-slate-700/50">
                  <div className="text-center">
                    <div className="relative inline-block mb-4">
                      <img
                        src={selectedLawyer.image}
                        alt={selectedLawyer.name}
                        className="w-28 h-28 rounded-3xl mx-auto object-cover shadow-elegant-lg"
                      />
                      <div className={`absolute -top-2 -right-2 p-2 rounded-xl shadow-elegant ${getTierBadge(selectedLawyer.tier).className}`}>
                        {React.createElement(getTierBadge(selectedLawyer.tier).icon, { className: "w-5 h-5" })}
                      </div>
                    </div>
                    <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-1">
                      {selectedLawyer.name}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 font-medium">
                      {selectedLawyer.specialization[0]}
                    </p>
                  </div>
                </div>

                {/* Profile Details */}
                <div className="p-8 space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: 'Experience', value: `${selectedLawyer.experience} years` },
                      { label: 'Cases Won', value: selectedLawyer.cases_won.toString() },
                      { label: 'Rating', value: `${selectedLawyer.rating}/5.0` },
                      { label: 'Court', value: selectedLawyer.court.split(' ')[0] },
                    ].map((item, index) => (
                      <div key={index} className="text-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl">
                        <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">{item.value}</div>
                        <div className="text-sm text-slate-600 dark:text-slate-400 font-medium">{item.label}</div>
                      </div>
                    ))}
                  </div>

                  <div>
                    <h4 className="font-serif font-bold text-lg text-slate-900 dark:text-slate-100 mb-4 flex items-center">
                      <Award className="w-5 h-5 mr-2 text-gold-500" />
                      Notable Cases
                    </h4>
                    <ul className="space-y-3">
                      {selectedLawyer.notable_cases.map((case_, index) => (
                        <li key={index} className="flex items-start text-sm">
                          <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                          <span className="text-slate-700 dark:text-slate-300 font-medium leading-relaxed">{case_}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-3">
                    <button className="elegant-button w-full bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white py-4 rounded-2xl hover:from-primary-600 hover:to-primary-700 dark:hover:from-gold-600 dark:hover:to-gold-700 shadow-elegant-lg font-semibold flex items-center justify-center">
                      <Phone className="w-5 h-5 mr-2" />
                      Schedule Consultation
                    </button>
                    <button className="elegant-button w-full border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 py-4 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 shadow-elegant font-semibold flex items-center justify-center">
                      <Mail className="w-5 h-5 mr-2" />
                      Send Inquiry
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-12 text-center">
                <Crown className="w-20 h-20 text-slate-400 dark:text-slate-600 mx-auto mb-6" />
                <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-3">
                  Select an Advocate
                </h3>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  Choose any advocate from the directory to view their detailed profile, expertise, and contact information.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};