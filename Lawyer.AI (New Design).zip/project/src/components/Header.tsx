import React from 'react';
import { Scale, Moon, Sun, Shield, Sparkles } from 'lucide-react';

interface HeaderProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({ isDark, toggleTheme }) => {
  return (
    <header className={`sticky top-0 z-50 transition-all duration-500 ${
      isDark 
        ? 'bg-slate-950/80 border-slate-800/50' 
        : 'bg-white/80 border-slate-200/50'
    } border-b backdrop-blur-2xl`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo Section */}
          <div className="flex items-center space-x-4">
            <div className={`relative p-3 rounded-2xl transition-all duration-300 ${
              isDark 
                ? 'bg-gradient-to-br from-gold-500/20 to-gold-600/20 shadow-gold-500/10' 
                : 'bg-gradient-to-br from-primary-500/20 to-primary-600/20 shadow-primary-500/10'
            } shadow-elegant-lg group hover:scale-105`}>
              <Scale className={`w-7 h-7 transition-all duration-300 ${
                isDark ? 'text-gold-400' : 'text-primary-600'
              } group-hover:rotate-12`} />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            <div className="space-y-1">
              <h1 className={`text-2xl font-serif font-bold tracking-tight transition-colors duration-300 ${
                isDark ? 'text-gold-400' : 'text-primary-900'
              }`}>
                NyayGPT
              </h1>
              <p className={`text-sm font-medium tracking-wide ${
                isDark ? 'text-slate-400' : 'text-slate-600'
              }`}>
                Premier Legal Intelligence
              </p>
            </div>
          </div>

          {/* Status & Controls */}
          <div className="flex items-center space-x-6">
            {/* Jurisdiction Badge */}
            <div className={`hidden md:flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-300 ${
              isDark 
                ? 'bg-emerald-500/10 border border-emerald-500/20' 
                : 'bg-emerald-50 border border-emerald-200'
            }`}>
              <Shield className={`w-4 h-4 ${
                isDark ? 'text-emerald-400' : 'text-emerald-600'
              }`} />
              <span className={`text-sm font-medium ${
                isDark ? 'text-emerald-400' : 'text-emerald-700'
              }`}>
                Indian Jurisdiction
              </span>
              <Sparkles className={`w-3 h-3 ${
                isDark ? 'text-emerald-400' : 'text-emerald-600'
              } animate-pulse`} />
            </div>
            
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className={`elegant-button p-3 rounded-xl transition-all duration-300 ${
                isDark 
                  ? 'bg-slate-800/50 hover:bg-slate-700/50 text-gold-400 shadow-slate-900/20' 
                  : 'bg-slate-100/50 hover:bg-slate-200/50 text-primary-600 shadow-slate-200/20'
              } shadow-elegant border border-slate-200/20 dark:border-slate-700/20 hover:scale-105 active:scale-95`}
              aria-label="Toggle theme"
            >
              {isDark ? (
                <Sun className="w-5 h-5 transition-transform duration-300 hover:rotate-180" />
              ) : (
                <Moon className="w-5 h-5 transition-transform duration-300 hover:-rotate-12" />
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};