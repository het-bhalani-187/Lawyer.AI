import React, { useState } from 'react';
import { BookOpen, Clock, User, ChevronRight, Search, Filter, Sparkles, Crown } from 'lucide-react';

interface Article {
  id: string;
  title: string;
  category: string;
  readTime: number;
  author: string;
  excerpt: string;
  content: string;
  publishDate: string;
  image: string;
  featured: boolean;
}

export const LegalAwareness: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const articles: Article[] = [
    {
      id: '1',
      title: 'Understanding Your Rights Under Consumer Protection Act 2019',
      category: 'Consumer Rights',
      readTime: 8,
      author: 'Legal Team',
      excerpt: 'A comprehensive guide to the revolutionary consumer protection laws and how they empower ordinary citizens in their daily transactions.',
      content: 'The Consumer Protection Act 2019 has revolutionized consumer rights in India...',
      publishDate: '2024-01-15',
      image: 'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=600',
      featured: true
    },
    {
      id: '2',
      title: 'Digital Privacy Laws: What Every Indian Should Know',
      category: 'Privacy Rights',
      readTime: 12,
      author: 'Cyber Law Expert',
      excerpt: 'Navigate the complex world of digital privacy with this essential guide to your rights and responsibilities in the digital age.',
      content: 'In the digital age, understanding your privacy rights is crucial...',
      publishDate: '2024-01-10',
      image: 'https://images.pexels.com/photos/5668882/pexels-photo-5668882.jpeg?auto=compress&cs=tinysrgb&w=600',
      featured: false
    },
    {
      id: '3',
      title: 'Employment Law Essentials: Rights of Workers in India',
      category: 'Labor Rights',
      readTime: 10,
      author: 'Labor Law Specialist',
      excerpt: 'Essential knowledge about employment contracts, workplace harassment, and comprehensive worker protection laws.',
      content: 'Every employee in India has fundamental rights that are protected by law...',
      publishDate: '2024-01-05',
      image: 'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=600',
      featured: true
    }
  ];

  const categories = ['all', 'Consumer Rights', 'Privacy Rights', 'Labor Rights', 'Property Rights', 'Family Law'];

  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (selectedArticle) {
    return (
      <div className="max-w-5xl mx-auto">
        <button
          onClick={() => setSelectedArticle(null)}
          className="mb-8 flex items-center text-primary-600 dark:text-gold-400 hover:text-primary-700 dark:hover:text-gold-300 transition-colors font-semibold group"
        >
          <ChevronRight className="w-5 h-5 mr-2 rotate-180 group-hover:-translate-x-1 transition-transform" />
          Back to Legal Insights
        </button>

        <article className="elegant-card rounded-3xl overflow-hidden shadow-elegant-xl">
          <div className="relative">
            <img
              src={selectedArticle.image}
              alt={selectedArticle.title}
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <div className="flex items-center space-x-4 mb-4">
                <span className="bg-primary-500 dark:bg-gold-500 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-elegant">
                  {selectedArticle.category}
                </span>
                {selectedArticle.featured && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-sm px-3 py-2 rounded-xl">
                    <Crown className="w-4 h-4 text-gold-400" />
                    <span className="text-white text-sm font-semibold">Featured</span>
                  </div>
                )}
              </div>
              <h1 className="text-4xl font-serif font-bold text-white mb-4 leading-tight">
                {selectedArticle.title}
              </h1>
            </div>
          </div>
          
          <div className="p-10">
            <div className="flex items-center space-x-6 mb-8 pb-6 border-b border-slate-200/50 dark:border-slate-700/50">
              <div className="flex items-center text-slate-600 dark:text-slate-400">
                <Clock className="w-5 h-5 mr-2" />
                <span className="font-medium">{selectedArticle.readTime} min read</span>
              </div>
              <div className="flex items-center text-slate-600 dark:text-slate-400">
                <User className="w-5 h-5 mr-2" />
                <span className="font-medium">{selectedArticle.author}</span>
              </div>
              <div className="text-slate-500 dark:text-slate-400 font-medium">
                {new Date(selectedArticle.publishDate).toLocaleDateString('en-IN', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            </div>

            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 leading-relaxed font-medium">
                {selectedArticle.excerpt}
              </p>
              
              <div className="text-slate-700 dark:text-slate-300 leading-relaxed space-y-6">
                <h2 className="text-3xl font-serif font-bold mb-6">Introduction</h2>
                <p className="text-lg leading-relaxed">
                  The Consumer Protection Act 2019 has revolutionized consumer rights in India, providing stronger protection and easier redressal mechanisms for consumers across the country. This comprehensive legislation replaces the earlier Consumer Protection Act of 1986 and introduces several groundbreaking features that empower every citizen.
                </p>

                <h2 className="text-3xl font-serif font-bold mb-6 mt-10">Key Revolutionary Features</h2>
                <ul className="space-y-4 text-lg">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full mt-3 mr-4 flex-shrink-0" />
                    <span>Expanded definition of consumer to include online and offline transactions</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full mt-3 mr-4 flex-shrink-0" />
                    <span>Introduction of Central Consumer Protection Authority (CCPA)</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full mt-3 mr-4 flex-shrink-0" />
                    <span>Enhanced penalties for violations with stricter enforcement</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full mt-3 mr-4 flex-shrink-0" />
                    <span>Simplified dispute resolution process with digital integration</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-primary-500 dark:bg-gold-500 rounded-full mt-3 mr-4 flex-shrink-0" />
                    <span>Comprehensive protection against misleading advertisements</span>
                  </li>
                </ul>

                <h2 className="text-3xl font-serif font-bold mb-6 mt-10">How This Empowers You</h2>
                <p className="text-lg leading-relaxed">
                  As a consumer, you now have unprecedented legal protection when purchasing goods or services. The Act covers everything from defective products to deficient services, and provides multiple forums for seeking redressal based on the value of your claim. This means faster justice and stronger consumer rights than ever before.
                </p>

                <div className="bg-gradient-to-br from-primary-50 to-primary-100 dark:from-primary-900/20 dark:to-primary-800/20 p-8 rounded-2xl my-8 border border-primary-200/50 dark:border-primary-700/50">
                  <div className="flex items-start space-x-4">
                    <Sparkles className="w-6 h-6 text-primary-600 dark:text-primary-400 mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-serif font-bold text-xl text-primary-900 dark:text-primary-300 mb-3">💡 Expert Pro Tip</h3>
                      <p className="text-primary-800 dark:text-primary-400 text-lg leading-relaxed">
                        Always maintain comprehensive records of your purchases including receipts, warranty cards, and digital transaction records. These serve as crucial evidence in consumer disputes and can significantly strengthen your case, often leading to faster resolution and better compensation.
                      </p>
                    </div>
                  </div>
                </div>

                <h2 className="text-3xl font-serif font-bold mb-6 mt-10">Conclusion</h2>
                <p className="text-lg leading-relaxed">
                  Understanding your consumer rights empowers you to make informed decisions and seek appropriate remedies when things go wrong. The new Act provides a robust framework for consumer protection in the digital age, ensuring that your rights are protected whether you're shopping online or offline.
                </p>
              </div>
            </div>
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center space-x-4 mb-4">
          <div className="p-3 bg-gradient-to-br from-primary-500/20 to-primary-600/20 dark:from-gold-500/20 dark:to-gold-600/20 rounded-2xl">
            <BookOpen className="w-8 h-8 text-primary-600 dark:text-gold-500" />
          </div>
          <div>
            <h1 className="text-4xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-2">
              Legal Insights Hub
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 font-medium">
              Empower yourself with comprehensive knowledge about your legal rights and responsibilities
            </p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="mb-8">
        <div className="elegant-card p-8 rounded-3xl shadow-elegant-xl">
          <div className="flex flex-col lg:flex-row gap-6">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-6 h-6" />
              <input
                type="text"
                placeholder="Search legal insights and articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-6 py-4 border border-slate-300/50 dark:border-slate-600/50 rounded-2xl bg-white/80 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-primary-500 dark:focus:ring-gold-500 focus:border-transparent backdrop-blur-sm shadow-elegant transition-all duration-300 text-lg font-medium"
              />
            </div>
            <div className="flex items-center space-x-3">
              <Filter className="text-slate-400 w-6 h-6" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-6 py-4 border border-slate-300/50 dark:border-slate-600/50 rounded-2xl bg-white/80 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-primary-500 dark:focus:ring-gold-500 focus:border-transparent backdrop-blur-sm shadow-elegant transition-all duration-300 font-medium"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {filteredArticles.map((article) => (
          <div
            key={article.id}
            onClick={() => setSelectedArticle(article)}
            className="elegant-card rounded-3xl overflow-hidden shadow-elegant-lg hover:shadow-elegant-xl transition-all duration-300 cursor-pointer group hover:scale-[1.02]"
          >
            <div className="relative overflow-hidden">
              <img
                src={article.image}
                alt={article.title}
                className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
              <div className="absolute top-4 left-4 flex items-center space-x-2">
                <span className="bg-primary-500 dark:bg-gold-500 text-white px-3 py-1 rounded-xl text-sm font-bold shadow-elegant">
                  {article.category}
                </span>
                {article.featured && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-sm px-2 py-1 rounded-xl">
                    <Crown className="w-3 h-3 text-gold-400" />
                    <span className="text-white text-xs font-semibold">Featured</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-slate-100 line-clamp-2 group-hover:text-primary-600 dark:group-hover:text-gold-400 transition-colors leading-tight">
                {article.title}
              </h3>
              
              <p className="text-slate-600 dark:text-slate-400 line-clamp-3 leading-relaxed font-medium">
                {article.excerpt}
              </p>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200/50 dark:border-slate-700/50">
                <div className="flex items-center space-x-4 text-sm text-slate-500 dark:text-slate-400">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    <span className="font-medium">{article.readTime} min</span>
                  </div>
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    <span className="font-medium">{article.author}</span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-primary-500 dark:text-gold-500 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredArticles.length === 0 && (
        <div className="text-center py-16">
          <BookOpen className="w-20 h-20 text-slate-400 dark:text-slate-600 mx-auto mb-6" />
          <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-3">
            No Articles Found
          </h3>
          <p className="text-slate-600 dark:text-slate-400 text-lg">
            Try adjusting your search terms or category filter to discover more legal insights.
          </p>
        </div>
      )}
    </div>
  );
};