import React, { useState } from 'react';
import { Target, Lightbulb, AlertTriangle, TrendingUp, Clock, Crown, Zap, Shield } from 'lucide-react';

interface StrategyCase {
  id: string;
  title: string;
  type: string;
  status: 'active' | 'planning' | 'completed';
  priority: 'high' | 'medium' | 'low';
  lastUpdate: string;
  complexity: number;
}

export const StrategyRoom: React.FC = () => {
  const [activeCase, setActiveCase] = useState<string | null>(null);
  const [cases] = useState<StrategyCase[]>([
    {
      id: '1',
      title: 'Corporate Fraud Investigation - Section 420 IPC',
      type: 'Criminal Law',
      status: 'active',
      priority: 'high',
      lastUpdate: '2 hours ago',
      complexity: 9,
    },
    {
      id: '2',
      title: 'Property Succession Rights Dispute',
      type: 'Civil Law',
      status: 'planning',
      priority: 'medium',
      lastUpdate: '1 day ago',
      complexity: 7,
    },
    {
      id: '3',
      title: 'Industrial Disputes Act Violation',
      type: 'Labor Law',
      status: 'completed',
      priority: 'low',
      lastUpdate: '3 days ago',
      complexity: 5,
    },
  ]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800';
      case 'medium': return 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800';
      case 'low': return 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800';
      default: return 'text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/20 border-slate-200 dark:border-slate-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-gradient-to-r from-blue-500 to-blue-600';
      case 'planning': return 'bg-gradient-to-r from-amber-500 to-amber-600';
      case 'completed': return 'bg-gradient-to-r from-emerald-500 to-emerald-600';
      default: return 'bg-gradient-to-r from-slate-500 to-slate-600';
    }
  };

  const getComplexityBars = (complexity: number) => {
    return Array.from({ length: 10 }, (_, i) => (
      <div
        key={i}
        className={`h-1 rounded-full transition-all duration-300 ${
          i < complexity 
            ? complexity >= 8 
              ? 'bg-red-500' 
              : complexity >= 6 
                ? 'bg-amber-500' 
                : 'bg-emerald-500'
            : 'bg-slate-200 dark:bg-slate-700'
        }`}
      />
    ));
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center space-x-4 mb-4">
          <div className="p-3 bg-gradient-to-br from-primary-500/20 to-primary-600/20 dark:from-gold-500/20 dark:to-gold-600/20 rounded-2xl">
            <Crown className="w-8 h-8 text-primary-600 dark:text-gold-500" />
          </div>
          <div>
            <h1 className="text-4xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-2">
              Strategy Command Center
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 font-medium">
              Orchestrate your legal victories with precision and strategic brilliance
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        {/* Case Portfolio */}
        <div className="xl:col-span-1">
          <div className="elegant-card rounded-3xl overflow-hidden shadow-elegant-xl">
            <div className="p-6 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 border-b border-slate-200/50 dark:border-slate-700/50">
              <h2 className="text-xl font-serif font-semibold text-slate-900 dark:text-slate-100 flex items-center">
                <Target className="w-6 h-6 mr-3 text-primary-600 dark:text-gold-500" />
                Active Portfolio
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                {cases.length} strategic cases
              </p>
            </div>
            <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
              {cases.map((case_) => (
                <div
                  key={case_.id}
                  onClick={() => setActiveCase(case_.id)}
                  className={`p-5 rounded-2xl border-2 transition-all duration-300 cursor-pointer hover:scale-105 ${
                    activeCase === case_.id
                      ? 'border-primary-500 dark:border-gold-500 bg-primary-50 dark:bg-gold-900/10 shadow-elegant-lg'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white/50 dark:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold text-sm text-slate-900 dark:text-slate-100 line-clamp-2 leading-tight">
                      {case_.title}
                    </h3>
                    <div className={`w-4 h-4 rounded-full shadow-sm ${getStatusColor(case_.status)}`} />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-600 dark:text-slate-400 font-medium">{case_.type}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${getPriorityColor(case_.priority)}`}>
                        {case_.priority.toUpperCase()}
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500 dark:text-slate-400">Complexity</span>
                        <span className="font-semibold text-slate-700 dark:text-slate-300">{case_.complexity}/10</span>
                      </div>
                      <div className="grid grid-cols-10 gap-1">
                        {getComplexityBars(case_.complexity)}
                      </div>
                    </div>
                    
                    <div className="flex items-center text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/50 dark:border-slate-700/50">
                      <Clock className="w-3 h-3 mr-1" />
                      {case_.lastUpdate}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Strategic Analysis Panel */}
        <div className="xl:col-span-3">
          <div className="elegant-card rounded-3xl overflow-hidden shadow-elegant-xl">
            <div className="p-8 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 border-b border-slate-200/50 dark:border-slate-700/50">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-serif font-semibold text-slate-900 dark:text-slate-100">
                  Strategic Intelligence Dashboard
                </h2>
                {activeCase && (
                  <div className="flex items-center space-x-2">
                    <Zap className="w-5 h-5 text-primary-600 dark:text-gold-500" />
                    <span className="text-sm font-semibold text-primary-600 dark:text-gold-500">
                      AI Analysis Active
                    </span>
                  </div>
                )}
              </div>
            </div>
            
            {activeCase ? (
              <div className="p-8 space-y-8">
                {/* Case Overview */}
                <div className="bg-gradient-to-br from-primary-50 to-primary-100 dark:from-primary-900/20 dark:to-primary-800/20 p-6 rounded-2xl border border-primary-200/50 dark:border-primary-700/50">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="font-serif font-bold text-xl text-primary-900 dark:text-primary-300">
                      Case Analysis: Corporate Fraud Investigation
                    </h3>
                    <Shield className="w-6 h-6 text-primary-600 dark:text-primary-400" />
                  </div>
                  <p className="text-primary-800 dark:text-primary-400 leading-relaxed font-medium">
                    High-stakes criminal prosecution involving Section 420 IPC charges. Multi-defendant case with complex financial transactions requiring sophisticated evidence analysis and strategic courtroom positioning.
                  </p>
                </div>

                {/* Strategic Intelligence Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/20 p-6 rounded-2xl border border-emerald-200/50 dark:border-emerald-700/50">
                    <div className="flex items-center mb-4">
                      <Lightbulb className="w-6 h-6 text-emerald-600 dark:text-emerald-400 mr-3" />
                      <h4 className="font-serif font-bold text-lg text-emerald-900 dark:text-emerald-300">Strategic Advantages</h4>
                    </div>
                    <ul className="space-y-3 text-sm text-emerald-800 dark:text-emerald-400">
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Comprehensive documentary evidence chain</span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Precedent: State of Maharashtra v. Somesh Gopal (2019)</span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Witness testimony alignment verified</span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Complete financial audit trail established</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 p-6 rounded-2xl border border-red-200/50 dark:border-red-700/50">
                    <div className="flex items-center mb-4">
                      <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400 mr-3" />
                      <h4 className="font-serif font-bold text-lg text-red-900 dark:text-red-300">Critical Risk Factors</h4>
                    </div>
                    <ul className="space-y-3 text-sm text-red-800 dark:text-red-400">
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Opposing counsel: Senior Advocate with 85% success rate</span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Complex jurisdictional challenges across 3 states</span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">Aggressive timeline pressure for filing deadlines</span>
                      </li>
                      <li className="flex items-start">
                        <div className="w-2 h-2 bg-red-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                        <span className="font-medium">High-profile media attention potential</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Master Strategy */}
                <div className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 p-6 rounded-2xl border border-amber-200/50 dark:border-amber-700/50">
                  <div className="flex items-center mb-4">
                    <TrendingUp className="w-6 h-6 text-amber-600 dark:text-amber-400 mr-3" />
                    <h4 className="font-serif font-bold text-lg text-amber-900 dark:text-amber-300">Master Strategy & Power Moves</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-amber-800 dark:text-amber-400">
                    <div className="space-y-3">
                      <div>
                        <span className="font-bold text-amber-900 dark:text-amber-300">Immediate Action:</span>
                        <p className="mt-1 font-medium">File Section 91 CrPC application for additional documentary evidence within 48 hours</p>
                      </div>
                      <div>
                        <span className="font-bold text-amber-900 dark:text-amber-300">Courtroom Strategy:</span>
                        <p className="mt-1 font-medium">Chronological evidence presentation with visual timeline for maximum impact</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <span className="font-bold text-amber-900 dark:text-amber-300">Legal Precedent:</span>
                        <p className="mt-1 font-medium">Cite R.S. Nayak v. A.R. Antulay for procedural advantage in evidence admission</p>
                      </div>
                      <div>
                        <span className="font-bold text-amber-900 dark:text-amber-300">Negotiation Leverage:</span>
                        <p className="mt-1 font-medium">Highlight prosecution's burden of proof gaps in financial transaction chain</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Tactical Timeline */}
                <div className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800/50 dark:to-slate-700/50 p-6 rounded-2xl border border-slate-200/50 dark:border-slate-700/50">
                  <h4 className="font-serif font-bold text-lg text-slate-900 dark:text-slate-300 mb-6">7-Day Tactical Execution Plan</h4>
                  <div className="space-y-4">
                    {[
                      { day: 'Day 1-2', task: 'Complete comprehensive witness statement review and cross-reference verification', status: 'active' },
                      { day: 'Day 3-4', task: 'File Section 91 CrPC application with supporting documentation', status: 'pending' },
                      { day: 'Day 5-7', task: 'Prepare advanced cross-examination strategy with psychological profiling', status: 'pending' },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center space-x-4">
                        <div className={`w-4 h-4 rounded-full ${
                          item.status === 'active' 
                            ? 'bg-gradient-to-r from-primary-500 to-primary-600' 
                            : 'bg-slate-300 dark:bg-slate-600'
                        }`} />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-slate-900 dark:text-slate-300">{item.day}</span>
                            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                              item.status === 'active' 
                                ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-400'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                            }`}>
                              {item.status === 'active' ? 'In Progress' : 'Scheduled'}
                            </span>
                          </div>
                          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 font-medium">{item.task}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-16 text-center">
                <div className="mb-6">
                  <Target className="w-20 h-20 text-slate-400 dark:text-slate-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-slate-100 mb-3">
                    Select a Case for Strategic Analysis
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400 text-lg max-w-md mx-auto leading-relaxed">
                    Choose a case from your portfolio to unlock comprehensive strategic insights and tactical recommendations.
                  </p>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-slate-500 dark:text-slate-400">
                  <Crown className="w-4 h-4" />
                  <span>Premium AI-powered legal strategy awaits</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};