import React from 'react';
import { MessageCircle, Target, Users, BookOpen, FileText, Sparkles } from 'lucide-react';

interface TabNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isDark: boolean;
}

const tabs = [
  { id: 'chat', label: 'Legal Consultation', icon: MessageCircle, description: 'Ask any legal question' },
  { id: 'strategy', label: 'Strategy Room', icon: Target, description: 'Plan your legal battles' },
  { id: 'lawyer', label: 'Find Counsel', icon: Users, description: 'Connect with experts' },
  { id: 'awareness', label: 'Legal Insights', icon: BookOpen, description: 'Stay informed' },
  { id: 'documents', label: 'Document Analysis', icon: FileText, description: 'AI-powered review' },
];

export const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, setActiveTab, isDark }) => {
  return (
    <nav className="py-8">
      <div className="flex flex-wrap gap-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`group relative overflow-hidden px-6 py-4 rounded-2xl font-medium text-sm transition-all duration-300 transform hover:scale-105 active:scale-95 ${
                isActive
                  ? isDark
                    ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-slate-900 shadow-elegant-lg shadow-gold-500/25'
                    : 'bg-gradient-to-r from-primary-500 to-primary-600 text-white shadow-elegant-lg shadow-primary-500/25'
                  : isDark
                    ? 'bg-slate-800/50 text-slate-300 hover:bg-slate-700/50 border border-slate-700/50 hover:border-slate-600/50'
                    : 'bg-white/50 text-slate-600 hover:bg-white/80 border border-slate-200/50 hover:border-slate-300/50 shadow-elegant'
              } backdrop-blur-xl`}
            >
              {/* Shimmer effect for active tab */}
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
              )}
              
              <div className="relative flex items-center space-x-3">
                <Icon className={`w-5 h-5 transition-all duration-300 ${
                  isActive 
                    ? 'scale-110' 
                    : 'group-hover:scale-110'
                }`} />
                <div className="text-left">
                  <div className="font-semibold">
                    {tab.label}
                  </div>
                  <div className={`text-xs opacity-75 ${
                    isActive 
                      ? isDark ? 'text-slate-800' : 'text-white/90'
                      : isDark ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    {tab.description}
                  </div>
                </div>
                {isActive && (
                  <Sparkles className="w-4 h-4 animate-pulse" />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </nav>
  );
};