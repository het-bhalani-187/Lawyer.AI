import { useState } from 'react';

export const useActiveTab = () => {
  const [activeTab, setActiveTab] = useState('chat');

  return { activeTab, setActiveTab };
};