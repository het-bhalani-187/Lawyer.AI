# app.py
from flask import Flask, render_template, request, jsonify
from nyaygpt_main import get_chatbot_response # Ensure this import is correct

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask_chatbot():
    user_query = request.json.get('query')
    if not user_query:
        return jsonify({"error": "No query provided"}), 400

    print(f"--- Received User Query in app.py: '{user_query}' ---") # ADDED PRINT

    try:
        response = get_chatbot_response(user_query)
        print(f"--- Raw NyayGPT Response from get_chatbot_response: '{response}' (Type: {type(response)}) ---") # ADDED PRINT

        if response is None:
            response = "I couldn't generate a response. Please check the backend logs for details."
            print("--- get_chatbot_response returned None or an empty response string ---") # ADDED PRINT
        elif not isinstance(response, str):
            try:
                response = str(response) # Try to convert to string if it's not already
                print(f"--- get_chatbot_response returned non-string type, converted to: '{response}' ---")
            except Exception as convert_err:
                response = f"An error occurred converting response to string: {convert_err}"
                print(f"--- ERROR converting response to string: {convert_err} ---")


        return jsonify({"response": response})
    except Exception as e:
        print(f"!!! CRITICAL ERROR in app.py during get_chatbot_response: {e} !!!") # MODIFIED PRINT for clarity
        # Return a more user-friendly error message
        return jsonify({"error": "An error occurred while processing your request. Please try again later."}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')