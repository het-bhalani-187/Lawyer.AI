# nyaygpt_main.py (Final Modified Version for Web App)

import os
import json
import random
import subprocess
import torch
import pandas as pd
from sentence_transformers import SentenceTransformer, util
# Ensure your utils folder is in the same directory as this file,
# or your system's PYTHONPATH includes the directory containing utils
from utils.data_loader import load_legal_data
from utils.intent_classifier import detect_intent
from utils.prompt_builder import build_prompt
from utils.llm_connector import query_tinyllama_ollama

# Load legal data files
# IMPORTANT: These paths are now RELATIVE to the root of your project (NYAYGPT(OLD BOT) folder)
file_paths = [
    'C:/Users/hetbh/Desktop/Dataset/CPC.json',
    'C:/Users/hetbh/Desktop/Dataset/CrPC.json',
    'C:/Users/hetbh/Desktop/Dataset/IPC.json',
    'C:/Users/hetbh/Desktop/Dataset/RTI.json',
    'C:/Users/hetbh/Desktop/Dataset/SMA.json'
]

# Initialize model and data only once when the script is imported
# This saves time and resources as the web app starts
print("Loading legal data and SentenceTransformer model... This may take a moment.")
legal_data = load_legal_data(file_paths)
model = SentenceTransformer('all-MiniLM-L6-v2')

if legal_data:
    corpus_embeddings = model.encode(legal_data, convert_to_tensor=True)
    print("Legal data and model loaded successfully!")
else:
    corpus_embeddings = None
    print("Warning: No legal data loaded. NyayGPT may not function correctly.")

def get_chatbot_response(query): # RENAMED to match the call in app.py
    """
    This function processes a user query and returns a chatbot response.
    It's designed to be called by the web application.
    """
    if not legal_data or corpus_embeddings is None:
        return "I'm sorry, my legal data is not loaded correctly. Please check the server logs."

    intent = detect_intent(query)
    prompt = build_prompt(query, intent, legal_data, model, corpus_embeddings)
    response = query_tinyllama_ollama(prompt)
    return response

# REMOVED the original `if __name__ == "__main__":` block from here.
# The web application (app.py) now handles the user interaction loop.