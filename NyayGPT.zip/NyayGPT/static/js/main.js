// static/js/main.js (Created by Gemini)
document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    // Focus on the input field when the page loads
    userInput.focus();

    chatForm.addEventListener('submit', async (event) => {
        event.preventDefault(); // Prevent the browser from reloading the page

        const query = userInput.value.trim(); // Get user's input and remove leading/trailing spaces
        if (query === '') return; // Don't send empty queries

        // Display user's message in the chat box
        appendMessage(query, 'user');
        userInput.value = ''; // Clear the input field after sending

        // Display a "Typing..." or "Thinking..." message from the bot
        const thinkingMessageDiv = appendMessage('NyayGPT is typing...', 'bot');
        thinkingMessageDiv.classList.add('thinking-message'); // Add a class for potential styling (e.g., italics)

        // Send the user's query to your Flask backend
        try {
            const response = await fetch('/ask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json', // Tell the server we're sending JSON
                },
                body: JSON.stringify({ query: query }), // Convert the query to JSON string
            });

            // Remove the "Thinking..." message
            chatBox.removeChild(thinkingMessageDiv);

            if (!response.ok) {
                // If the server responded with an error status (e.g., 400, 500)
                const errorData = await response.json();
                throw new Error(`Server error: ${errorData.error || response.statusText}`);
            }

            const data = await response.json(); // Parse the JSON response from the server
            appendMessage(data.response, 'bot'); // Display the chatbot's response
        } catch (error) {
            console.error('Error fetching chatbot response:', error);
            // Display an error message to the user
            appendMessage('Oops! Something went wrong. Please try again.', 'bot');
            // Ensure thinking message is removed if an error occurs while it's present
            if (chatBox.contains(thinkingMessageDiv)) {
                 chatBox.removeChild(thinkingMessageDiv);
            }
        }
    });

    // Helper function to add messages to the chat box
    function appendMessage(message, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        messageDiv.textContent = message;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to the bottom of the chat
        return messageDiv; // Return the created div for potential manipulation (like for thinking message)
    }
});