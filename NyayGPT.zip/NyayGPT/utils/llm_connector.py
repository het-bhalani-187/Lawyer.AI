# utils/llm_connector.py (example structure, add these to your existing function)
import requests
import json

def query_tinyllama_ollama(prompt):
    ollama_url = "http://localhost:11434/api/generate" # Default Ollama API endpoint
    payload = {
        "model": "tinyllama", # Ensure this matches your downloaded model name
        "prompt": prompt,
        "stream": False # Set to False for simpler debugging to get full response at once
    }

    print(f"DEBUG(llm_connector): Attempting to query Ollama at {ollama_url} with prompt length {len(prompt)}") # ADDED PRINT
    print(f"DEBUG(llm_connector): Payload: {payload}") # ADDED PRINT - CAUTION: can be very verbose for long prompts

    try:
        response = requests.post(ollama_url, json=payload)
        response.raise_for_status() # Raise an exception for HTTP errors (4xx or 5xx)
        data = response.json()
        
        # Check if 'response' key exists and is not empty
        if 'response' in data:
            ollama_response = data['response']
            print(f"DEBUG(llm_connector): Received raw Ollama response (first 100 chars): {ollama_response[:100]}...") # ADDED PRINT
            return ollama_response
        else:
            print(f"DEBUG(llm_connector): Ollama response JSON missing 'response' key or empty: {data}") # ADDED PRINT
            return "No valid 'response' key in LLM output."
    except requests.exceptions.ConnectionError as e:
        print(f"ERROR(llm_connector): Could not connect to Ollama server at {ollama_url}. Is Ollama running? Error: {e}") # ADDED PRINT
        return "Failed to connect to the AI model. Is Ollama server running?"
    except requests.exceptions.RequestException as e:
        print(f"ERROR(llm_connector): Request to Ollama failed: {e}. Status Code: {response.status_code if 'response' in locals() else 'N/A'}") # ADDED PRINT
        return "An error occurred when querying the AI model."
    except json.JSONDecodeError as e:
        print(f"ERROR(llm_connector): Failed to decode JSON from Ollama response. Error: {e}. Raw response: {{(response.text[:500] if 'response' in locals() and response else 'No response')}}") # ADDED PRINT
        return "Invalid response format from AI model."
    except Exception as e:
        print(f"ERROR(llm_connector): An unexpected error occurred in query_tinyllama_ollama: {e}") # ADDED PRINT
        return "An unexpected AI model error occurred."