# **App Name**: LexConnect

## Core Features:

- User Registration: Dual profile registration for lawyers (with verification) and clients.
- Case Posting: Basic case posting system for clients, including specifying legal expertise, budget, timeline, and privacy.
- Lawyer Search & Messaging: Lawyer profile display and filtering with secure messaging between lawyers and clients.

## Style Guidelines:

- Primary color: Dark grey (#333333) for a sophisticated and modern feel.
- Secondary color: Deep blue (#003366) to inspire trust and authority.
- Accent: Teal (#008080) for highlights and interactive elements to provide contrast.
- Clean and professional fonts for readability and trust, optimized for dark backgrounds.
- Use of simple, recognizable icons for navigation and features, designed for visibility on dark backgrounds.
- Clean and organized layout, ensuring easy navigation with clear visual hierarchy suitable for a dark theme.