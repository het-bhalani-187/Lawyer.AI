
"use client";

import { useState, useEffect, useMemo } from 'react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Briefcase, Clock, DollarSign, Eye, Filter, CalendarDays } from 'lucide-react'; // Added Filter, CalendarDays
import useLocalStorage from '@/hooks/useLocalStorage';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { useRouter } from 'next/navigation';
import { useToast } from "@/hooks/use-toast";
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Skeleton } from "@/components/ui/skeleton"; // Import Skeleton
import { cn } from '@/lib/utils';

type Case = {
    id: string;
    clientId: string;
    clientName: string;
    title: string;
    description: string;
    expertise: string;
    budget?: string;
    timeline: string;
    privacy: 'public' | 'private';
    postedDate: string; // ISO string
    status: 'open' | 'closed' | 'in_progress';
    proposals?: any[]; // Placeholder for proposals
};

const legalExpertiseOptions = [
    "Family Law",
    "Corporate Law",
    "Criminal Law",
    "Real Estate Law",
    "Intellectual Property",
    "Personal Injury",
    "Immigration Law",
    "Bankruptcy Law",
    "Employment Law",
    "Other",
];


export default function BrowseCasesPage() {
  const [cases] = useLocalStorage<Case[]>('cases', []);
  const [currentUser] = useLocalStorage<any | null>('user', null);
  const [searchTerm, setSearchTerm] = useState('');
  const [expertiseFilter, setExpertiseFilter] = useState('all'); // Use 'all' as default
  const [isLawyer, setIsLawyer] = useState(false);
  const [isLoading, setIsLoading] = useState(true); // Add loading state
  const router = useRouter();
  const { toast } = useToast();


   useEffect(() => {
    if (!currentUser) {
      toast({ title: "Access Denied", description: "Please log in to browse cases.", variant: "destructive" });
      router.push('/login');
    } else if (currentUser.role !== 'lawyer') {
      toast({ title: "Access Denied", description: "Only lawyers can browse cases.", variant: "destructive" });
      router.push('/dashboard');
    } else {
        setIsLawyer(true);
    }
     setIsLoading(false); // Set loading to false after checks
  }, [currentUser, router, toast]);


   const openCases = useMemo(() => cases.filter(c => c.status === 'open' && c.privacy === 'public'), [cases]);


  const filteredCases = useMemo(() => {
    return openCases.filter(caseItem => {
      const titleMatch = caseItem.title.toLowerCase().includes(searchTerm.toLowerCase());
      const expertiseMatch = expertiseFilter === 'all' || caseItem.expertise === expertiseFilter;
      return titleMatch && expertiseMatch;
    });
  }, [openCases, searchTerm, expertiseFilter]);


   // Loading state skeleton
   const LoadingSkeleton = () => (
     <div className="space-y-8">
         <Skeleton className="h-10 w-1/3" />
          <Card className="bg-card/80 shadow-sm">
             <CardHeader>
                 <Skeleton className="h-6 w-1/4 mb-2" />
                 <Skeleton className="h-4 w-1/2" />
             </CardHeader>
             <CardContent className="flex flex-col md:flex-row gap-4">
                 <Skeleton className="h-11 flex-grow" />
                 <Skeleton className="h-11 w-full md:w-[250px]" />
             </CardContent>
          </Card>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <CaseCardSkeleton />
              <CaseCardSkeleton />
              <CaseCardSkeleton />
          </div>
     </div>
   );

   if (isLoading || !isLawyer) {
     return <DashboardLayout><LoadingSkeleton /></DashboardLayout>;
   }


  return (
    <DashboardLayout>
        <div className="space-y-8">
            {/* Page Title */}
             <h1 className="text-3xl font-bold text-foreground">Browse Available Cases</h1>

            {/* Filters Card */}
            <Card className="bg-card/80 shadow-sm border border-border/30"> {/* Added border */}
                <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center gap-2 text-primary"><Filter className="w-5 h-5" /> Filter Cases</CardTitle> {/* Use primary color */}
                <CardDescription>Find legal cases posted by clients seeking assistance.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col md:flex-row gap-4">
                <div className="flex-grow relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                    type="text"
                    placeholder="Search by case title or keyword..." // Updated placeholder
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-full h-11 bg-background/70" // Adjusted background
                    />
                </div>
                <Select value={expertiseFilter} onValueChange={setExpertiseFilter}>
                    <SelectTrigger className="w-full md:w-[250px] h-11 bg-background/70"> {/* Adjusted background */}
                    <SelectValue placeholder="Filter by Expertise" />
                    </SelectTrigger>
                    <SelectContent>
                    <SelectItem value="all">All Expertise Areas</SelectItem>
                    {legalExpertiseOptions.map(option => (
                        <SelectItem key={option} value={option}>{option}</SelectItem>
                    ))}
                    </SelectContent>
                </Select>
                {/* Consider adding sorting options later */}
                </CardContent>
            </Card>

            {/* Case Listing */}
            {filteredCases.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"> {/* Use grid layout */}
                {filteredCases.map((caseItem) => (
                    <CaseCard key={caseItem.id} caseItem={caseItem} />
                ))}
                </div>
            ) : (
                 <Card className="text-center py-16 text-muted-foreground bg-card/50 border-dashed"> {/* Updated styling */}
                    <CardContent>
                        <p className="text-lg mb-2">No open cases found.</p>
                        <p className="text-sm">Try adjusting your search filters or check back later.</p>
                    </CardContent>
                 </Card>
            )}
        </div>
    </DashboardLayout>
  );
}

// Loading Skeleton for Case Card
const CaseCardSkeleton = () => (
    <Card className="flex flex-col h-full overflow-hidden shadow-md bg-card/60 border border-border/20">
        <CardHeader className="pb-3">
            <Skeleton className="h-5 w-3/4 mb-1" />
            <Skeleton className="h-3 w-1/2 mb-2" />
            <Skeleton className="h-4 w-1/4" />
        </CardHeader>
        <CardContent className="flex-grow space-y-3 pt-0">
            <Skeleton className="h-12 w-full" />
            <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
                 <Skeleton className="h-4 w-2/5" />
                 <Skeleton className="h-4 w-2/5" />
            </div>
        </CardContent>
        <CardFooter className="pt-4 border-t border-border/20">
            <Skeleton className="h-9 w-full" />
        </CardFooter>
    </Card>
);


interface CaseCardProps {
    caseItem: Case;
}

// Updated Case Card component
function CaseCard({ caseItem }: CaseCardProps) {
   const [timeAgo, setTimeAgo] = useState('');

    useEffect(() => {
        setTimeAgo(formatDistanceToNow(new Date(caseItem.postedDate), { addSuffix: true }));
    }, [caseItem.postedDate]);

    return (
         <Card className="flex flex-col h-full overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 bg-card/60 border border-border/20 group"> {/* Card styling */}
            <CardHeader className="pb-3">
                 <CardTitle className="text-lg font-semibold mb-1 line-clamp-2 group-hover:text-primary transition-colors">{caseItem.title}</CardTitle>
                 <div className="flex justify-between items-center text-xs text-muted-foreground">
                    <span>Posted by {caseItem.clientName}</span>
                    {timeAgo ? (
                       <span className="flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5"/>{timeAgo}</span>
                    ) : (
                       <Skeleton className="h-3 w-16" /> // Placeholder for timeAgo
                    )}
                 </div>
                 <Badge variant="outline" className="text-xs w-fit mt-2">{caseItem.expertise}</Badge>
            </CardHeader>
            <CardContent className="flex-grow space-y-3 pt-0"> {/* Ensure content grows */}
                <p className="text-sm text-muted-foreground line-clamp-3">
                    {caseItem.description}
                </p>
                 {/* Use grid for details for better alignment */}
                 <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground pt-2 border-t border-dashed border-border/30">
                    {caseItem.budget && (
                        <span className="flex items-center gap-1 truncate"><DollarSign className="h-3.5 w-3.5 flex-shrink-0"/> Budget: {caseItem.budget}</span>
                    )}
                    <span className="flex items-center gap-1 truncate"><Clock className="h-3.5 w-3.5 flex-shrink-0"/> Timeline: {caseItem.timeline}</span>
                     {/* Add proposal count later if needed */}
                 </div>
            </CardContent>
            <CardFooter className="pt-4 border-t border-border/20"> {/* Ensure footer has border */}
                <Button size="sm" asChild className="w-full bg-primary hover:bg-primary/90">
                   <Link href={`/case/${caseItem.id}`}>
                       <Eye className="h-4 w-4 mr-2"/> View Details
                   </Link>
                </Button>
            </CardFooter>
        </Card>
    );
}

