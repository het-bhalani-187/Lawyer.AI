
"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Briefcase, Clock, DollarSign, User, CalendarDays, Send, AlertCircle, ArrowLeft } from 'lucide-react'; // Added ArrowLeft
import useLocalStorage from '@/hooks/useLocalStorage';
import { format } from 'date-fns'; // For better date formatting
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import Link from 'next/link'; // Import Link


type Case = {
    id: string;
    clientId: string;
    clientName: string;
    title: string;
    description: string;
    expertise: string;
    budget?: string;
    timeline: string;
    privacy: 'public' | 'private';
    postedDate: string; // ISO string
    status: 'open' | 'closed' | 'in_progress';
    proposals?: Proposal[]; // Added proposals array
};

type Proposal = {
    id: string;
    caseId: string;
    lawyerId: string;
    lawyerName: string;
    timestamp: string;
    coverLetter: string;
    proposedFee: string;
    estimatedTimeline: string;
    status: 'submitted' | 'accepted' | 'rejected';
};

type User = {
  id: string;
  role: 'lawyer' | 'client';
  fullName?: string; // Lawyer
  // ... other user fields
};

const proposalSchema = z.object({
  coverLetter: z.string().min(50, { message: "Proposal must be at least 50 characters." }).max(1500, {message: "Proposal cannot exceed 1500 characters."}),
  proposedFee: z.string().min(1, { message: "Please provide a proposed fee structure (e.g., $XXX/hour, $YYYY fixed)." }),
  estimatedTimeline: z.string().min(1, { message: "Please provide an estimated timeline." }),
});

type ProposalFormData = z.infer<typeof proposalSchema>;


export default function CaseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const caseId = params.id as string;

  const [cases, setCases] = useLocalStorage<Case[]>('cases', []);
  const [currentUser] = useLocalStorage<User | null>('user', null);
  const [caseDetails, setCaseDetails] = useState<Case | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const form = useForm<ProposalFormData>({
    resolver: zodResolver(proposalSchema),
    defaultValues: {
      coverLetter: "",
      proposedFee: "",
      estimatedTimeline: "",
    },
  });


  useEffect(() => {
    const foundCase = cases.find(c => c.id === caseId);
    if (foundCase) {
      setCaseDetails(foundCase);
      // Check if current lawyer has already submitted a proposal
      if (currentUser?.role === 'lawyer') {
          const submitted = foundCase.proposals?.some(p => p.lawyerId === currentUser.id);
          setHasSubmitted(!!submitted);
      }

    } else {
      // Handle case not found - maybe redirect or show error
      toast({ title: "Error", description: "Case not found.", variant: "destructive" });
      router.push('/browse-cases');
    }
  }, [caseId, cases, currentUser, router, toast]);


  const onSubmitProposal = (values: ProposalFormData) => {
     if (!currentUser || currentUser.role !== 'lawyer' || !caseDetails) return;

     const newProposal: Proposal = {
         id: Date.now().toString(),
         caseId: caseDetails.id,
         lawyerId: currentUser.id,
         lawyerName: currentUser.fullName || 'Unknown Lawyer', // Ensure lawyer name is available
         timestamp: new Date().toISOString(),
         status: 'submitted',
         ...values,
     };

     // Update the specific case in the cases array
     const updatedCases = cases.map(c => {
         if (c.id === caseId) {
             return {
                 ...c,
                 proposals: [...(c.proposals || []), newProposal] // Add the new proposal
             };
         }
         return c;
     });

     setCases(updatedCases); // Save updated cases list
     setHasSubmitted(true); // Update state to show proposal submitted message

     toast({
         title: "Proposal Submitted",
         description: "Your proposal has been sent to the client.",
     });

     form.reset(); // Clear the form
  };


  if (!caseDetails) {
    return <div className="container mx-auto py-12 text-center">Loading case details...</div>;
  }

   // Redirect if client tries to access directly (they should go via My Cases)
   // Or show a client-specific view if needed later
   if (currentUser && currentUser.role === 'client' && currentUser.id !== caseDetails.clientId) {
        toast({ title: "Access Denied", description: "You can only view your own cases.", variant: "destructive" });
        router.push('/dashboard');
        return null; // Prevent rendering further
   }


  return (
    <div className="container mx-auto max-w-4xl py-12 space-y-8">
        {/* Back Button */}
        <Button variant="outline" size="sm" asChild className="mb-6">
           <Link href="/browse-cases">
               <ArrowLeft className="w-4 h-4 mr-2" /> Back to Browse Cases
           </Link>
        </Button>

      {/* Case Details Card */}
      <Card>
        <CardHeader>
            <div className="flex flex-col md:flex-row justify-between md:items-start gap-4">
                 <div>
                    <CardTitle className="text-2xl font-bold mb-1">{caseDetails.title}</CardTitle>
                    <CardDescription className="text-sm">
                        Posted by {caseDetails.clientName} on {format(new Date(caseDetails.postedDate), 'PPP')}
                    </CardDescription>
                 </div>
                 <div className="flex flex-col items-start md:items-end gap-2 flex-shrink-0">
                    <Badge variant="outline" className="text-sm">{caseDetails.expertise}</Badge>
                     <Badge variant={caseDetails.status === 'open' ? 'default' : 'secondary'} className="capitalize">
                         {caseDetails.status.replace('_', ' ')}
                     </Badge>
                 </div>
            </div>
        </CardHeader>
        <CardContent className="space-y-6">
            <section>
                 <h3 className="font-semibold mb-2 text-lg border-b pb-1">Case Description</h3>
                 <p className="text-muted-foreground whitespace-pre-wrap">{caseDetails.description}</p>
            </section>

            <section>
                <h3 className="font-semibold mb-3 text-lg border-b pb-1">Requirements</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                     <div className="flex items-center gap-2">
                        <Briefcase className="h-4 w-4 text-muted-foreground" />
                         <span>Expertise: <strong>{caseDetails.expertise}</strong></span>
                    </div>
                     <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                         <span>Timeline: <strong>{caseDetails.timeline}</strong></span>
                    </div>
                     {caseDetails.budget && (
                        <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                             <span>Budget: <strong>{caseDetails.budget}</strong></span>
                        </div>
                     )}
                     <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                         <span>Client: {caseDetails.clientName}</span> {/* Maybe link to profile later if allowed */}
                    </div>
                </div>
            </section>
        </CardContent>
      </Card>

       {/* Proposal Section (for Lawyers) */}
       {currentUser?.role === 'lawyer' && caseDetails.status === 'open' && (
           <Card>
                <CardHeader>
                    <CardTitle>Submit Your Proposal</CardTitle>
                    <CardDescription>Explain how you can help the client and provide your terms.</CardDescription>
                </CardHeader>
                <CardContent>
                     {hasSubmitted ? (
                         <div className="text-center text-green-600 bg-green-100 dark:bg-green-900/30 p-4 rounded-md border border-green-300 dark:border-green-700">
                             <p>You have already submitted a proposal for this case.</p>
                             {/* Option to view/edit proposal could go here later */}
                         </div>
                     ) : (
                        <Form {...form}>
                            <form onSubmit={form.handleSubmit(onSubmitProposal)} className="space-y-6">
                                <FormField
                                    control={form.control}
                                    name="coverLetter"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Your Proposal / Cover Letter</FormLabel>
                                        <FormControl>
                                        <Textarea
                                            placeholder="Explain why you are a good fit for this case, your approach, and relevant experience..."
                                            className="min-h-[150px]"
                                            {...field}
                                        />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <FormField
                                        control={form.control}
                                        name="proposedFee"
                                        render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Proposed Fee Structure</FormLabel>
                                            <FormControl>
                                            <Input placeholder="e.g., $300/hour, $5000 Fixed Fee + milestones" {...field} />
                                            </FormControl>
                                            <FormDescription>Be clear about your rates or project cost.</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                        )}
                                    />
                                     <FormField
                                        control={form.control}
                                        name="estimatedTimeline"
                                        render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Estimated Timeline</FormLabel>
                                            <FormControl>
                                            <Input placeholder="e.g., 2-4 weeks, Initial consultation within 48 hours" {...field} />
                                            </FormControl>
                                             <FormDescription>Provide an estimate for completion or next steps.</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                        )}
                                    />
                                 </div>
                                 <Button type="submit" className="w-full md:w-auto">
                                    <Send className="h-4 w-4 mr-2"/> Submit Proposal
                                 </Button>
                            </form>
                        </Form>
                     )}
                </CardContent>
           </Card>
       )}

       {/* Client View: Show Proposals Received */}
         {currentUser?.role === 'client' && currentUser.id === caseDetails.clientId && (
             <Card>
                 <CardHeader>
                     <CardTitle>Proposals Received ({caseDetails.proposals?.length || 0})</CardTitle>
                     <CardDescription>Review proposals submitted by interested lawyers.</CardDescription>
                 </CardHeader>
                 <CardContent>
                     {caseDetails.proposals && caseDetails.proposals.length > 0 ? (
                         <div className="space-y-4">
                             {caseDetails.proposals.map(proposal => (
                                <ProposalCard key={proposal.id} proposal={proposal} />
                             ))}
                         </div>
                     ) : (
                         <p className="text-muted-foreground text-center py-4">No proposals received yet.</p>
                     )}
                 </CardContent>
             </Card>
         )}

        {/* Message for Closed/In Progress Cases */}
         {caseDetails.status !== 'open' && (
            <Card className="border-yellow-400 bg-yellow-50 dark:bg-yellow-900/20">
                <CardHeader className="flex flex-row items-center gap-3">
                    <AlertCircle className="h-5 w-5 text-yellow-600" />
                    <CardTitle className="text-yellow-700 dark:text-yellow-300">
                        Case Status: {caseDetails.status.replace('_', ' ')}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                     <p className="text-sm text-yellow-600 dark:text-yellow-400">
                         {caseDetails.status === 'in_progress'
                            ? "This case is currently in progress. New proposals cannot be submitted."
                            : "This case has been closed and is no longer accepting proposals."
                         }
                     </p>
                </CardContent>
            </Card>
         )}

    </div>
  );
}


interface ProposalCardProps {
    proposal: Proposal;
}

function ProposalCard({ proposal }: ProposalCardProps) {
    // Find lawyer info - assumes users list is accessible or passed down
    // This is inefficient; ideally, lawyer info would be part of the proposal or fetched separately
    const [users] = useLocalStorage<any[]>('users', []);
    const lawyer = users.find(u => u.id === proposal.lawyerId);

     // Placeholder actions - implement accept/reject logic later
     const handleAccept = () => alert(`Accepting proposal from ${proposal.lawyerName} - logic TBD`);
     const handleReject = () => alert(`Rejecting proposal from ${proposal.lawyerName} - logic TBD`);


    return (
        <Card className="bg-muted/50">
             <CardHeader className="flex flex-row items-start gap-4">
                 <Avatar className="h-10 w-10">
                     <AvatarImage src={lawyer?.profilePicUrl || `https://picsum.photos/seed/${lawyer?.id}/40/40`} alt={proposal.lawyerName} data-ai-hint="lawyer portrait"/>
                     <AvatarFallback>{proposal.lawyerName?.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                 </Avatar>
                <div className="flex-grow">
                    <p className="font-semibold">{proposal.lawyerName}</p>
                     <p className="text-xs text-muted-foreground">Submitted: {format(new Date(proposal.timestamp), 'PPp')}</p>
                 </div>
                 {/* Add Lawyer Rating/Verification here if available */}
             </CardHeader>
             <CardContent className="space-y-3">
                 <p className="text-sm whitespace-pre-wrap border-l-2 pl-3 italic border-border">"{proposal.coverLetter}"</p>
                 <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t">
                     <p><strong>Fee:</strong> {proposal.proposedFee}</p>
                     <p><strong>Timeline:</strong> {proposal.estimatedTimeline}</p>
                 </div>
            </CardContent>
             <CardFooter className="flex justify-end gap-2">
                <Button variant="outline" size="sm" asChild>
                    <Link href={`/messages?recipient=${proposal.lawyerId}`}>Message Lawyer</Link>
                </Button>
                 {/* Add Accept/Reject buttons for client */}
                  {/* <Button variant="destructive" size="sm" onClick={handleReject}>Reject</Button> */}
                  {/* <Button size="sm" onClick={handleAccept}>Accept Proposal</Button> */}
            </CardFooter>
        </Card>
    );
}

