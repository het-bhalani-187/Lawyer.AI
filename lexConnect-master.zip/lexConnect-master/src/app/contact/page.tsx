
"use client"; // Required for form handling

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Mail, Phone, Send } from "lucide-react"; // Added icons

const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  subject: z.string().min(5, { message: "Subject must be at least 5 characters." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export default function ContactPage() {
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  function onSubmit(values: ContactFormData) {
    // In a real app, you would send this data to your backend/API
    console.log("Contact form submitted:", values);

    toast({
      title: "Message Sent (Simulation)",
      description: "Thank you for contacting us! We will get back to you shortly.",
    });

    form.reset(); // Clear the form after successful submission
  }

  return (
    <div className="container mx-auto max-w-3xl py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Contact Us</CardTitle>
          <CardDescription>Have questions or feedback? Reach out to us.</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-8">
           {/* Contact Info */}
           <div className="space-y-4">
              <h3 className="font-semibold text-lg text-foreground">Get in Touch</h3>
              <p className="text-muted-foreground">
                  We're here to help. Fill out the form or use the contact details below.
              </p>
               <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-3">
                        <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <a href="mailto:support@lexconnect.example.com" className="hover:text-primary">support@lexconnect.example.com</a>
                         <span className="text-xs text-muted-foreground">(Placeholder)</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span>+1 (555) 123-4567</span>
                         <span className="text-xs text-muted-foreground">(Placeholder)</span>
                    </div>
                    {/* Add address if needed */}
               </div>
                <p className="text-xs text-muted-foreground pt-4">
                    Please note: For legal advice, please use the platform to connect with a qualified lawyer. We cannot provide legal counsel via this contact form.
                </p>
           </div>

           {/* Contact Form */}
           <div>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Your Name</FormLabel>
                            <FormControl>
                            <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Your Email</FormLabel>
                            <FormControl>
                            <Input type="email" placeholder="your.email@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="subject"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Subject</FormLabel>
                            <FormControl>
                            <Input placeholder="Regarding..." {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Message</FormLabel>
                            <FormControl>
                            <Textarea
                                placeholder="Please describe your inquiry..."
                                className="min-h-[100px]"
                                {...field}
                            />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <Button type="submit" className="w-full">
                        <Send className="h-4 w-4 mr-2"/> Send Message
                    </Button>
                    </form>
                </Form>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
