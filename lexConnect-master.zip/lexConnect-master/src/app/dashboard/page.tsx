"use client";

import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Briefcase, MessageSquare, User, FileText, Search, PlusCircle, ArrowUpRight, ArrowDownRight, Bell } from 'lucide-react';
import Link from 'next/link';
import useLocalStorage from '@/hooks/useLocalStorage';
import { formatDistanceToNow } from 'date-fns';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';


type User = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
  firstName?: string; // Client
  lastName?: string; // Client
  fullName?: string; // Lawyer
  specialization?: string; // Lawyer
};

type Case = {
    id: string;
    clientId: string;
    clientName: string;
    title: string;
    expertise: string;
    postedDate: string; // ISO string
    status: 'open' | 'closed' | 'in_progress';
    description: string;
    proposals?: Proposal[]; // For proposal count
};

// Added Proposal type for richer data if needed
type Proposal = {
    id: string;
    caseId: string;
    lawyerId: string;
    lawyerName: string;
    timestamp: string;
    status: 'submitted' | 'accepted' | 'rejected';
};

// Example Recent Activity Item Type
type Activity = {
  id: string;
  type: 'new_case' | 'new_proposal' | 'message_received' | 'case_closed' | 'proposal_accepted';
  timestamp: string; // ISO string
  title: string;
  description: string;
  link?: string;
  isPositive?: boolean; // For styling like the green/red transactions
};

export default function DashboardPage() {
  const [currentUser] = useLocalStorage<User | null>('user', null);
  const [cases] = useLocalStorage<Case[]>('cases', []);
  const [messages] = useLocalStorage<any[]>('messages', []); // Assuming messages structure exists
  const router = useRouter();
  const [isClientMounted, setIsClientMounted] = useState(false); // Track client mount


  useEffect(() => {
    setIsClientMounted(true); // Component has mounted
    if (!currentUser) {
      router.push('/login'); // Redirect if not logged in (check happens after mount)
    }
  }, [currentUser, router]);


  // Client's posted cases
  const clientCases = useMemo(() => currentUser?.role === 'client'
    ? cases.filter(c => c.clientId === currentUser.id)
    : [], [cases, currentUser]);

   // Cases a lawyer might be interested in (example: open cases in their specialization, or recently posted)
   const lawyerRelevantCases = useMemo(() => currentUser?.role === 'lawyer'
     ? cases.filter(c => c.status === 'open' && (!currentUser.specialization || c.expertise === currentUser.specialization || c.expertise === 'Other')) // Simple filtering
           .sort((a, b) => new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime()) // Newest first
     : [], [cases, currentUser]);


  const unreadMessagesCount = useMemo(() => currentUser
    ? messages.filter(m => m.recipientId === currentUser.id && !m.read).length
    : 0, [messages, currentUser]);

   // --- Example Recent Activity Data ---
   // In a real app, this would come from a backend or aggregated logs
   const [recentActivity, setRecentActivity] = useState<Activity[]>([]);

    useEffect(() => {
        // Ensure calculation runs only after mount and when data is available
        if (!isClientMounted || !currentUser) return;

        let activity: Activity[] = [];

        // Example: New cases posted by client
        if (currentUser.role === 'client') {
            clientCases
                .sort((a, b) => new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime())
                .slice(0, 2) // Get latest 2
                .forEach(c => activity.push({
                    id: `case-${c.id}`,
                    type: 'new_case',
                    timestamp: c.postedDate,
                    title: `Case Posted: ${c.title}`,
                    description: `Status: ${c.status.replace('_', ' ')}`,
                    link: `/my-case/${c.id}`,
                    isPositive: true,
                }));
        }

        // Example: New proposals received by client
        if (currentUser.role === 'client') {
             clientCases.forEach(c => {
                 c.proposals?.filter(p => p.status === 'submitted')
                    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .slice(0, 2) // Limit proposals shown
                    .forEach(p => activity.push({
                        id: `prop-${p.id}`,
                        type: 'new_proposal',
                        timestamp: p.timestamp,
                        title: `Proposal Received for "${c.title}"`,
                        description: `From: ${p.lawyerName}`,
                        link: `/my-case/${c.id}`,
                         isPositive: true,
                    }));
             });
        }

         // Example: New relevant cases for lawyer
         if (currentUser.role === 'lawyer') {
            lawyerRelevantCases
                .slice(0, 3) // Limit lawyer cases shown
                .forEach(c => activity.push({
                    id: `lcase-${c.id}`,
                    type: 'new_case', // Could be a different type like 'relevant_case'
                    timestamp: c.postedDate,
                    title: `New Case: ${c.title}`,
                    description: `Expertise: ${c.expertise}`,
                    link: `/case/${c.id}`,
                    isPositive: true,
                }));
         }


        // Example: Recent Messages (simplified - just showing count or last sender)
        const recentMsgs = messages
            .filter(m => m.recipientId === currentUser.id || m.senderId === currentUser.id)
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

         if (recentMsgs.length > 0) {
             const lastMsg = recentMsgs[0];
             const otherParty = lastMsg.senderId === currentUser.id ? lastMsg.recipientName : lastMsg.senderName;
             activity.push({
                 id: `msg-${lastMsg.id}`,
                 type: 'message_received',
                 timestamp: lastMsg.timestamp,
                 title: `Last Message ${lastMsg.senderId === currentUser.id ? 'Sent' : 'From'} ${otherParty}`,
                 description: lastMsg.content.substring(0, 30) + (lastMsg.content.length > 30 ? '...' : ''),
                 link: `/messages`, // Link to general messages page
                 isPositive: !lastMsg.read && lastMsg.recipientId === currentUser.id, // Highlight unread
             });
         }

        // Sort all activities by timestamp, newest first
        activity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

        setRecentActivity(activity.slice(0, 5)); // Limit to 5 most recent overall

    }, [isClientMounted, currentUser, cases, messages, clientCases, lawyerRelevantCases]); // Added isClientMounted


    // Render Loading Skeleton before client mount or if user is not yet loaded
    const LoadingSkeleton = () => (
        <div className="space-y-8">
            <div className="mb-6 p-4"> {/* Added padding */}
                <Skeleton className="h-8 w-1/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"> {/* Reduced gap here */}
                <Skeleton className="h-36 rounded-lg" /> {/* Increased height for new design */}
                <Skeleton className="h-36 rounded-lg" />
                <Skeleton className="h-36 rounded-lg" />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                    <Skeleton className="h-40 rounded-lg" />
                </div>
                <div className="lg:col-span-1">
                    <Skeleton className="h-64 rounded-lg" />
                </div>
            </div>
        </div>
    );


  // Use DashboardLayout
  return (
    <DashboardLayout>
       {/* Ensure rendering only when isClientMounted AND currentUser is available */}
       {isClientMounted && currentUser ? (
         <div className="space-y-8">
             <div className="mb-6 p-4"> {/* Added padding */}
                 <h1 className="text-3xl font-bold text-foreground">
                     Hello{currentUser.role === 'client' ? `, ${currentUser.firstName}` : currentUser.role === 'lawyer' ? `, ${currentUser.fullName}` : ''}!
                 </h1>
                 <p className="text-muted-foreground">Here's a summary of your LexConnect activity.</p>
             </div>

             {/* Stat Cards Section */}
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"> {/* Reduced gap here */}
                 <StatCard
                     title={currentUser.role === 'client' ? "My Active Cases" : "Open Relevant Cases"}
                     value={currentUser.role === 'client' ? clientCases.filter(c => c.status !== 'closed').length.toString() : lawyerRelevantCases.length.toString()}
                     icon={Briefcase}
                     description={currentUser.role === 'client' ? "Cases you've posted" : "Potential opportunities"}
                     color="primary"
                 />
                  <StatCard
                     title="Unread Messages"
                     value={unreadMessagesCount.toString()}
                     icon={MessageSquare}
                     description="Recent communications"
                     color="secondary"
                 />
                 {currentUser.role === 'client' ? (
                     <Link href="/my-case" passHref>
                         <StatCard
                             title="Proposals Received"
                             value={clientCases.reduce((sum, c) => sum + (c.proposals?.filter(p => p.status === 'submitted').length || 0), 0).toString()}
                             icon={FileText}
                             description="Offers from lawyers"
                             color="accent"
                             className="cursor-pointer h-full" // Make card height consistent if needed and add cursor
                         />
                     </Link>
                 ) : (
                     <StatCard
                         title="Proposals Submitted"
                         value={cases.reduce((sum, c) => sum + (c.proposals?.filter(p => p.lawyerId === currentUser.id).length || 0), 0).toString()}
                         icon={FileText}
                         description="Your active bids"
                         color="accent"
                     />
                 )}
             </div>

              {/* Main Content Area */}
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left/Main Column (e.g., Quick Links or Key Info) */}
                <div className="lg:col-span-2 space-y-6">
                     {/* Quick Actions / Overview */}
                     <Card>
                         <CardHeader>
                             <CardTitle>Quick Actions</CardTitle>
                         </CardHeader>
                         <CardContent className="flex flex-wrap gap-4">
                             {currentUser.role === 'client' && (
                                 <>
                                     <Button asChild><Link href="/post-case"><PlusCircle className="w-4 h-4 mr-2"/> Post New Case</Link></Button>
                                     <Button variant="outline" asChild><Link href="/my-case"><FileText className="w-4 h-4 mr-2"/> View My Cases</Link></Button>
                                     <Button variant="outline" asChild><Link href="/find-lawyer"><Search className="w-4 h-4 mr-2"/> Find Lawyers</Link></Button>
                                 </>
                             )}
                              {currentUser.role === 'lawyer' && (
                                 <>
                                     <Button asChild><Link href="/browse-cases"><Search className="w-4 h-4 mr-2"/> Browse Cases</Link></Button>
                                     {/* Add link to submitted proposals later */}
                                     {/* <Button variant="outline" asChild><Link href="/my-proposals"><FileText className="w-4 h-4 mr-2"/> My Proposals</Link></Button> */}
                                      <Button variant="outline" asChild><Link href="/profile"><User className="w-4 h-4 mr-2"/> Edit Profile</Link></Button>
                                 </>
                             )}
                             <Button variant="outline" asChild><Link href="/messages"><MessageSquare className="w-4 h-4 mr-2"/> Go to Messages</Link></Button>
                         </CardContent>
                     </Card>

                     {/* Placeholder for Charts or other important info */}
                     {/* <Card>
                         <CardHeader><CardTitle>Activity Overview</CardTitle></CardHeader>
                         <CardContent><p className="text-muted-foreground">Charts or key metrics will go here.</p></CardContent>
                     </Card> */}
                </div>

                {/* Right Column (e.g., Recent Activity) */}
                 <div className="lg:col-span-1">
                     <Card>
                         <CardHeader>
                            <CardTitle>Recent Activity</CardTitle>
                             <CardDescription>Your latest updates and notifications.</CardDescription>
                         </CardHeader>
                         <CardContent className="space-y-4">
                             {recentActivity.length > 0 ? (
                                 recentActivity.map(activity => (
                                     <ActivityItem key={activity.id} activity={activity} />
                                 ))
                             ) : (
                                 <p className="text-sm text-muted-foreground text-center py-4">No recent activity.</p>
                             )}
                              {/* Add a "View All" link if needed */}
                              {/* <Button variant="link" size="sm" className="w-full mt-2">View All Activity</Button> */}
                         </CardContent>
                     </Card>
                 </div>
            </div>
         </div>
       ) : (
          <LoadingSkeleton /> // Show skeleton while loading
       )}
    </DashboardLayout>
  );
}


interface StatCardProps {
    title: string;
    value: string;
    icon: React.ElementType;
    description: string;
    color?: 'primary' | 'secondary' | 'accent'; // Added color prop
    className?: string; // Added className prop
}

function StatCard({ title, value, icon: Icon, description, color = 'primary', className }: StatCardProps) {
    const gradientClasses = {
        primary: 'from-primary/70 to-primary/40 border-primary/30 text-primary-foreground',
        secondary: 'from-secondary/70 to-secondary/40 border-secondary/30 text-secondary-foreground',
        accent: 'from-teal-600/70 to-teal-500/40 border-teal-700/30 text-teal-100', // Updated accent to teal
    };
    const iconBgClasses = {
         primary: 'bg-primary/20 text-primary-foreground/90',
         secondary: 'bg-secondary/20 text-secondary-foreground/90',
         accent: 'bg-teal-400/20 text-teal-100/90', // Updated accent icon bg
    }

    return (
        <Card className={cn(
            "relative overflow-hidden transition-all duration-300 hover:scale-[1.03] hover:shadow-xl",
            "bg-gradient-to-br", // Apply gradient background
            gradientClasses[color],
            className // Apply passed className
        )}>
             {/* Optional decorative shape */}
             {/* <div className={cn(
                 "absolute -top-4 -right-4 w-20 h-20 rounded-full opacity-20",
                  color === 'primary' ? 'bg-primary' : color === 'secondary' ? 'bg-secondary' : 'bg-accent'
              )}></div> */}

             <CardHeader className="relative z-10 flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-base font-semibold">{title}</CardTitle>
                 {/* Enhanced icon */}
                 <div className={cn("p-2 rounded-full", iconBgClasses[color])}>
                    <Icon className="h-5 w-5" />
                 </div>
            </CardHeader>
            <CardContent className="relative z-10">
                 <div className="text-3xl font-bold">{value}</div>
                 <p className="text-xs text-current/80 pt-1">{description}</p>
            </CardContent>
        </Card>
    );
}


interface ActivityItemProps {
    activity: Activity;
}

function ActivityItem({ activity }: ActivityItemProps) {
    const [timeAgo, setTimeAgo] = useState('');

    useEffect(() => {
        setTimeAgo(formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true }));
    }, [activity.timestamp]);

    const Icon = activity.isPositive === true ? ArrowUpRight : activity.isPositive === false ? ArrowDownRight : Bell; // Choose icon based on type/positivity
    const iconColor = activity.isPositive === true ? 'text-green-500' : activity.isPositive === false ? 'text-red-500' : 'text-muted-foreground';

    const content = (
        <div className="flex items-center gap-4">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full bg-muted/50 ${iconColor}`}>
                 <Icon className="h-4 w-4" />
            </div>
            <div className="flex-grow">
                <p className="text-sm font-medium leading-none truncate">{activity.title}</p>
                <p className="text-xs text-muted-foreground truncate">{activity.description}</p>
            </div>
            <div className="text-xs text-muted-foreground"> {/* Removed whitespace-nowrap */}
                 {timeAgo ? timeAgo : <Skeleton className="h-3 w-16"/>} {/* Placeholder for timeAgo */}
            </div>
        </div>
    );

     return activity.link ? (
         <Link href={activity.link} className="block hover:bg-accent/50 p-2 -m-2 rounded-md transition-colors">
             {content}
         </Link>
     ) : (
         <div className="p-2">
             {content}
         </div>
     );
}
