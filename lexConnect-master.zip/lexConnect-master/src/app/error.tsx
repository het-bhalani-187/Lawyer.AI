
'use client' // Error components must be Client Components

import { useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertTriangle } from 'lucide-react'

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error)
  }, [error])

  return (
    <div className="container mx-auto py-12 flex items-center justify-center min-h-[calc(100vh-15rem)]">
       <Card className="max-w-lg w-full text-center border-destructive bg-destructive/10">
            <CardHeader>
                 <div className="mx-auto bg-destructive/20 p-3 rounded-full w-fit">
                    <AlertTriangle className="h-10 w-10 text-destructive" />
                 </div>
                 <CardTitle className="text-destructive mt-4">Something went wrong!</CardTitle>
                 <CardDescription className="text-destructive/80">
                     {error.message || "An unexpected error occurred."}
                 </CardDescription>
            </CardHeader>
            <CardContent>
                 <Button
                    onClick={
                    // Attempt to recover by trying to re-render the segment
                    () => reset()
                    }
                    variant="destructive"
                    className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                >
                    Try again
                </Button>
            </CardContent>
       </Card>
    </div>
  )
}
