
"use client";

import { useState, useEffect, useMemo } from 'react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Briefcase, Star, MessageSquare, ShieldCheck } from 'lucide-react'; // Added ShieldCheck
import useLocalStorage from '@/hooks/useLocalStorage';
import Link from 'next/link';
import Image from 'next/image'; // Import next/image
import { cn } from '@/lib/utils'; // Import cn
import { Skeleton } from "@/components/ui/skeleton"; // Import Skeleton
import DashboardLayout from '@/components/layout/DashboardLayout'; // Import DashboardLayout


type Lawyer = {
    id: string;
    fullName: string;
    email: string; // Added for contact button logic
    role: 'lawyer';
    barNumber: string;
    specialization: string;
    isVerified: boolean;
    // Add other potential fields like location, rating, bio etc. later
    location?: string;
    rating?: number;
    bio?: string;
    profilePicUrl?: string; // Optional profile picture URL
};


export default function FindLawyerPage() {
  const [users] = useLocalStorage<any[]>('users', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [specializationFilter, setSpecializationFilter] = useState('all'); // Default to 'all'
  const [isMounted, setIsMounted] = useState(false); // Track client mount
  // Add more filters like location, rating later

  useEffect(() => {
    setIsMounted(true); // Component has mounted
  }, []);


  const lawyers: Lawyer[] = useMemo(() => users.filter(user => user.role === 'lawyer'), [users]);

  const filteredLawyers = useMemo(() => {
    // Ensure filtering happens only after mount and lawyers data is ready
    if (!isMounted) return [];
    return lawyers.filter(lawyer => {
      const nameMatch = lawyer.fullName.toLowerCase().includes(searchTerm.toLowerCase());
      const specMatch = specializationFilter === 'all' || lawyer.specialization.toLowerCase().includes(specializationFilter.toLowerCase());
      // Combine matches - Add more filter conditions here
      return nameMatch && specMatch;
    });
  }, [lawyers, searchTerm, specializationFilter, isMounted]);


   const allSpecializations = useMemo(() => {
      // Ensure unique values and filter out any potential empty strings
      const specs = new Set(lawyers
        .map(l => l.specialization)
        .filter(spec => spec && spec.trim() !== '') // Ensure spec is not null, undefined, or empty string
      );
      // Add 'all' to the beginning
      return ['all', ...Array.from(specs).sort()];
   }, [lawyers]);


   // Loading Skeleton for Lawyer Cards
   const LawyerCardSkeleton = () => (
        <Card className="flex flex-col h-full overflow-hidden rounded-xl shadow-lg bg-card transition-all duration-300 border border-border/50">
             <Skeleton className="h-48 w-full" />
             <div className="p-5 flex flex-col flex-grow">
                 <div className="mb-3 text-center -mt-10 relative z-10">
                     <Skeleton className="h-16 w-16 rounded-full mx-auto mb-2" />
                     <Skeleton className="h-6 w-3/4 mx-auto mb-1" />
                     <Skeleton className="h-4 w-1/2 mx-auto" />
                 </div>
                 <Skeleton className="h-4 w-full mb-2" />
                 <Skeleton className="h-4 w-5/6 mb-4 mx-auto" />
                 <div className="mt-auto pt-4 border-t border-border/30">
                     <div className="flex justify-between gap-3">
                         <Skeleton className="h-9 w-1/2" />
                         <Skeleton className="h-9 w-1/2" />
                     </div>
                 </div>
             </div>
        </Card>
    );

  return (
    <DashboardLayout> {/* Wrap with DashboardLayout */}
        <div className="space-y-8">
        {/* Updated Filter Card Styling */}
        <Card className="mb-8 bg-card/80 backdrop-blur-sm shadow-md">
            <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-2 text-primary"><Search className="w-6 h-6" /> Find Your Legal Expert</CardTitle>
            <CardDescription>Search our network of verified legal professionals.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col md:flex-row gap-4">
            <div className="flex-grow relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                    type="text"
                    placeholder="Search by lawyer name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-full h-11" // Slightly larger input
                />
            </div>
            <Select value={specializationFilter} onValueChange={setSpecializationFilter}>
                <SelectTrigger className="w-full md:w-[280px] h-11"> {/* Adjusted width and height */}
                <SelectValue placeholder="Filter by Specialization" />
                </SelectTrigger>
                <SelectContent>
                {/* <SelectItem value="all">All Specializations</SelectItem> */}
                {allSpecializations.map(spec => (
                    // Check if spec is defined and not empty before rendering SelectItem
                    spec ? <SelectItem key={spec} value={spec}>{spec === 'all' ? 'All Specializations' : spec}</SelectItem> : null
                ))}
                </SelectContent>
            </Select>
            {/* Add more filter components here (e.g., Location, Rating) */}
            </CardContent>
        </Card>

        {/* Lawyer Listing - Render only after mount */}
        {!isMounted ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"> {/* Changed md: to sm: for better responsiveness */}
                <LawyerCardSkeleton />
                <LawyerCardSkeleton />
                <LawyerCardSkeleton />
            </div>
        ) : filteredLawyers.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"> {/* Changed md: to sm: for better responsiveness */}
            {filteredLawyers.map((lawyer) => (
                <LawyerCard key={lawyer.id} lawyer={lawyer} />
            ))}
            </div>
        ) : (
            <Card className="text-center py-16 text-muted-foreground bg-card/50">
                <CardContent>
                    <p className="text-lg mb-2">No lawyers found matching your criteria.</p>
                    <p className="text-sm">Try broadening your search or changing the specialization.</p>
                </CardContent>
            </Card>
        )}
        </div>
    </DashboardLayout>
  );
}


interface LawyerCardProps {
    lawyer: Lawyer;
}

// Updated Lawyer Card component - Inspired by example images
function LawyerCard({ lawyer }: LawyerCardProps) {
    const profilePic = lawyer.profilePicUrl || `https://picsum.photos/seed/${lawyer.id}/300/200`;
    const initial = lawyer.fullName.split(' ').map(n => n[0]).join('').toUpperCase();

    return (
        <Card className="flex flex-col h-full overflow-hidden rounded-xl shadow-lg bg-card transition-all duration-300 hover:shadow-2xl border border-border/50 group"> {/* Added group class */}
            {/* Image Section */}
            <div className="relative h-48 w-full overflow-hidden"> {/* Fixed height for image */}
                <Image
                     src={profilePic}
                     alt={lawyer.fullName}
                     layout="fill" // Use fill layout
                     objectFit="cover" // Cover the container
                     className="transition-transform duration-300 group-hover:scale-105" // Subtle zoom on hover
                     data-ai-hint="lawyer portrait professional"
                 />
                 {/* Optional Overlay */}
                 <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                 {/* Verification Badge on Image */}
                  {lawyer.isVerified && (
                      <Badge variant="secondary" className="absolute top-3 right-3 text-xs font-medium py-1 px-2 bg-background/80 text-foreground backdrop-blur-sm">
                          <ShieldCheck className="h-3.5 w-3.5 mr-1 text-green-500"/> Verified
                      </Badge>
                  )}
            </div>

            {/* Content Section */}
            <div className="p-5 flex flex-col flex-grow">
                {/* Name & Title */}
                <div className="mb-3 text-center -mt-10 relative z-10"> {/* Negative margin to overlap image slightly */}
                   <Avatar className="h-16 w-16 border-4 border-background shadow-md mx-auto mb-2">
                        <AvatarImage src={profilePic} alt={lawyer.fullName} data-ai-hint="lawyer headshot"/>
                        <AvatarFallback className="text-xl bg-muted">{initial}</AvatarFallback>
                   </Avatar>
                    <h3 className="text-lg font-semibold text-foreground">{lawyer.fullName}</h3>
                    <p className="text-sm text-primary font-medium flex items-center justify-center gap-1.5">
                        <Briefcase className="h-4 w-4"/> {lawyer.specialization}
                    </p>
                    {lawyer.location && (
                        <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1.5">
                            <MapPin className="h-3.5 w-3.5"/> {lawyer.location}
                        </p>
                    )}
                </div>

                {/* Rating */}
                 {lawyer.rating !== undefined && (
                     <div className="flex items-center justify-center gap-1 text-xs mb-3">
                        {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`h-4 w-4 ${i < Math.floor(lawyer.rating ?? 0) ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground/30'}`} />
                        ))}
                        <span className="text-muted-foreground ml-1">({lawyer.rating.toFixed(1)})</span>
                     </div>
                 )}

                {/* Bio */}
                <p className="text-sm text-muted-foreground line-clamp-3 text-center mb-4 flex-grow">
                    {lawyer.bio || `Experienced ${lawyer.specialization} lawyer dedicated to client success. Providing expert legal counsel and representation.`}
                </p>

                {/* Action Buttons */}
                <div className="mt-auto pt-4 border-t border-border/30"> {/* Use mt-auto to push to bottom */}
                    <div className="flex justify-between gap-3">
                        <Button variant="outline" size="sm" className="flex-1" asChild>
                            <Link href={`/profile/${lawyer.id}`}>View Profile</Link>
                        </Button>
                        <Button size="sm" className="flex-1 bg-primary hover:bg-primary/90" asChild>
                           <Link href={`/messages?recipient=${lawyer.id}`}>
                               <MessageSquare className="h-4 w-4 mr-2" /> Contact
                           </Link>
                        </Button>
                     </div>
                </div>
            </div>
        </Card>
    );
}

