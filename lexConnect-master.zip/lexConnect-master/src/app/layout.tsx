
import type { Metadata } from 'next';
import { Inter } from 'next/font/google'; // Changed font to Inter for better readability
import './globals.css';
import { cn } from '@/lib/utils';
import { Toaster } from "@/components/ui/toaster";
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
// Removed unused import: import { usePathname } from 'next/navigation';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-geist-sans', // Keep variable name for consistency if needed elsewhere
});


export const metadata: Metadata = {
  title: 'LexConnect - Legal Networking & Consultation',
  description: 'Connecting Lawyers and Clients Seamlessly',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // Cannot use usePathname here directly as this is a Server Component

  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={cn(
          'min-h-screen bg-background font-sans antialiased flex flex-col', // Removed overflow-hidden
          inter.variable // Use Inter font variable
        )}
      >
        {/* Header might need conditional rendering based on route in a client component wrapper if needed */}
        <Header />
        {/* Remove container and padding from main, let page/layout components handle it */}
        <main className="flex-grow flex flex-col">
           {children}
        </main>
        {/* Footer might need conditional rendering based on route */}
        <Footer />
        <Toaster />
      </body>
    </html>
  );
}
