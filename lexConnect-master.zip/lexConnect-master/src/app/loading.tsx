
import { Skeleton } from "@/components/ui/skeleton";

export default function Loading() {
  // You can add any UI inside Loading, including a Skeleton.
  return (
    <div className="container mx-auto py-12 space-y-8">
        <Skeleton className="h-12 w-1/4" />
        <Skeleton className="h-8 w-3/4 mb-8" />

         <div className="grid md:grid-cols-3 gap-4 mb-8">
            <Skeleton className="h-32 rounded-lg" />
            <Skeleton className="h-32 rounded-lg" />
             <Skeleton className="h-32 rounded-lg" />
         </div>

        <Skeleton className="h-64 rounded-lg" />
         <Skeleton className="h-64 rounded-lg mt-8" />
    </div>
    );
}
