

"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { LogIn, User, Lock, Mail, Briefcase, Award } from 'lucide-react'; // Added User, Briefcase, Award

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"; // Added CardDescription
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import useLocalStorage from '@/hooks/useLocalStorage';
import { cn } from "@/lib/utils";

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address." }),
  password: z.string().min(1, { message: "Password is required." }),
  rememberMe: z.boolean().optional(),
});

type LoginFormData = z.infer<typeof formSchema>;

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [users] = useLocalStorage<any[]>('users', []);
  const [, setCurrentUser] = useLocalStorage<any | null>('user', null);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
      rememberMe: false,
    },
  });

  function onSubmit(values: LoginFormData) {
    console.log("Login attempt with:", values);

    const user = users.find(u => u.email === values.email && u.password === values.password);

    if (user) {
      setCurrentUser(user); // Updates localStorage
      toast({
        title: "Login Successful",
        description: `Welcome back, ${user.role === 'client' ? user.firstName : user.fullName}!`,
      });
      router.push('/dashboard'); // Client-side navigation acts as a soft refresh for the dashboard
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid email or password.",
        variant: "destructive",
      });
      // Ensure errors are set correctly if login fails
      form.setError("email", { type: "manual", message: " " }); // Clear message maybe?
      form.setError("password", { type: "manual", message: "Invalid email or password." });
    }
  }

  return (
    <div className={cn(
        "flex items-center justify-center min-h-screen p-4",
        "login-page-background" // Apply specific class for background and effects
    )}>
      <Card className={cn(
          "w-full max-w-md bg-black/70 backdrop-blur-lg shadow-2xl text-neutral-200 rounded-xl border border-neutral-800/50 overflow-hidden", // Adjusted styling for a sleeker look
          "login-card-glow" // Apply the glowing light animation class
          )}>
        <CardHeader className="text-center p-6 md:p-8">
           <CardTitle className="text-3xl font-bold text-neutral-100 tracking-tight mb-2">
                Welcome Back
            </CardTitle>
            <CardDescription className="text-neutral-400">
                Sign in to access your LexConnect account.
            </CardDescription>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6"> {/* Increased spacing */}
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="relative"> {/* Use relative for icon positioning */}
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" /> {/* Mail Icon */}
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="Email Address"
                        {...field}
                        className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" // Updated styles
                      />
                    </FormControl>
                    <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem className="relative"> {/* Use relative for icon positioning */}
                     <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" /> {/* Lock Icon */}
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="Password"
                        {...field}
                        className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" // Updated styles
                      />
                    </FormControl>
                     <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                  </FormItem>
                )}
              />

              <div className="flex items-center justify-between text-sm pt-1">
                 <FormField
                    control={form.control}
                    name="rememberMe"
                    render={({ field }) => (
                     <FormItem className="flex items-center space-x-2">
                        <FormControl>
                             <Checkbox
                                 checked={field.value}
                                 onCheckedChange={field.onChange}
                                 id="rememberMe"
                                 className="border-neutral-600 data-[state=checked]:bg-teal-600 data-[state=checked]:border-teal-500 data-[state=checked]:text-neutral-100 h-4 w-4" // Adjusted styling
                             />
                        </FormControl>
                        <Label htmlFor="rememberMe" className="font-normal text-neutral-400 cursor-pointer select-none">
                            Remember me
                        </Label>
                     </FormItem>
                    )}
                 />
                 <Button variant="link" asChild className="p-0 h-auto text-sm text-neutral-400 hover:text-teal-400 hover:underline">
                      <Link href="/forgot-password">Forgot password?</Link>
                 </Button>
              </div>

              <Button type="submit" className="w-full !mt-8 bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 rounded-lg text-base transition-all duration-300 transform hover:scale-[1.02]" size="lg">
                <LogIn className="w-5 h-5 mr-2"/> Sign In
              </Button>

               <div className="text-center text-sm text-neutral-400 pt-4">
                    Don't have an account?{' '}
                    <Button variant="link" asChild className="p-0 h-auto font-semibold text-teal-400 hover:text-teal-300 hover:underline text-sm">
                        <Link href="/register">
                            Register here
                        </Link>
                    </Button>
                </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
