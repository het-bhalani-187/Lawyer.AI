
"use client";

import { useState, useEffect, useMemo, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, MessageSquare, Search, Users, Smile, ArrowLeft } from 'lucide-react'; // Added ArrowLeft
import useLocalStorage from '@/hooks/useLocalStorage';
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import DashboardLayout from '@/components/layout/DashboardLayout';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

// Dummy data structure - Replace with real data handling
type Message = {
    id: string;
    senderId: string;
    recipientId: string;
    senderName: string;
    recipientName: string;
    timestamp: string; // ISO string
    content: string;
    read: boolean;
};

type User = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
  firstName?: string;
  lastName?: string;
  fullName?: string;
  profilePicUrl?: string;
};


type Conversation = {
    id: string;
    participants: { id: string; name: string; profilePicUrl?: string }[];
    messages: Message[];
    lastMessageTimestamp: string;
    unreadCount: number;
};


export default function MessagesPage() {
  const [currentUser] = useLocalStorage<User | null>('user', null);
  const [users] = useLocalStorage<any[]>('users', []);
  const [messages, setMessages] = useLocalStorage<Message[]>('messages', []);
  const [newMessage, setNewMessage] = useState('');
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const router = useRouter();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const recipientIdFromQuery = searchParams.get('recipient');
  const [isClientLoading, setIsClientLoading] = useState(true);
  const messageEndRef = useRef<HTMLDivElement | null>(null);


  // Group messages into conversations
   const conversations = useMemo(() => {
     if (!currentUser) return [];

     const convMap = new Map<string, Conversation>();

     messages.forEach(msg => {
       const otherParticipantId = msg.senderId === currentUser.id ? msg.recipientId : msg.senderId;
       const conversationId = [currentUser.id, otherParticipantId].sort().join('-');

       if (!convMap.has(conversationId)) {
         const otherUser = users.find(u => u.id === otherParticipantId);
         const currentUserInfo = users.find(u => u.id === currentUser.id);

         if (!otherUser || !currentUserInfo) return;

         convMap.set(conversationId, {
           id: conversationId,
           participants: [
             { id: currentUserInfo.id, name: currentUserInfo.role === 'client' ? `${currentUserInfo.firstName} ${currentUserInfo.lastName}` : currentUserInfo.fullName ?? 'User', profilePicUrl: currentUserInfo.profilePicUrl },
             { id: otherUser.id, name: otherUser.role === 'client' ? `${otherUser.firstName} ${otherUser.lastName}` : otherUser.fullName ?? 'User', profilePicUrl: otherUser.profilePicUrl }
           ],
           messages: [],
           lastMessageTimestamp: '1970-01-01T00:00:00Z',
           unreadCount: 0,
         });
       }

        const conversation = convMap.get(conversationId);
        if (conversation) {
            conversation.messages.push(msg);
            if (msg.timestamp > conversation.lastMessageTimestamp) {
                 conversation.lastMessageTimestamp = msg.timestamp;
             }
             if (!msg.read && msg.recipientId === currentUser.id) {
                conversation.unreadCount += 1;
             }
        }
     });

      convMap.forEach(conv => {
        conv.messages.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      });


     return Array.from(convMap.values()).sort((a, b) => b.lastMessageTimestamp.localeCompare(a.lastMessageTimestamp));

   }, [messages, currentUser, users]);

   const filteredConversations = useMemo(() => {
       if (!searchTerm) return conversations;
       return conversations.filter(conv => {
           const otherParticipant = conv.participants.find(p => p.id !== currentUser?.id);
           return otherParticipant?.name.toLowerCase().includes(searchTerm.toLowerCase());
       });
   }, [conversations, searchTerm, currentUser]);


   useEffect(() => {
       setIsClientLoading(false);
       if (!currentUser) {
           toast({ title: "Access Denied", description: "Please log in to view messages.", variant: "destructive" });
           router.push('/login');
       }
   }, [currentUser, router, toast]);


   useEffect(() => {
       if (!isClientLoading && recipientIdFromQuery && currentUser) {
           const conversationId = [currentUser.id, recipientIdFromQuery].sort().join('-');
           const targetConversation = conversations.find(c => c.id === conversationId);

           if (targetConversation) {
               setSelectedConversationId(conversationId);
           } else {
               const recipientUser = users.find(u => u.id === recipientIdFromQuery);
               if (recipientUser && !conversations.some(c => c.id === conversationId)) {
                    const tempConvId = [currentUser.id, recipientIdFromQuery].sort().join('-');
                     setSelectedConversationId(tempConvId);
                     console.log("Recipient found, starting new conversation.");
               } else {
                   setSelectedConversationId(null);
               }
           }
       }
   }, [recipientIdFromQuery, currentUser, conversations, isClientLoading, users, router]);

    useEffect(() => {
        messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [selectedConversationId, messages]);


   const selectedConversation = useMemo(() => {
      if (selectedConversationId && !conversations.find(c => c.id === selectedConversationId)) {
          const participantIds = selectedConversationId.split('-');
          const otherParticipantId = participantIds.find(id => id !== currentUser?.id);
          const otherUser = users.find(u => u.id === otherParticipantId);
          const currentUserInfo = users.find(u => u.id === currentUser?.id);

          if (otherUser && currentUserInfo) {
              return {
                  id: selectedConversationId,
                  participants: [
                      { id: currentUserInfo.id, name: currentUserInfo.role === 'client' ? `${currentUserInfo.firstName} ${currentUserInfo.lastName}` : currentUserInfo.fullName ?? 'User', profilePicUrl: currentUserInfo.profilePicUrl },
                      { id: otherUser.id, name: otherUser.role === 'client' ? `${otherUser.firstName} ${otherUser.lastName}` : otherUser.fullName ?? 'User', profilePicUrl: otherUser.profilePicUrl }
                  ],
                  messages: [],
                  lastMessageTimestamp: new Date().toISOString(),
                  unreadCount: 0,
              };
          }
      }
      return conversations.find(c => c.id === selectedConversationId);
   }, [conversations, selectedConversationId, currentUser, users]);


   const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !currentUser || !selectedConversationId) return;

        const conversation = selectedConversation;
        const recipient = conversation?.participants.find(p => p.id !== currentUser.id);

        if (!recipient) {
             toast({ title: "Error", description: "Cannot determine recipient.", variant: "destructive"});
             return;
        }

        const messageToSend: Message = {
            id: Date.now().toString(),
            senderId: currentUser.id,
            recipientId: recipient.id,
            senderName: currentUser.role === 'client' ? `${currentUser.firstName} ${currentUser.lastName}` : currentUser.fullName ?? 'User',
            recipientName: recipient.name,
            timestamp: new Date().toISOString(),
            content: newMessage,
            read: false,
        };

        setMessages([...messages, messageToSend]);
        setNewMessage('');
   };

   useEffect(() => {
     if (selectedConversationId && currentUser) {
       const updatedMessages = messages.map(msg => {
         if (msg.recipientId === currentUser.id && !msg.read) {
            const msgConvId = [msg.senderId, msg.recipientId].sort().join('-');
            if (msgConvId === selectedConversationId) {
                return { ...msg, read: true };
            }
         }
         return msg;
       });

       if (JSON.stringify(messages) !== JSON.stringify(updatedMessages)) {
            setMessages(updatedMessages);
       }
     }
   }, [selectedConversationId, currentUser, messages, setMessages]);


    if (isClientLoading || !currentUser) {
        return (
            <DashboardLayout>
                 {/* Updated Loading Skeleton */}
                <div className="h-full flex flex-col bg-gradient-to-br from-background via-muted/10 to-background">
                     <CardHeader className="px-4 pt-4 pb-4 flex-shrink-0 border-b border-border/30">
                        <Skeleton className="h-8 w-1/3 mb-1" />
                        <Skeleton className="h-4 w-1/2" />
                     </CardHeader>
                    <div className="flex-grow flex border-t border-border/10 rounded-lg overflow-hidden min-h-0"> {/* Removed bg-card/80 */}
                         <div className="w-full md:w-1/3 border-r border-border/10 flex flex-col bg-background/30 backdrop-blur-sm">
                             <div className="p-4 border-b border-border/10 sticky top-0 bg-background/50 backdrop-blur-sm z-10 flex-shrink-0">
                                <Skeleton className="h-9 w-full" />
                             </div>
                             <div className="overflow-y-auto flex-grow p-2 space-y-1">
                                {[...Array(5)].map((_, i) => (
                                    <div key={i} className="flex items-center gap-3 p-3 rounded-lg">
                                        <Skeleton className="h-10 w-10 rounded-full"/>
                                        <div className="flex-grow space-y-1.5">
                                            <Skeleton className="h-4 w-3/4"/>
                                            <Skeleton className="h-3 w-1/2"/>
                                        </div>
                                        <Skeleton className="h-4 w-4 rounded-full ml-auto" />
                                    </div>
                                ))}
                             </div>
                         </div>
                         <div className="hidden md:flex w-2/3 flex-col items-center justify-center text-muted-foreground bg-muted/5">
                            <MessageSquare className="h-16 w-16 mb-4 text-muted-foreground/30" />
                             <p>Loading conversations...</p>
                         </div>
                    </div>
                </div>
            </DashboardLayout>
        );
    }


  return (
    <DashboardLayout>
        {/* Messages UI - Full height, Gradient BG */}
        <div className="h-full flex flex-col bg-gradient-to-br from-background via-secondary/5 to-background"> {/* Main container with full height and subtle gradient */}
             {/* Optional Header (Can be removed if redundant with layout) */}
            {/* <CardHeader className="px-4 pt-4 pb-4 flex-shrink-0 border-b border-border/30">
                <CardTitle className="text-2xl font-bold flex items-center gap-2"><Users className="w-6 h-6 text-primary"/> Messages</CardTitle>
                <CardDescription>Your conversations with lawyers and clients.</CardDescription>
            </CardHeader> */}

             {/* Main Chat Area */}
            <div className="flex-grow flex border border-border/10 rounded-lg overflow-hidden shadow-lg min-h-0 mt-4 mx-4 mb-4"> {/* Added margin */}

                {/* Conversation List */}
                 <div className={cn(
                     "border-r border-border/10 flex flex-col transition-all duration-300 ease-in-out bg-background/30 backdrop-blur-sm", // Added background/blur
                     selectedConversationId && "hidden md:flex",
                     !selectedConversationId && "w-full",
                     "md:w-[320px]" // Fixed width for desktop sidebar
                 )}>
                     {/* List Header + Search */}
                     <div className="p-4 border-b border-border/10 sticky top-0 bg-background/50 backdrop-blur-sm z-10 flex-shrink-0 space-y-3">
                        <h2 className="text-xl font-semibold flex items-center gap-2"><Users className="w-5 h-5 text-primary"/> Conversations</h2>
                         <div className="relative">
                             <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                             <Input
                                placeholder="Search contacts..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10 h-9 bg-muted/50 border-border/30 focus:bg-background" // Adjusted input style
                            />
                         </div>
                     </div>
                     {/* Scrollable List */}
                     <div className="overflow-y-auto flex-grow p-1"> {/* Reduced padding */}
                         {filteredConversations.length > 0 ? (
                             filteredConversations.map(conv => {
                                 const otherParticipant = conv.participants.find(p => p.id !== currentUser.id);
                                 const lastMessage = conv.messages.length > 0 ? conv.messages[conv.messages.length - 1] : null;
                                 const timeAgo = lastMessage ? formatDistanceToNow(new Date(lastMessage.timestamp), { addSuffix: true }) : '';

                                 return (
                                     <button
                                         key={conv.id}
                                         onClick={() => setSelectedConversationId(conv.id)}
                                         className={cn(
                                             "w-full text-left p-3 border-b border-transparent hover:border-border/10 hover:bg-muted/50 transition-colors flex items-center gap-3 rounded-md mb-1", // Rounded items, margin bottom
                                             selectedConversationId === conv.id ? 'bg-muted border-border/20' : '' // Highlight selected
                                         )}
                                     >
                                         <Avatar className="h-10 w-10 border-2 border-border/20"> {/* Added border */}
                                             <AvatarImage src={otherParticipant?.profilePicUrl || `https://picsum.photos/seed/${otherParticipant?.id}/40/40`} alt={otherParticipant?.name} data-ai-hint="person portrait professional"/>
                                             <AvatarFallback className="bg-muted">{otherParticipant?.name?.split(' ').map(n => n[0]).join('').toUpperCase() || '?'}</AvatarFallback>
                                         </Avatar>
                                         <div className="flex-grow overflow-hidden">
                                             <p className="font-medium truncate text-sm">{otherParticipant?.name}</p>
                                             {lastMessage && <p className="text-xs text-muted-foreground truncate">{lastMessage.senderId === currentUser.id ? 'You: ' : ''}{lastMessage.content}</p>}
                                         </div>
                                         <div className="flex flex-col items-end text-xs text-muted-foreground ml-auto flex-shrink-0 pl-2"> {/* Added padding left */}
                                              <span className="whitespace-nowrap">{timeAgo.replace('about ', '').replace(' ago', '')}</span> {/* Shorten time */}
                                             {conv.unreadCount > 0 && (
                                                 <span className="mt-1 bg-primary text-primary-foreground h-5 w-5 rounded-full flex items-center justify-center text-[10px] font-bold shadow">
                                                     {conv.unreadCount > 9 ? '9+' : conv.unreadCount}
                                                 </span>
                                             )}
                                         </div>
                                     </button>
                                 );
                             })
                         ) : (
                             <p className="p-4 text-sm text-muted-foreground text-center">
                                {searchTerm ? "No matches found." : "No conversations yet."}
                             </p>
                         )}
                     </div>
                 </div>

                 {/* Message View */}
                  <div className={cn(
                      "flex flex-col transition-all duration-300 ease-in-out bg-muted/5", // Subtle background for message area
                      !selectedConversationId && "hidden md:flex",
                      selectedConversationId && "w-full",
                      "md:w-0 md:flex-grow" // Ensure it takes remaining space
                  )}>
                     {selectedConversation ? (
                         <>
                             {/* Chat Header */}
                              <div className="p-3 border-b border-border/10 flex items-center gap-3 bg-background/60 backdrop-blur-sm sticky top-0 z-10 flex-shrink-0 shadow-sm">
                                 <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={() => setSelectedConversationId(null)}>
                                     <ArrowLeft className="h-5 w-5"/>
                                 </Button>
                                 {(() => {
                                     const otherParticipant = selectedConversation.participants.find(p => p.id !== currentUser.id);
                                     return (
                                         <>
                                             <Avatar className="h-10 w-10 border-2 border-border/20">
                                                 <AvatarImage src={otherParticipant?.profilePicUrl || `https://picsum.photos/seed/${otherParticipant?.id}/40/40`} alt={otherParticipant?.name} data-ai-hint="person profile"/>
                                                 <AvatarFallback className="bg-muted">{otherParticipant?.name?.split(' ').map(n => n[0]).join('').toUpperCase() || '?'}</AvatarFallback>
                                             </Avatar>
                                             <div className="flex-grow">
                                                <p className="font-semibold text-sm">{otherParticipant?.name}</p>
                                                <p className="text-xs text-green-500">Online</p> {/* Example status */}
                                             </div>
                                         </>
                                     );
                                 })()}
                             </div>
                             {/* Message List */}
                             <div className="flex-grow overflow-y-auto p-4 space-y-4"> {/* Removed bg-muted/20 */}
                                 {selectedConversation.messages.map(msg => {
                                     const isCurrentUser = msg.senderId === currentUser.id;
                                     const timestamp = formatDistanceToNow(new Date(msg.timestamp), { addSuffix: true });
                                     return (
                                         <div key={msg.id} className={cn('flex', isCurrentUser ? 'justify-end' : 'justify-start')}>
                                             <div className={cn(
                                                 'max-w-[75%] p-3 rounded-xl shadow text-sm',
                                                 isCurrentUser
                                                    ? 'bg-gradient-to-br from-primary via-primary/90 to-primary/80 text-primary-foreground rounded-br-none' // Gradient for user's messages
                                                    : 'bg-card text-card-foreground rounded-bl-none border border-border/20' // Card background for others
                                             )}>
                                                 <p className="leading-snug">{msg.content}</p>
                                                 <p className={cn(
                                                     'text-xs mt-1.5 opacity-70', // Increased margin-top
                                                     isCurrentUser ? 'text-right text-primary-foreground/80' : 'text-left text-muted-foreground' // Adjusted opacity color
                                                 )}>
                                                     {timestamp}
                                                 </p>
                                             </div>
                                         </div>
                                     );
                                 })}
                                 <div ref={messageEndRef} />
                             </div>

                             {/* Message Input */}
                             <form onSubmit={handleSendMessage} className="p-3 border-t border-border/10 bg-background/80 backdrop-blur-sm flex gap-2 items-center flex-shrink-0">
                                 <Input
                                     placeholder="Type a message..."
                                     value={newMessage}
                                     onChange={(e) => setNewMessage(e.target.value)}
                                     className="flex-grow h-10 rounded-full px-4 bg-muted border-transparent focus-visible:ring-1 focus-visible:ring-primary focus-visible:border-primary" // Adjusted input style
                                 />
                                 <Button type="submit" size="icon" disabled={!newMessage.trim()} className="rounded-full bg-primary hover:bg-primary/90 w-10 h-10 flex-shrink-0 shadow">
                                     <Send className="h-4 w-4" />
                                     <span className="sr-only">Send</span>
                                 </Button>
                             </form>
                         </>
                     ) : (
                          <div className="hidden md:flex w-full h-full flex-col items-center justify-center text-center text-muted-foreground">
                             <MessageSquare className="h-20 w-20 mb-4 text-muted-foreground/20" /> {/* Larger icon */}
                             <p className="text-lg font-medium">Select a conversation</p>
                             <p className="text-sm">Start chatting with your connections.</p>
                         </div>
                     )}
                 </div>
            </div>
        </div>
    </DashboardLayout>
  );
}
