
"use client";

// This page is essentially the same as /case/[id] but tailored for the client's view.
// We can reuse most of the logic and components.

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Briefcase, Clock, DollarSign, User, CalendarDays, AlertCircle, Trash2, Edit, ArrowLeft, ShieldCheck, MessageSquare } from 'lucide-react'; // Added MessageSquare
import useLocalStorage from '@/hooks/useLocalStorage';
import { format } from 'date-fns';
import { useToast } from "@/hooks/use-toast";
import Link from 'next/link';
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/separator"; // Import Separator


type Case = {
    id: string;
    clientId: string;
    clientName: string;
    title: string;
    description: string;
    expertise: string;
    budget?: string;
    timeline: string;
    privacy: 'public' | 'private';
    postedDate: string; // ISO string
    status: 'open' | 'closed' | 'in_progress';
    proposals?: Proposal[];
};

type Proposal = {
    id: string;
    caseId: string;
    lawyerId: string;
    lawyerName: string;
    timestamp: string;
    coverLetter: string;
    proposedFee: string;
    estimatedTimeline: string;
    status: 'submitted' | 'accepted' | 'rejected';
};

type User = {
  id: string;
  role: 'lawyer' | 'client';
  profilePicUrl?: string; // Add profile pic for lawyer avatar in proposal
  isVerified?: boolean; // Add verification status for lawyer
  // ... other user fields
};


export default function MyCaseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const caseId = params.id as string;

  const [cases, setCases] = useLocalStorage<Case[]>('cases', []);
  const [currentUser] = useLocalStorage<User | null>('user', null);
  const [caseDetails, setCaseDetails] = useState<Case | null>(null);

  useEffect(() => {
     if (!currentUser) {
        router.push('/login');
        return;
     }

    const foundCase = cases.find(c => c.id === caseId);

    if (foundCase) {
        // Ensure the current user is the client who posted this case
        if(currentUser.role !== 'client' || foundCase.clientId !== currentUser.id) {
             toast({ title: "Access Denied", description: "You can only view your own posted cases.", variant: "destructive" });
             router.push('/dashboard');
        } else {
             setCaseDetails(foundCase);
        }
    } else {
      toast({ title: "Error", description: "Case not found.", variant: "destructive" });
      router.push('/dashboard'); // Redirect client to their dashboard
    }
  }, [caseId, cases, currentUser, router, toast]);


   const handleAcceptProposal = (proposalId: string) => {
        if (!caseDetails) return;

        const updatedCases = cases.map(c => {
            if (c.id === caseId) {
                 // Mark the accepted proposal and reject others
                 const updatedProposals = c.proposals?.map(p => {
                    if (p.id === proposalId) {
                        return { ...p, status: 'accepted' as 'accepted' };
                    } else if (p.status === 'submitted') { // Reject other pending proposals
                         return { ...p, status: 'rejected' as 'rejected' };
                    }
                    return p;
                 });
                return { ...c, status: 'in_progress' as 'in_progress', proposals: updatedProposals };
            }
            return c;
        });

        setCases(updatedCases);
        toast({ title: "Proposal Accepted", description: "The case status is now 'In Progress'." });
   };

   const handleRejectProposal = (proposalId: string) => {
      if (!caseDetails) return;

       const updatedCases = cases.map(c => {
            if (c.id === caseId) {
                 const updatedProposals = c.proposals?.map(p =>
                    p.id === proposalId ? { ...p, status: 'rejected' as 'rejected' } : p
                 );
                return { ...c, proposals: updatedProposals };
            }
            return c;
        });
       setCases(updatedCases);
       toast({ title: "Proposal Rejected", description: "The lawyer has been notified (simulation)." });
   };

    const handleDeleteCase = () => {
        if (!caseDetails || caseDetails.status !== 'open') {
             toast({ title: "Action Not Allowed", description: "Only open cases can be deleted.", variant: "destructive"});
             return;
        }
         // Add confirmation dialog here in a real app
         if (confirm("Are you sure you want to delete this case? This action cannot be undone.")) {
             const updatedCases = cases.filter(c => c.id !== caseId);
             setCases(updatedCases);
             toast({ title: "Case Deleted", description: `Case "${caseDetails.title}" has been removed.`});
             router.push('/dashboard');
         }
    };


  if (!caseDetails || !currentUser || currentUser.id !== caseDetails.clientId) {
    // Handles loading state and unauthorized access after initial check
    return <div className="container mx-auto py-12 text-center">Loading or Access Denied...</div>;
  }

  const statusBadgeVariant = {
      open: 'default', // Will use primary color (teal)
      in_progress: 'secondary', // Will use secondary color (deep blue)
      closed: 'outline', // Will use outline style
  }[caseDetails.status] as "default" | "secondary" | "outline" | undefined;


  return (
    <div className="container mx-auto max-w-4xl py-8 md:py-12 space-y-8">
       {/* Back Button & Page Title */}
        <div className="flex items-center justify-between mb-6">
             <Button variant="outline" size="sm" asChild>
                 <Link href="/my-case">
                 <ArrowLeft className="w-4 h-4 mr-2" /> Back to My Cases
                 </Link>
             </Button>
            <Badge variant={statusBadgeVariant} className={cn("capitalize text-sm")}>
                {caseDetails.status.replace('_', ' ')}
            </Badge>
        </div>


      {/* Case Details Card */}
      <Card className="overflow-hidden shadow-lg border-border/50"> {/* Added shadow */}
        <CardHeader className="bg-gradient-to-r from-card via-card to-muted/10 p-6"> {/* Subtle gradient header */}
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4"> {/* Ensure items-center */}
                 <div className="flex-grow">
                    <CardTitle className="text-2xl font-bold text-foreground mb-1">{caseDetails.title}</CardTitle>
                    <CardDescription className="text-sm flex items-center gap-1.5 text-muted-foreground">
                        <CalendarDays className="w-4 h-4" /> {/* Increased icon size slightly */}
                         <span>Posted on {format(new Date(caseDetails.postedDate), 'PPP')}</span>
                    </CardDescription>
                 </div>
                 {/* Action Buttons */}
                  <div className="flex items-center gap-2 flex-shrink-0 mt-2 md:mt-0">
                      <Button variant="outline" size="sm" onClick={() => alert("Edit case feature coming soon!")} disabled={caseDetails.status !== 'open'} title={caseDetails.status !== 'open' ? 'Cannot edit case unless status is Open' : 'Edit Case'}>
                           <Edit className="w-4 h-4 mr-2"/> Edit
                       </Button>
                       <Button variant="destructive" size="sm" onClick={handleDeleteCase} disabled={caseDetails.status !== 'open'} title={caseDetails.status !== 'open' ? 'Cannot delete case unless status is Open' : 'Delete Case'}>
                           <Trash2 className="w-4 h-4 mr-2"/> Delete
                       </Button>
                 </div>
            </div>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
             <section>
                 <h3 className="font-semibold mb-3 text-lg flex items-center gap-2 text-primary"><Briefcase className="w-5 h-5"/> Case Description</h3>
                 <p className="text-muted-foreground text-sm leading-relaxed whitespace-pre-wrap bg-muted/30 p-4 rounded-md border border-border/50">{caseDetails.description}</p>
             </section>

             <Separator />

            <section>
                <h3 className="font-semibold mb-4 text-lg flex items-center gap-2 text-primary"><User className="w-5 h-5"/> Requirements</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 text-sm">
                     <div className="flex items-start gap-3">
                        <Briefcase className="h-4 w-4 text-muted-foreground mt-1 flex-shrink-0" /> {/* Adjusted margin-top */}
                         <div>
                             <span className="font-medium text-foreground">Expertise Needed</span>
                             <p className="text-muted-foreground">{caseDetails.expertise}</p>
                         </div>
                    </div>
                     <div className="flex items-start gap-3">
                        <Clock className="h-4 w-4 text-muted-foreground mt-1 flex-shrink-0" /> {/* Adjusted margin-top */}
                          <div>
                             <span className="font-medium text-foreground">Desired Timeline</span>
                             <p className="text-muted-foreground">{caseDetails.timeline}</p>
                         </div>
                    </div>
                     {caseDetails.budget && (
                        <div className="flex items-start gap-3">
                            <DollarSign className="h-4 w-4 text-muted-foreground mt-1 flex-shrink-0" /> {/* Adjusted margin-top */}
                              <div>
                                 <span className="font-medium text-foreground">Estimated Budget</span>
                                 <p className="text-muted-foreground">{caseDetails.budget}</p>
                             </div>
                        </div>
                     )}
                     {/* Privacy setting can be shown if needed */}
                     {/* <div className="flex items-center gap-2">...</div> */}
                </div>
            </section>
        </CardContent>
      </Card>


       {/* Client View: Show Proposals Received */}
        <Card>
             <CardHeader>
                 <CardTitle className="text-xl font-semibold">Proposals Received ({caseDetails.proposals?.length || 0})</CardTitle> {/* Slightly smaller title */}
                 <CardDescription>Review proposals submitted by interested lawyers.</CardDescription>
             </CardHeader>
             <CardContent className="space-y-6"> {/* Added space-y-6 */}
                 {caseDetails.proposals && caseDetails.proposals.length > 0 ? (
                     <>
                         {caseDetails.proposals
                            .sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()) // Show newest first
                            .map(proposal => (
                            <ProposalCardClientView
                                key={proposal.id}
                                proposal={proposal}
                                caseStatus={caseDetails.status}
                                onAccept={handleAcceptProposal}
                                onReject={handleRejectProposal}
                            />
                         ))}
                     </>
                 ) : (
                     <p className="text-muted-foreground text-center py-10">No proposals received yet.</p>
                 )}
             </CardContent>
         </Card>

         {/* Message for Closed/In Progress Cases */}
         {caseDetails.status !== 'open' && (
            <Card className={cn(
                 "border-l-4",
                 caseDetails.status === 'in_progress' ? 'border-secondary bg-secondary/10' : 'border-border bg-muted/10' // Use secondary for in_progress, muted/border for closed
             )}>
                 <CardHeader className="flex flex-row items-center gap-3 py-4">
                    <AlertCircle className={cn("h-5 w-5", caseDetails.status === 'in_progress' ? 'text-secondary' : 'text-muted-foreground')} />
                    <CardTitle className={cn("text-base font-semibold", caseDetails.status === 'in_progress' ? 'text-secondary-foreground/90' : 'text-muted-foreground')}> {/* Adjusted text color */}
                        Case Status: {caseDetails.status.replace('_', ' ')}
                    </CardTitle>
                 </CardHeader>
                 <CardContent className="pb-4 pl-12">
                      <p className={cn("text-sm", caseDetails.status === 'in_progress' ? 'text-secondary-foreground/90' : 'text-muted-foreground')}>
                         {caseDetails.status === 'in_progress'
                            ? "You have accepted a proposal for this case. You can communicate with the lawyer via messages."
                            : "This case has been closed."
                         }
                     </p>
                 </CardContent>
             </Card>
         )}
    </div>
  );
}


interface ProposalCardClientViewProps {
    proposal: Proposal;
    caseStatus: 'open' | 'closed' | 'in_progress';
    onAccept: (proposalId: string) => void;
    onReject: (proposalId: string) => void;
}

function ProposalCardClientView({ proposal, caseStatus, onAccept, onReject }: ProposalCardClientViewProps) {
    // Assume users list is available via hook for lawyer details (inefficient, needs optimization later)
    const [users] = useLocalStorage<User[]>('users', []); // Use User type
    const lawyer = users.find(u => u.id === proposal.lawyerId);
    const isDecisionMade = proposal.status === 'accepted' || proposal.status === 'rejected';
    const canDecide = caseStatus === 'open' && proposal.status === 'submitted';

    return (
        <Card className={cn(
            "relative overflow-hidden transition-shadow duration-300 hover:shadow-lg", // Changed duration
            proposal.status === 'accepted' ? 'bg-primary/10 border-primary/40' : // Adjusted border opacity
            proposal.status === 'rejected' ? 'bg-destructive/10 border-destructive/40 opacity-80' : // Adjusted border opacity and opacity
            'bg-card/80 border border-border/30' // Default state with subtle border
        )}>
             {/* Accepted/Rejected Banner */}
             {isDecisionMade && (
                 <div className={cn(
                     "absolute top-0 left-0 right-0 py-1 px-4 text-xs font-semibold text-center tracking-wider", // Added tracking-wider
                     proposal.status === 'accepted' ? 'bg-primary text-primary-foreground' : 'bg-destructive text-destructive-foreground'
                 )}>
                     {proposal.status.toUpperCase()}
                 </div>
             )}
             <CardHeader className={cn(
                 "flex flex-col sm:flex-row items-start gap-4",
                  isDecisionMade ? 'pt-10' : 'pt-6' // Add padding top if banner is shown
                 )}>
                  <Avatar className="h-12 w-12 border-2 border-muted flex-shrink-0"> {/* Slightly larger border */}
                     <AvatarImage src={lawyer?.profilePicUrl || `https://picsum.photos/seed/${lawyer?.id}/48/48`} alt={proposal.lawyerName} data-ai-hint="lawyer portrait professional"/>
                     <AvatarFallback>{proposal.lawyerName?.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                  </Avatar>
                <div className="flex-grow">
                     <Link href={`/profile/${lawyer?.id}`} className="font-semibold hover:underline text-lg text-foreground">{proposal.lawyerName}</Link> {/* Ensured text-foreground */}
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground mt-1"> {/* Use flex-wrap */}
                         <span>Submitted: {format(new Date(proposal.timestamp), 'PPp')}</span>
                         {lawyer?.isVerified && <Badge variant="secondary" className="text-xs font-normal py-0.5 px-2"><ShieldCheck className="h-3 w-3 mr-1"/> Verified</Badge>} {/* Adjusted padding */}
                      </div>
                 </div>
             </CardHeader>
             <CardContent className="space-y-4 pt-0"> {/* Removed pt-0 */}
                  <Separator />
                 <blockquote className="text-sm italic border-l-4 pl-4 border-accent ml-1 text-muted-foreground"> {/* Use blockquote for semantics */}
                     "{proposal.coverLetter}"
                 </blockquote>
                 <div className="text-sm grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 pt-3 border-t border-dashed border-border/50"> {/* Adjusted grid gap */}
                     <div className="flex items-center gap-2">
                         <DollarSign className="h-4 w-4 text-muted-foreground flex-shrink-0" /> {/* Added flex-shrink-0 */}
                         <div>
                             <span className="text-xs text-muted-foreground">Proposed Fee:</span>
                             <p className="font-medium text-foreground">{proposal.proposedFee}</p>
                         </div>
                     </div>
                      <div className="flex items-center gap-2">
                         <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0" /> {/* Added flex-shrink-0 */}
                          <div>
                             <span className="text-xs text-muted-foreground">Estimated Timeline:</span>
                             <p className="font-medium text-foreground">{proposal.estimatedTimeline}</p>
                         </div>
                     </div>
                 </div>
            </CardContent>
             <CardFooter className="flex flex-col sm:flex-row justify-end gap-3 bg-muted/20 p-4 border-t border-border/30"> {/* Slightly different background */}
                <Link href={`/messages?recipient=${proposal.lawyerId}`} passHref legacyBehavior>
                    <Button variant="outline" size="sm" className="w-full sm:w-auto"> {/* Full width on small screens */}
                        <MessageSquare className="w-4 h-4 mr-2"/> Message Lawyer
                    </Button>
                </Link>
                <div className="flex gap-3 w-full sm:w-auto"> {/* Container for decision buttons */}
                    {canDecide && (
                        <>
                            <Button variant="destructive" size="sm" onClick={() => onReject(proposal.id)} className="flex-1 sm:flex-none">Reject</Button> {/* flex-1 on small */}
                            <Button size="sm" onClick={() => onAccept(proposal.id)} className="bg-primary hover:bg-primary/90 flex-1 sm:flex-none">Accept Proposal</Button> {/* flex-1 on small */}
                        </>
                    )}
                    {/* Show disabled buttons if already decided */}
                    {isDecisionMade && (
                        <>
                            <Button variant="destructive" size="sm" disabled className="flex-1 sm:flex-none">{proposal.status === 'rejected' ? 'Rejected' : 'Reject'}</Button> {/* flex-1 on small */}
                            <Button size="sm" disabled className={cn("flex-1 sm:flex-none", proposal.status === 'accepted' ? 'bg-primary opacity-50' : '')}>{proposal.status === 'accepted' ? 'Accepted' : 'Accept Proposal'}</Button> {/* flex-1 on small */}
                        </>
                    )}
                </div>
            </CardFooter>
        </Card>
    );
}

