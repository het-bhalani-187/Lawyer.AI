

"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlusCircle } from 'lucide-react';
import useLocalStorage from '@/hooks/useLocalStorage';
import { formatDistanceToNow } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import DashboardLayout from '@/components/layout/DashboardLayout'; // Import the DashboardLayout

type User = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
  firstName?: string;
  lastName?: string;
};

type Case = {
    id: string;
    clientId: string;
    clientName: string;
    title: string;
    expertise: string;
    postedDate: string; // ISO string
    status: 'open' | 'closed' | 'in_progress';
    description: string;
};


export default function MyCasesPage() {
  const [currentUser] = useLocalStorage<User | null>('user', null);
  const [cases] = useLocalStorage<Case[]>('cases', []);
  const router = useRouter();
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    if (!currentUser) {
      toast({ title: "Access Denied", description: "Please log in to view your cases.", variant: "destructive" });
      router.push('/login');
    } else if (currentUser.role !== 'client') {
      toast({ title: "Access Denied", description: "Only clients can view 'My Cases'.", variant: "destructive" });
      router.push('/dashboard');
    } else {
        setIsClient(true);
    }
  }, [currentUser, router, toast]);

   const userCases = currentUser?.role === 'client'
        ? cases.filter(c => c.clientId === currentUser.id).sort((a, b) => new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime()) // Sort by most recent
        : [];

   // Show loading within the layout
   if (!isClient) {
     return <DashboardLayout><div className="text-center py-12">Loading access...</div></DashboardLayout>;
   }


  return (
    // Wrap the page content with DashboardLayout
    <DashboardLayout>
       <div className="space-y-8">
         <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
             <div>
                 <h1 className="text-3xl font-bold text-foreground">My Posted Cases</h1>
                 <p className="text-muted-foreground">Manage the cases you have posted.</p>
             </div>
             <Button asChild size="sm">
                 <Link href="/post-case"><PlusCircle className="w-4 h-4 mr-2"/> Post New Case</Link>
             </Button>
         </div>

        <Card>
             {/* Removed redundant header, title is above now */}
             <CardContent className="pt-6"> {/* Add padding-top */}
                 {userCases.length > 0 ? (
                     <div className="space-y-4">
                         {userCases.map(caseItem => (
                             <MyCaseListItem key={caseItem.id} caseItem={caseItem} />
                         ))}
                     </div>
                 ) : (
                     <p className="text-muted-foreground text-center py-16">You haven't posted any cases yet.</p>
                 )}
             </CardContent>
         </Card>
       </div>
    </DashboardLayout>
  );
}


interface MyCaseListItemProps {
    caseItem: Case;
}

function MyCaseListItem({ caseItem }: MyCaseListItemProps) {
   const [timeAgo, setTimeAgo] = useState('');

    // Calculate timeAgo on the client side to avoid hydration mismatch
    useEffect(() => {
        setTimeAgo(formatDistanceToNow(new Date(caseItem.postedDate), { addSuffix: true }));
    }, [caseItem.postedDate]);

    const linkHref = `/my-case/${caseItem.id}`;

     return (
         <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 border rounded-md hover:bg-muted/50 gap-4">
            <div className="space-y-1 overflow-hidden mr-4 flex-grow">
                <Link href={linkHref} className="font-medium hover:underline text-base block">{caseItem.title}</Link>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span>Expertise: {caseItem.expertise}</span>
                    <span>Posted: {timeAgo || 'recently'}</span>
                </div>
            </div>
             <div className="flex items-center gap-2 flex-shrink-0">
                <Badge variant={caseItem.status === 'open' ? 'default' : caseItem.status === 'in_progress' ? 'secondary' : 'outline'} className="capitalize">
                    {caseItem.status.replace('_', ' ')}
                </Badge>
                 <Button variant="outline" size="sm" asChild>
                     <Link href={linkHref}>View Details</Link>
                 </Button>
             </div>
         </div>
     );
}
