
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { FileQuestion } from 'lucide-react'


export default function NotFound() {
  return (
     <div className="container mx-auto py-12 flex items-center justify-center min-h-[calc(100vh-15rem)]">
       <Card className="max-w-lg w-full text-center">
            <CardHeader>
                 <div className="mx-auto bg-secondary/10 p-3 rounded-full w-fit border">
                    <FileQuestion className="h-10 w-10 text-secondary" />
                 </div>
                 <CardTitle className="mt-4">Page Not Found</CardTitle>
                 <CardDescription>
                     Oops! The page you're looking for doesn't seem to exist.
                 </CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground mb-6">
                    Let's get you back on track.
                </p>
                 <Button asChild>
                    <Link href="/">Return Home</Link>
                 </Button>
            </CardContent>
       </Card>
    </div>
  )
}
