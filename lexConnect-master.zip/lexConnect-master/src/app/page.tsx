
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, Search, MessageSquare, UserCheck, FileText, ShieldCheck, Zap, ArrowRight } from "lucide-react";
import Link from 'next/link';
import Image from 'next/image';
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from 'react';
import ScrollFadeIn from '@/components/animation/ScrollFadeIn'; // Import the animation component

// Updated AnimatedText component for typing effect
const AnimatedText = ({ texts, typingSpeed = 100, deletingSpeed = 50, pauseDuration = 2000 }: { texts: string[], typingSpeed?: number, deletingSpeed?: number, pauseDuration?: number }) => {
  const [textIndex, setTextIndex] = useState(0);
  const [subIndex, setSubIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [displayText, setDisplayText] = useState('');

  useEffect(() => {
    if (subIndex === texts[textIndex].length + 1 && !isDeleting) {
      // Pause at the end of typing
      const timer = setTimeout(() => {
        setIsDeleting(true);
      }, pauseDuration);
      return () => clearTimeout(timer);
    } else if (subIndex === 0 && isDeleting) {
      // Finished deleting, switch to next text
      setIsDeleting(false);
      setTextIndex((prevIndex) => (prevIndex + 1) % texts.length);
      const timer = setTimeout(() => {
         // Optional small pause before typing next word
      }, 200); // Short pause before next word starts typing
       return () => clearTimeout(timer);
    }

    const timeout = setTimeout(() => {
      setSubIndex((prevSubIndex) => prevSubIndex + (isDeleting ? -1 : 1));
    }, isDeleting ? deletingSpeed : typingSpeed);

    return () => clearTimeout(timeout);
  }, [subIndex, isDeleting, textIndex, texts, typingSpeed, deletingSpeed, pauseDuration]);

  useEffect(() => {
    // Update display text based on subIndex
    setDisplayText(texts[textIndex].substring(0, subIndex));
  }, [subIndex, textIndex, texts]);


  return (
    <span className="whitespace-nowrap">
      {displayText}
      <span className="inline-block w-1 h-5 md:h-6 lg:h-7 bg-current animate-blink ml-1 align-bottom"></span> {/* Cursor */}
    </span>
  );
};


export default function Home() {
   const textOptions = ["Find Your Legal Professional", "Find Your Client"];

  return (
    <div className="space-y-20 md:space-y-28 lg:space-y-32 overflow-x-hidden"> {/* Increased spacing */}

      {/* Hero Section - Enhanced */}
      <section className="relative text-center pt-24 pb-16 md:pt-32 md:pb-24 lg:pt-40 lg:pb-32 overflow-hidden">
         {/* Background Gradient/Image */}
         <div className="absolute inset-0 z-[-1]">
            <Image
               src="https://picsum.photos/seed/lexhero/1920/1080" // Larger, more impactful placeholder
               alt="Abstract legal background"
               data-ai-hint="abstract legal background modern technology"
               layout="fill"
               objectFit="cover"
               quality={80}
               className="opacity-15" // Reduced opacity for subtlety
               priority // Prioritize loading hero image
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background"></div> {/* Gradient overlay */}
         </div>

        <div className="container mx-auto px-4 relative z-10">
          {/* Added Badge */}
           <Badge variant="outline" className="mb-4 text-sm font-medium py-1 px-3 border-primary/30 bg-primary/10 text-primary">
               Connecting Clients & Lawyers
           </Badge>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6 text-foreground leading-tight min-h-[4rem] md:min-h-[5rem] lg:min-h-[6rem] flex items-center justify-center"> {/* Added min-height and flex for alignment */}
             <AnimatedText texts={textOptions} />
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-10"> {/* Increased bottom margin */}
             LexConnect is the modern platform linking clients with verified legal professionals. Find the right lawyer or discover new cases tailored to your expertise.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4"> {/* Added items-center */}
            <Button size="lg" asChild className="group transition-transform duration-300 hover:scale-105 shadow-lg">
              <Link href="/register?role=client">
                  I Need a Lawyer <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button size="lg" variant="secondary" asChild className="transition-transform duration-300 hover:scale-105 shadow-lg">
               <Link href="/register?role=lawyer">I Am a Lawyer</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section - Updated Cards */}
      <section className="container mx-auto px-4">
        <ScrollFadeIn> {/* Wrap section title for animation */}
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Why Choose LexConnect?</h2> {/* Increased bottom margin */}
        </ScrollFadeIn>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ScrollFadeIn delay={100}> {/* Add animation wrapper with delay */}
            <FeatureCard
              icon={ShieldCheck} // Changed icon
              title="Verified Professionals"
              description="Connect confidently with lawyers whose credentials and bar status are thoroughly checked."
            />
          </ScrollFadeIn>
          <ScrollFadeIn delay={200}> {/* Add animation wrapper with delay */}
            <FeatureCard
              icon={Search}
              title="Targeted Matching"
              description="Clients find lawyers by specialization and budget. Lawyers find cases aligned with their expertise."
            />
          </ScrollFadeIn>
          <ScrollFadeIn delay={300}> {/* Add animation wrapper with delay */}
            <FeatureCard
              icon={Zap} // Changed icon
              title="Efficient Workflow"
              description="Clients easily post case details. Lawyers manage proposals and case progress seamlessly."
            />
          </ScrollFadeIn>
          <ScrollFadeIn delay={400}> {/* Add animation wrapper with delay */}
           <FeatureCard
            icon={MessageSquare}
            title="Secure Communication"
            description="End-to-end encrypted messaging ensures confidential conversations within the platform."
           />
          </ScrollFadeIn>
          <ScrollFadeIn delay={500}> {/* Add animation wrapper with delay */}
           <FeatureCard
            icon={FileText}
            title="Streamlined Case Management"
            description="Manage proposals, documents, and communication history all in one organized place."
           />
          </ScrollFadeIn>
          <ScrollFadeIn delay={600}> {/* Add animation wrapper with delay */}
           <FeatureCard
            icon={UserCheck} // Changed icon
            title="Trust & Transparency"
            description="Built with privacy at its core. Clear processes foster trust between clients and lawyers."
           />
          </ScrollFadeIn>
        </div>
      </section>

       {/* How It Works Section - Enhanced */}
       <section className="container mx-auto px-4 text-center py-16 md:py-20">
         <ScrollFadeIn> {/* Wrap section title for animation */}
            <h2 className="text-3xl md:text-4xl font-bold mb-16">Simple Steps to Success</h2> {/* Changed title, increased margin */}
         </ScrollFadeIn>
         <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-start">
           {/* For Clients */}
           <ScrollFadeIn delay={200}> {/* Add animation wrapper with delay */}
             <Card className="text-left bg-gradient-to-br from-card via-card to-secondary/10 border border-border/30 shadow-lg transition-all duration-300 hover:shadow-primary/20 hover:border-primary/50"> {/* Gradient background */}
               <CardHeader>
                 <CardTitle className="flex items-center gap-3 text-xl font-semibold text-foreground"> {/* Adjusted size/weight */}
                     <div className="p-2 bg-primary/10 rounded-md text-primary"><UserCheck className="w-6 h-6" /></div>
                     For Clients
                 </CardTitle>
               </CardHeader>
               <CardContent className="space-y-6 pl-10 pr-6 pb-6"> {/* Adjusted padding */}
                 <HowItWorksStep number="1" title="Post Your Case">Describe your legal issue, needs, and budget securely.</HowItWorksStep>
                 <HowItWorksStep number="2" title="Receive Proposals">Verified lawyers interested in your case submit tailored proposals.</HowItWorksStep>
                 <HowItWorksStep number="3" title="Hire & Collaborate">Compare options, hire the best fit, and manage your case.</HowItWorksStep>
                   <Button className="mt-6 w-full" asChild>
                       <Link href="/post-case">Get Started Now</Link>
                   </Button>
               </CardContent>
             </Card>
           </ScrollFadeIn>

           {/* For Lawyers */}
           <ScrollFadeIn delay={400}> {/* Add animation wrapper with delay */}
             <Card className="text-left bg-gradient-to-br from-card via-card to-primary/10 border border-border/30 shadow-lg transition-all duration-300 hover:shadow-secondary/20 hover:border-secondary/50"> {/* Gradient background */}
               <CardHeader>
                 <CardTitle className="flex items-center gap-3 text-xl font-semibold text-foreground">
                     <div className="p-2 bg-secondary/10 rounded-md text-secondary"><Briefcase className="w-6 h-6"/></div>
                     For Lawyers
                 </CardTitle>
               </CardHeader>
               <CardContent className="space-y-6 pl-10 pr-6 pb-6"> {/* Adjusted padding */}
                  <HowItWorksStep number="1" title="Build Your Profile">Showcase your expertise, credentials, and experience.</HowItWorksStep>
                  <HowItWorksStep number="2" title="Find Relevant Cases">Browse opportunities matching your practice areas.</HowItWorksStep>
                  <HowItWorksStep number="3" title="Connect & Grow">Submit proposals and connect with potential clients.</HowItWorksStep>
                 <Button variant="secondary" className="mt-6 w-full" asChild>
                     <Link href="/browse-cases">Find Cases</Link>
                 </Button>
               </CardContent>
             </Card>
           </ScrollFadeIn>
         </div>
       </section>

       {/* Call to Action Section - Improved */}
      <section className="relative py-16 md:py-24 bg-gradient-to-r from-primary via-teal-600 to-secondary text-center text-primary-foreground overflow-hidden">
          <div className="absolute inset-0 opacity-20 mix-blend-overlay" style={{ backgroundImage: 'url(/circuit-board.svg)' }}></div> {/* Optional pattern */}
         <div className="container mx-auto px-4 relative z-10">
           <ScrollFadeIn> {/* Wrap CTA content */}
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Transform Your Legal Experience?</h2>
              <p className="text-lg text-primary-foreground/80 mb-8 max-w-xl mx-auto">
                  Join LexConnect today. Clients find expert help, lawyers find new opportunities. It's that simple.
              </p>
              <Button size="lg" variant="outline" className="bg-background/10 text-primary-foreground border-primary-foreground/50 hover:bg-background/20 hover:text-primary-foreground hover:border-primary-foreground transition-all duration-300 shadow-xl" asChild>
                  <Link href="/register">Register Now for Free</Link>
              </Button>
            </ScrollFadeIn>
         </div>
      </section>
    </div>
  );
}


interface FeatureCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
}

// Updated FeatureCard Styling
function FeatureCard({ icon: Icon, title, description }: FeatureCardProps) {
  return (
    <Card className="text-center p-6 md:p-8 bg-card/60 backdrop-blur-sm border border-border/30 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col items-center h-full"> {/* Added h-full */}
      <div className="p-4 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 text-primary mb-5 border border-primary/20 inline-block shadow-inner">
        <Icon className="h-8 w-8" />
      </div>
      <CardTitle className="text-xl mb-3">{title}</CardTitle>
      <CardContent className="p-0 flex-grow"> {/* Removed padding */}
        <p className="text-muted-foreground text-sm leading-relaxed">{description}</p> {/* Adjusted line height */}
      </CardContent>
    </Card>
  );
}

// New HowItWorksStep Component
interface HowItWorksStepProps {
    number: string;
    title: string;
    children: React.ReactNode;
}

function HowItWorksStep({ number, title, children }: HowItWorksStepProps) {
    return (
        <div className="flex items-start gap-4 relative">
            <div className="flex-shrink-0 z-10 w-8 h-8 mt-1 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold border-2 border-background shadow">
                {number}
            </div>
            {/* Dashed line connecting steps */}
            {number !== '3' && <div className="absolute left-4 top-10 bottom-0 w-px border-l-2 border-dashed border-border/50 z-0"></div>}
            <div className="flex-grow">
                <h4 className="font-semibold text-foreground mb-1">{title}</h4>
                <p className="text-sm text-muted-foreground">{children}</p>
            </div>
        </div>
    );
}
