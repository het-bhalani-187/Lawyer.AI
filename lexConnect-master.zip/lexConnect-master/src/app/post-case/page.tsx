
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import useLocalStorage from '@/hooks/useLocalStorage'; // Import the hook
import DashboardLayout from '@/components/layout/DashboardLayout'; // Import the DashboardLayout
import { FileText, DollarSign, Clock, Lock, Unlock, Briefcase } from 'lucide-react'; // Added icons
import { cn } from "@/lib/utils"; // Import cn utility

const caseSchema = z.object({
  title: z.string().min(5, { message: "Case title must be at least 5 characters." }).max(100, { message: "Title cannot exceed 100 characters."}),
  description: z.string().min(20, { message: "Please provide a detailed description (at least 20 characters)." }).max(2000, { message: "Description cannot exceed 2000 characters."}),
  expertise: z.string({ required_error: "Please select the required legal expertise." }),
  budget: z.string().optional(), // Making budget optional for now
  timeline: z.string({ required_error: "Please select the urgency." }),
  // Force privacy to public as private is disabled
  privacy: z.enum(["public", "private"], { required_error: "Please select a privacy setting." }).default("public").refine(val => val === "public", { message: "Private option is currently disabled."}),
});

type CaseFormData = z.infer<typeof caseSchema>;

const legalExpertiseOptions = [
    "Family Law",
    "Corporate Law",
    "Criminal Law",
    "Real Estate Law",
    "Intellectual Property",
    "Personal Injury",
    "Immigration Law",
    "Bankruptcy Law",
    "Employment Law",
    "Other",
];

const timelineOptions = [
    "Urgent (within days)",
    "Standard (within weeks)",
    "Flexible (months)",
];

export default function PostCasePage() {
  const router = useRouter();
  const { toast } = useToast();
  const [cases, setCases] = useLocalStorage<any[]>('cases', []);
  const [currentUser, setCurrentUser] = useLocalStorage<any | null>('user', null);
  const [isClient, setIsClient] = useState(false);


   useEffect(() => {
    // Redirect if not logged in or not a client
    if (!currentUser) {
      toast({ title: "Access Denied", description: "Please log in to post a case.", variant: "destructive" });
      router.push('/login');
    } else if (currentUser.role !== 'client') {
      toast({ title: "Access Denied", description: "Only clients can post cases.", variant: "destructive" });
      router.push('/dashboard'); // Or appropriate lawyer dashboard
    } else {
       setIsClient(true);
    }
  }, [currentUser, router, toast]);


  const form = useForm<CaseFormData>({
    resolver: zodResolver(caseSchema),
    defaultValues: {
      title: "",
      description: "",
      expertise: undefined, // No default expertise
      budget: "",
      timeline: undefined, // No default timeline
      privacy: "public", // Default to public as private is disabled
    },
  });

  function onSubmit(values: CaseFormData) {
     if (!currentUser || currentUser.role !== 'client') return; // Ensure client role

     console.log("Submitting new case:", values);

     // Ensure privacy is 'public' regardless of form state (though schema validation should handle this)
     const finalValues = { ...values, privacy: 'public' as 'public' };


     const newCase = {
         id: Date.now().toString(), // Simple unique ID
         clientId: currentUser.id,
         // Ensure clientName is constructed correctly, handling potential undefined fields
         clientName: `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim() || 'Unknown Client',
         postedDate: new Date().toISOString(),
         status: 'open', // Initial status
         proposals: [], // To store lawyer proposals later
         ...finalValues,
     };

     const updatedCases = [...cases, newCase];
     setCases(updatedCases);

     console.log("Updated cases list:", updatedCases);

     toast({
      title: "Case Posted Successfully",
      description: `Your case "${values.title}" is now live.`,
     });

     router.push('/my-case'); // Redirect to client's case list
  }

   // Show loading within the layout
   if (!isClient) {
     return <DashboardLayout><div className="container mx-auto max-w-3xl py-12 text-center">Loading...</div></DashboardLayout>;
   }

  return (
    // Wrap the content with DashboardLayout
    <DashboardLayout>
        <div className="max-w-3xl mx-auto space-y-8"> {/* Slightly wider max-width */}
             <Card className="border-none shadow-none bg-transparent p-0"> {/* Remove Card border/shadow */}
                  <CardHeader className="px-1 pb-4"> {/* Adjust padding */}
                      <CardTitle className="text-3xl font-bold text-foreground flex items-center gap-2">
                         <FileText className="w-7 h-7 text-primary"/> Post a New Case
                      </CardTitle>
                      <CardDescription>Fill in the details below to connect with qualified lawyers.</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6"> {/* Add padding-top */}
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8"> {/* Increase spacing */}

                         {/* Case Title Card */}
                          <Card className="bg-card/50 p-6 shadow-sm">
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="text-base font-semibold text-card-foreground">Case Title</FormLabel> {/* Changed text color */}
                                    <FormControl>
                                    <Input placeholder="e.g., Need help with divorce proceedings" {...field} value={field.value ?? ""} className="h-11 text-base bg-background/80" />
                                    </FormControl>
                                    <FormDescription className="text-muted-foreground"> {/* Changed text color */}
                                    A brief, descriptive title for your case.
                                    </FormDescription>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                          </Card>

                        {/* Case Description Card */}
                          <Card className="bg-card/50 p-6 shadow-sm">
                          <FormField
                              control={form.control}
                              name="description"
                              render={({ field }) => (
                              <FormItem>
                                  <FormLabel className="text-base font-semibold">Case Description</FormLabel>
                                  <FormControl>
                                  <Textarea
                                      placeholder="Describe your legal situation in detail. Include relevant facts, desired outcomes, and any questions you have. The more detail, the better lawyers can assess your case."
                                      className="min-h-[180px] text-base bg-background/80" /* Increased min-height and adjusted background */
                                      {...field} value={field.value ?? ""}
                                  />
                                  </FormControl>
                                  <FormDescription>
                                      Be specific, but avoid sharing overly sensitive personal information initially.
                                  </FormDescription>
                                  <FormMessage />
                              </FormItem>
                              )}
                          />
                        </Card>

                         {/* Grouped Requirements */}
                         <div className="space-y-6 rounded-lg border bg-card/50 p-6 shadow-sm">
                            <h3 className="text-lg font-semibold mb-4 border-b pb-2">Case Requirements</h3>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6"> {/* Grid layout */}
                                 <FormField
                                    control={form.control}
                                    name="expertise"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel className="flex items-center gap-2"><Briefcase className="w-4 h-4"/> Required Legal Expertise</FormLabel>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                            <SelectTrigger className="h-11">
                                            <SelectValue placeholder="Select the area of law" />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {legalExpertiseOptions.map((option) => (
                                            <SelectItem key={option} value={option}>
                                                {option}
                                            </SelectItem>
                                            ))}
                                        </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="timeline"
                                    render={({ field }) => (
                                    <FormItem>
                                        <FormLabel className="flex items-center gap-2"><Clock className="w-4 h-4"/> Urgency / Timeline</FormLabel>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                            <SelectTrigger className="h-11">
                                            <SelectValue placeholder="Select how soon you need assistance" />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {timelineOptions.map((option) => (
                                            <SelectItem key={option} value={option}>
                                                {option}
                                            </SelectItem>
                                            ))}
                                        </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                    )}
                                />
                             </div>

                             <FormField
                                control={form.control}
                                name="budget"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="flex items-center gap-2"><DollarSign className="w-4 h-4"/> Budget Range <span className="text-xs text-muted-foreground">(Optional)</span></FormLabel>
                                    <FormControl>
                                    <Input placeholder="e.g., $1,000 - $5,000, or Fixed Fee" {...field} value={field.value ?? ""} className="h-11" />
                                    </FormControl>
                                    <FormDescription>
                                    Provide an estimated budget if you have one. This helps lawyers gauge feasibility.
                                    </FormDescription>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                         </div>


                        <FormField
                            control={form.control}
                            name="privacy"
                            render={({ field }) => (
                            <FormItem className="space-y-4 rounded-lg border border-transparent p-6 shadow-none"> {/* Style like requirements box, but transparent */}
                                <FormLabel className="text-lg font-semibold flex items-center gap-2 border-b pb-2">
                                    {/* Dynamically show icon based on selected value (should always be public now) */}
                                    {field.value === 'public' ? <Unlock className="w-5 h-5 text-green-500"/> : <Lock className="w-5 h-5 text-orange-500"/>}
                                     Case Privacy Setting
                                </FormLabel>
                                <FormControl>
                                <RadioGroup
                                    onValueChange={field.onChange}
                                    defaultValue={field.value}
                                    className="flex flex-col sm:flex-row gap-4 pt-2" // Adjusted layout
                                >
                                    <FormItem className="flex items-start space-x-3 space-y-0 p-4 border rounded-md flex-1 hover:bg-muted/50 transition-colors cursor-pointer has-[:checked]:border-primary has-[:checked]:bg-primary/10">
                                        <FormControl>
                                            <RadioGroupItem value="public" id="privacy-public"/>
                                        </FormControl>
                                        <div className="space-y-1 leading-none">
                                            <FormLabel htmlFor='privacy-public' className="font-medium flex items-center gap-1 cursor-pointer">
                                                <Unlock className="w-4 h-4"/> Public
                                            </FormLabel>
                                            <FormDescription className="text-xs">
                                                 Allows any verified lawyer on the platform to view your case details and submit proposals.
                                            </FormDescription>
                                        </div>
                                    </FormItem>
                                     <FormItem className={cn(
                                         "flex items-start space-x-3 space-y-0 p-4 border rounded-md flex-1 transition-colors",
                                         "opacity-50 cursor-not-allowed bg-muted/30" // Disabled styles
                                     )}>
                                        <FormControl>
                                            {/* Add disabled attribute */}
                                            <RadioGroupItem value="private" id="privacy-private" disabled />
                                        </FormControl>
                                         <div className="space-y-1 leading-none">
                                            {/* Add disabled style to label */}
                                            <FormLabel htmlFor='privacy-private' className="font-medium flex items-center gap-1 cursor-not-allowed text-muted-foreground">
                                                 <Lock className="w-4 h-4"/> Private
                                            </FormLabel>
                                             <FormDescription className="text-xs">
                                                 (Coming Soon) This option is currently disabled. Cases are posted as Public.
                                            </FormDescription>
                                         </div>
                                    </FormItem>
                                </RadioGroup>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />

                        <Button type="submit" size="lg" className="w-full text-lg py-6 bg-secondary text-secondary-foreground hover:bg-secondary/90">Post Case</Button> {/* Changed variant to secondary */}
                        </form>
                    </Form>
                    </CardContent>
                </Card>
        </div>
    </DashboardLayout>
  );
}
