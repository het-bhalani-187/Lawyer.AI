
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PrivacyPolicyPage() {
  return (
    <div className="container mx-auto max-w-3xl py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Privacy Policy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-muted-foreground">
          <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

          <p>Welcome to LexConnect ("we," "us," or "our"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform.</p>

          <h2 className="font-semibold text-lg pt-4 text-foreground">1. Information We Collect</h2>
          <p>We may collect personal information such as your name, email address, contact details, professional credentials (for lawyers), case details (for clients), payment information (when implemented), and usage data.</p>

          <h2 className="font-semibold text-lg pt-4 text-foreground">2. How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul className="list-disc list-inside ml-4 space-y-1">
            <li>Provide, operate, and maintain our platform.</li>
            <li>Facilitate connections between clients and lawyers.</li>
            <li>Process transactions (when implemented).</li>
            <li>Improve, personalize, and expand our platform.</li>
            <li>Communicate with you, including for customer service and updates.</li>
            <li>Verify lawyer credentials.</li>
            <li>Ensure security and prevent fraud.</li>
            <li>Comply with legal obligations.</li>
          </ul>

          <h2 className="font-semibold text-lg pt-4 text-foreground">3. Information Sharing and Disclosure</h2>
          <p>We do not sell your personal information. We may share information:</p>
           <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Between clients and lawyers as necessary to facilitate consultations and case handling (e.g., case details shared with lawyers who view/propose).</li>
              <li>With third-party service providers for functions like payment processing, data storage, and analytics (under confidentiality agreements).</li>
              <li>If required by law or to protect our rights and safety or the rights and safety of others.</li>
          </ul>

           <h2 className="font-semibold text-lg pt-4 text-foreground">4. Data Security</h2>
           <p>We implement reasonable security measures (like encryption for messages - planned) to protect your information. However, no system is completely secure.</p>
            {/* Placeholder using localStorage */}
            <p className="text-orange-500 font-medium mt-2">Note: Currently, data including user details, cases, and messages is stored in your browser's localStorage. This is for demonstration purposes only and is not secure for sensitive information in a production environment. Do not enter real sensitive data.</p>


          <h2 className="font-semibold text-lg pt-4 text-foreground">5. Your Choices</h2>
          <p>You can review and update your profile information. You may also request deletion of your account, subject to legal and operational requirements.</p>


          <h2 className="font-semibold text-lg pt-4 text-foreground">6. Changes to This Policy</h2>
          <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page.</p>

          <h2 className="font-semibold text-lg pt-4 text-foreground">7. Contact Us</h2>
           <p>If you have any questions about this Privacy Policy, please contact us at [Placeholder Contact Email/Link].</p>
        </CardContent>
      </Card>
    </div>
  );
}
