
"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { User, Mail, Briefcase, Award, MessageSquare, ShieldCheck, MapPin, Star } from 'lucide-react';
import useLocalStorage from '@/hooks/useLocalStorage';
import Link from 'next/link';

// Reusing the UserProfile type, assuming it contains necessary fields
type UserProfile = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
  firstName?: string; // Client
  lastName?: string; // Client
  fullName?: string; // Lawyer
  specialization?: string; // Lawyer
  barNumber?: string; // Lawyer
  isVerified?: boolean; // Lawyer
  bio?: string;
  location?: string;
  profilePicUrl?: string;
  rating?: number; // Added rating
   // Add more fields like portfolio, reviews, availability etc.
};

export default function PublicProfilePage() {
  const params = useParams();
  const router = useRouter();
  const userId = params.id as string;

  const [users] = useLocalStorage<UserProfile[]>('users', []);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);


  useEffect(() => {
    const foundUser = users.find(u => u.id === userId);
    if (foundUser && foundUser.role === 'lawyer') { // Only show lawyer public profiles for now
      setProfile(foundUser);
    } else {
      // Handle profile not found or not a lawyer - maybe redirect or show error
       // Avoid toast on initial load if checking, only if definitively not found/not lawyer
       // console.warn("Profile not found or user is not a lawyer.");
       // router.push('/find-lawyer'); // Optionally redirect
    }
     setIsLoading(false);
  }, [userId, users, router]);

  if (isLoading) {
     return <div className="container mx-auto py-12 text-center">Loading profile...</div>;
  }

  if (!profile) {
    return (
        <div className="container mx-auto max-w-4xl py-12 text-center">
             <Card>
                 <CardHeader>
                     <CardTitle>Profile Not Found</CardTitle>
                 </CardHeader>
                 <CardContent>
                     <p className="text-muted-foreground mb-4">The requested lawyer profile could not be found.</p>
                     <Button asChild>
                        <Link href="/find-lawyer">Back to Lawyer Search</Link>
                     </Button>
                 </CardContent>
             </Card>
        </div>
    );
  }

   // This should always be true based on the useEffect filter, but good for type safety
   if (profile.role !== 'lawyer') return null;


  const displayName = profile.fullName;
  const initial = displayName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'L';

  return (
    <div className="container mx-auto max-w-4xl py-12">
      <Card className="overflow-hidden">
          {/* Profile Header */}
         <div className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 p-8 relative">
             <div className="flex flex-col md:flex-row items-center gap-6">
                 <Avatar className="h-24 w-24 md:h-32 md:w-32 border-4 border-background shadow-lg">
                    <AvatarImage src={profile.profilePicUrl || `https://picsum.photos/seed/${profile.id}/128/128`} alt={displayName} data-ai-hint="lawyer portrait professional headshot"/>
                    <AvatarFallback className="text-4xl">{initial}</AvatarFallback>
                 </Avatar>
                 <div className="text-center md:text-left flex-grow">
                     <h1 className="text-3xl md:text-4xl font-bold mb-1">{displayName}</h1>
                     {profile.specialization && (
                         <p className="text-lg text-muted-foreground capitalize flex items-center justify-center md:justify-start gap-2">
                             <Briefcase className="h-5 w-5"/> {profile.specialization}
                         </p>
                     )}
                     {profile.location && (
                         <p className="text-sm text-muted-foreground capitalize flex items-center justify-center md:justify-start gap-2 mt-1">
                             <MapPin className="h-4 w-4"/> {profile.location}
                         </p>
                     )}
                     <div className="mt-3 flex flex-wrap gap-2 justify-center md:justify-start">
                         {profile.isVerified && (
                             <Badge variant="default" className="text-sm bg-green-600 hover:bg-green-700">
                                 <ShieldCheck className="h-3 w-3 mr-1"/> Verified
                             </Badge>
                         )}
                         {/* Placeholder Rating */}
                         {profile.rating !== undefined && (
                             <div className="flex items-center gap-1 bg-background/50 px-2 py-1 rounded-full border text-xs">
                                 <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                                 <span>{profile.rating.toFixed(1)}</span>
                                  <span className="text-muted-foreground ml-1">(placeholder)</span>
                             </div>
                         )}
                     </div>
                 </div>
                  <Button asChild className="mt-4 md:mt-0 md:ml-auto">
                     <Link href={`/messages?recipient=${profile.id}`}>
                        <MessageSquare className="h-4 w-4 mr-2"/> Contact Lawyer
                     </Link>
                 </Button>
             </div>
         </div>

          {/* Profile Details */}
        <CardContent className="p-6 md:p-8 space-y-6">
             {/* About Section */}
             <section>
                <h2 className="text-xl font-semibold mb-3 border-b pb-2">About {displayName}</h2>
                 <p className="text-muted-foreground whitespace-pre-wrap">
                     {profile.bio || `Experienced ${profile.specialization || 'legal professional'} dedicated to achieving the best outcomes for clients. Specializing in various aspects of ${profile.specialization || 'law'}. Contact for a consultation regarding your legal needs.`}
                 </p>
            </section>

             {/* Credentials */}
              <section>
                    <h2 className="text-xl font-semibold mb-3 border-b pb-2">Credentials & Expertise</h2>
                     <div className="space-y-2 text-sm">
                         {profile.specialization && (
                             <div className="flex items-start gap-3">
                                <Briefcase className="h-4 w-4 text-muted-foreground mt-1 flex-shrink-0" />
                                 <div>
                                     <span className="font-medium">Primary Specialization:</span>
                                     <p>{profile.specialization}</p>
                                 </div>
                             </div>
                         )}
                          {profile.barNumber && (
                             <div className="flex items-start gap-3">
                                <Award className="h-4 w-4 text-muted-foreground mt-1 flex-shrink-0" />
                                <div>
                                     <span className="font-medium">Bar Admission:</span>
                                      <p>Number {profile.barNumber} {profile.isVerified ? <span className="text-green-600">(Verified)</span> : <span className="text-orange-500">(Verification Pending)</span>}</p>
                                      {/* Add Bar State/Jurisdiction later */}
                                </div>

                             </div>
                         )}
                         {/* Add Education, Experience, Publications later */}
                         <div className="flex items-start gap-3 pt-2">
                             <Mail className="h-4 w-4 text-muted-foreground mt-1 flex-shrink-0" />
                               <div>
                                   <span className="font-medium">Contact:</span>
                                   <p>Available via the platform's secure messaging.</p>
                                    <Button variant="link" className="p-0 h-auto text-sm" asChild>
                                        <Link href={`/messages?recipient=${profile.id}`}>Send Message</Link>
                                    </Button>
                               </div>
                         </div>
                     </div>
                 </section>


             {/* Placeholder for Reviews/Ratings */}
              <section>
                 <h2 className="text-xl font-semibold mb-3 border-b pb-2">Client Reviews</h2>
                 <div className="text-center py-6 bg-muted/50 rounded-md">
                     <p className="text-muted-foreground text-sm">Client reviews and ratings will be displayed here soon.</p>
                      {/* Add review components later */}
                 </div>
             </section>
              {/* Placeholder for Portfolio/Case Studies */}
               <section>
                 <h2 className="text-xl font-semibold mb-3 border-b pb-2">Portfolio / Notable Cases</h2>
                 <div className="text-center py-6 bg-muted/50 rounded-md">
                     <p className="text-muted-foreground text-sm">Examples of work or case studies will be displayed here soon.</p>
                      {/* Add portfolio components later */}
                 </div>
             </section>

        </CardContent>
      </Card>
    </div>
  );
}
