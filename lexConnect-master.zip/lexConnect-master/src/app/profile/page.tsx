

"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { User, Mail, Phone, Briefcase, Award, Edit, ShieldCheck } from 'lucide-react'; // Added ShieldCheck
import useLocalStorage from '@/hooks/useLocalStorage';
import DashboardLayout from '@/components/layout/DashboardLayout'; // Import the DashboardLayout

type UserProfile = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
  firstName?: string; // Client
  lastName?: string; // Client
  fullName?: string; // Lawyer
  specialization?: string; // Lawyer
  barNumber?: string; // Lawyer
  isVerified?: boolean; // Lawyer
  bio?: string;
  location?: string;
  profilePicUrl?: string;
  phone?: string; // Optional phone
  // Add more fields like portfolio, ratings, availability calendar etc.
};

export default function ProfilePage() {
  const [currentUser, setCurrentUser] = useLocalStorage<UserProfile | null>('user', null);
  const router = useRouter();
  // Add state for editing mode if needed later
  // const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (!currentUser) {
      router.push('/login'); // Redirect if not logged in
    }
  }, [currentUser, router]);

  // Show loading state within the layout
  if (!currentUser) {
    return <DashboardLayout><div className="text-center py-12">Loading profile...</div></DashboardLayout>;
  }

  const displayName = currentUser.role === 'client'
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : currentUser.fullName;

  const initial = displayName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U';

  return (
    // Wrap the content with DashboardLayout
    <DashboardLayout>
        <div className="max-w-4xl mx-auto space-y-8"> {/* Added max-width and spacing */}
            <h1 className="text-3xl font-bold text-foreground">Profile Settings</h1> {/* Page Title */}

            <Card className="overflow-hidden">
                {/* Profile Header */}
                <div className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 p-8 relative">
                    <div className="flex flex-col md:flex-row items-center gap-6">
                        <Avatar className="h-24 w-24 md:h-32 md:w-32 border-4 border-background shadow-lg">
                            {/* Use picsum for placeholder */}
                            <AvatarImage src={currentUser.profilePicUrl || `https://picsum.photos/seed/${currentUser.id}/128/128`} alt={displayName || ''} data-ai-hint="person portrait professional"/>
                            <AvatarFallback className="text-4xl">{initial}</AvatarFallback>
                        </Avatar>
                        <div className="text-center md:text-left">
                            <h2 className="text-2xl md:text-3xl font-bold mb-1">{displayName}</h2>
                            <p className="text-lg text-muted-foreground capitalize">{currentUser.role}</p>
                            {currentUser.role === 'lawyer' && currentUser.specialization && (
                                <Badge variant="secondary" className="mt-2 text-sm"><Briefcase className="h-3 w-3 mr-1"/> {currentUser.specialization}</Badge>
                            )}
                            {currentUser.role === 'lawyer' && currentUser.isVerified && (
                                <Badge variant="default" className="mt-2 ml-2 text-sm bg-green-600 hover:bg-green-700">
                                    <ShieldCheck className="h-3 w-3 mr-1"/> Verified
                                </Badge>
                            )}
                        </div>
                        {/* Edit button might be better placed within specific sections */}
                        <Button variant="outline" className="mt-4 md:mt-0 md:ml-auto" onClick={() => alert('Edit functionality not yet implemented.')}>
                            <Edit className="h-4 w-4 mr-2" /> Edit Profile
                        </Button>
                    </div>
                </div>

                {/* Profile Details */}
                <CardContent className="p-6 md:p-8 space-y-8"> {/* Increased spacing */}
                    {/* About Section */}
                    <section>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-semibold">About</h3>
                             {/* <Button variant="ghost" size="sm" onClick={() => alert('Edit About section')}>Edit</Button> */}
                         </div>
                        <p className="text-muted-foreground">
                            {currentUser.bio || (currentUser.role === 'client' ? 'No bio provided.' : `Experienced ${currentUser.specialization || 'legal professional'}.`)}
                            {/* Add an edit textarea here when isEditing */}
                        </p>
                    </section>

                    {/* Contact Information */}
                    <section>
                         <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-semibold">Contact Information</h3>
                            {/* <Button variant="ghost" size="sm" onClick={() => alert('Edit Contact info')}>Edit</Button> */}
                         </div>
                        <div className="space-y-3 text-sm">
                            <div className="flex items-center gap-3">
                                <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                <span>{currentUser.email}</span>
                            </div>
                            {currentUser.phone && (
                                <div className="flex items-center gap-3">
                                    <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                    <span>{currentUser.phone}</span>
                                </div>
                            )}
                            {currentUser.location && (
                                <div className="flex items-center gap-3">
                                    <User className="h-4 w-4 text-muted-foreground flex-shrink-0" /> {/* Using User icon for location for now */}
                                    <span>{currentUser.location}</span>
                                </div>
                            )}
                             {!currentUser.phone && !currentUser.location && (
                                 <p className="text-muted-foreground text-xs">Complete your profile by adding phone and location.</p>
                             )}
                        </div>
                    </section>

                    {/* Lawyer Specific Details */}
                    {currentUser.role === 'lawyer' && (
                        <section>
                             <div className="flex justify-between items-center mb-4">
                                <h3 className="text-xl font-semibold">Credentials</h3>
                                {/* <Button variant="ghost" size="sm" onClick={() => alert('Edit Credentials')}>Edit</Button> */}
                            </div>
                            <div className="space-y-3 text-sm">
                                {currentUser.specialization && (
                                    <div className="flex items-center gap-3">
                                        <Briefcase className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                        <span>Specialization: <strong>{currentUser.specialization}</strong></span>
                                    </div>
                                )}
                                {currentUser.barNumber && (
                                    <div className="flex items-center gap-3">
                                        <Award className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                        <span>Bar Number: {currentUser.barNumber} {currentUser.isVerified ? <span className="text-green-600">(Verified)</span> : <span className="text-orange-500">(Verification Pending)</span>}</span>
                                    </div>
                                )}
                                {/* Add more credentials like Education, Certifications later */}
                            </div>
                        </section>
                    )}

                    {/* Placeholder for other sections like Case History (Client), Portfolio (Lawyer), Reviews */}
                    <section>
                         <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-semibold">{currentUser.role === 'client' ? 'Case History' : 'Portfolio & Reviews'}</h3>
                            {/* <Button variant="ghost" size="sm">View All</Button> */}
                         </div>
                        <p className="text-muted-foreground text-sm">This section will display relevant information soon.</p>
                        {/* Implement Case History / Portfolio / Reviews listing here */}
                    </section>

                     {/* Account Actions */}
                     <section>
                        <h3 className="text-xl font-semibold mb-4 text-destructive">Account Actions</h3>
                         <div className="space-y-3">
                            <Button variant="outline">Change Password</Button>
                             <Button variant="destructive">Delete Account</Button>
                             <p className="text-xs text-muted-foreground">Deleting your account is permanent and cannot be undone.</p>
                         </div>
                     </section>


                </CardContent>
            </Card>
        </div>
    </DashboardLayout>
  );
}
