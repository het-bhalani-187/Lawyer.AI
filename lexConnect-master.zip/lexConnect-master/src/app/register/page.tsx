

"use client";

import { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import Link from 'next/link';
import { User, Lock, Mail, Briefcase, Award, Building } from 'lucide-react'; // Added icons

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import useLocalStorage from '@/hooks/useLocalStorage'; // Import the hook
import { cn } from '@/lib/utils'; // Import cn utility

// Schemas
const baseSchema = z.object({
  email: z.string().email({ message: "Invalid email address." }),
  password: z.string().min(8, { message: "Password must be at least 8 characters." }),
  confirmPassword: z.string(),
  role: z.enum(["client", "lawyer"], { required_error: "You must select a role." }),
});

const clientSchema = baseSchema.extend({
  firstName: z.string().min(1, { message: "First name is required." }),
  lastName: z.string().min(1, { message: "Last name is required." }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"], // path of error
});


const lawyerSchema = baseSchema.extend({
  fullName: z.string().min(1, { message: "Full name is required." }),
  barNumber: z.string().min(1, { message: "Bar number is required." }),
  specialization: z.string().min(1, { message: "Specialization is required." }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});


type ClientFormData = z.infer<typeof clientSchema>;
type LawyerFormData = z.infer<typeof lawyerSchema>;


export default function RegisterPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  const [users, setUsers] = useLocalStorage<any[]>('users', []); // Use the hook for users
  const [currentUser, setCurrentUser] = useLocalStorage<any | null>('user', null);

  const initialRole = searchParams.get('role') === 'lawyer' ? 'lawyer' : 'client';
  const [role, setRole] = useState<'client' | 'lawyer'>(initialRole);

  const formSchema = role === 'client' ? clientSchema : lawyerSchema;
  const form = useForm<ClientFormData | LawyerFormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
      role: initialRole,
      firstName: "",
      lastName: "",
      fullName: "",
      barNumber: "",
      specialization: "",
    },
  });

  // Effect to reset form fields when role changes
  useEffect(() => {
    const currentValues = form.getValues();
    form.reset({
        email: currentValues.email || "",
        password: currentValues.password || "",
        confirmPassword: currentValues.confirmPassword || "",
        role: role,
        firstName: "",
        lastName: "",
        fullName: "",
        barNumber: "",
        specialization: "",
    });
  }, [role, form.reset, form]); // Added form to dependency array


  function onSubmit(values: ClientFormData | LawyerFormData) {
    console.log("Form submitted with values:", values);

     // Check if email already exists
    const existingUser = users.find(u => u.email === values.email);
    if (existingUser) {
      toast({
        title: "Registration Failed",
        description: "An account with this email already exists.",
        variant: "destructive",
      });
      form.setError("email", { type: "manual", message: "Email already in use." });
      return;
    }


    // Simple ID generation
     const newUser = {
         id: Date.now().toString(),
         ...values,
         confirmPassword: undefined, // Remove confirmPassword
         // Add lawyer specific defaults
         ...(values.role === 'lawyer' && { isVerified: false, profilePicUrl: '', bio: '', location: '' })
     };
    delete newUser.confirmPassword; // Explicitly remove


    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    setCurrentUser(newUser); // Log the new user in

    console.log("Updated users array:", updatedUsers);

    toast({
      title: "Registration Successful",
      description: `Welcome to LexConnect, ${role === 'client' ? (values as ClientFormData).firstName : (values as LawyerFormData).fullName}!`,
    });

    router.push('/dashboard'); // Redirect to dashboard
  }

  return (
    <div className={cn(
        "flex items-center justify-center min-h-screen p-4",
        "login-page-background" // Apply background class
    )}>
      <Card className={cn(
          "w-full max-w-md bg-black/70 backdrop-blur-lg shadow-2xl text-neutral-200 rounded-xl border border-neutral-800/50 overflow-hidden", // Use login card styling
          "login-card-glow" // Apply glow effect
      )}>
        <CardHeader className="text-center p-6 md:p-8">
          <CardTitle className="text-3xl font-bold text-neutral-100 tracking-tight mb-2">
              Create Account
          </CardTitle>
          <CardDescription className="text-neutral-400">
              Join LexConnect and find your legal match.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel className="text-neutral-300 font-semibold text-base">Register as a...</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={(value) => {
                          field.onChange(value);
                          setRole(value as 'client' | 'lawyer');
                        }}
                        defaultValue={field.value}
                        value={role}
                        className="grid grid-cols-2 gap-4" // Use grid layout for equal width
                      >
                        <FormItem className={cn(
                             "flex items-center space-x-3 space-y-0 p-3 border rounded-lg cursor-pointer transition-colors",
                             "bg-neutral-900/70 border-neutral-700/80 hover:border-teal-500/60",
                             field.value === 'client' ? 'border-teal-500 ring-2 ring-teal-500/50 bg-teal-900/30' : ''
                        )}>
                          <FormControl>
                             <RadioGroupItem value="client" id="clientRole" className="border-neutral-600 text-teal-500 data-[state=checked]:border-teal-500"/>
                          </FormControl>
                           <FormLabel htmlFor="clientRole" className="font-normal text-neutral-300 cursor-pointer select-none text-sm">
                             Client
                           </FormLabel>
                        </FormItem>
                        <FormItem className={cn(
                             "flex items-center space-x-3 space-y-0 p-3 border rounded-lg cursor-pointer transition-colors",
                             "bg-neutral-900/70 border-neutral-700/80 hover:border-teal-500/60",
                             field.value === 'lawyer' ? 'border-teal-500 ring-2 ring-teal-500/50 bg-teal-900/30' : ''
                        )}>
                          <FormControl>
                             <RadioGroupItem value="lawyer" id="lawyerRole" className="border-neutral-600 text-teal-500 data-[state=checked]:border-teal-500"/>
                          </FormControl>
                          <FormLabel htmlFor="lawyerRole" className="font-normal text-neutral-300 cursor-pointer select-none text-sm">
                            Lawyer
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage className="text-red-400 text-xs" />
                  </FormItem>
                )}
              />

              {/* Common Fields - Styled like login */}
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                   <FormItem className="relative">
                     <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                    <FormControl>
                      <Input
                         type="email"
                         placeholder="Email Address"
                         {...field}
                         className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                    </FormControl>
                    <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem className="relative">
                     <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                    <FormControl>
                      <Input
                         type="password"
                         placeholder="Password"
                         {...field}
                         className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                    </FormControl>
                    <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                    <FormControl>
                      <Input
                         type="password"
                         placeholder="Confirm Password"
                         {...field}
                         className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                    </FormControl>
                    <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                  </FormItem>
                )}
              />


              {/* Client Specific Fields */}
              {role === 'client' && (
                <>
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem className="relative">
                         <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                        <FormControl>
                          <Input
                             placeholder="First Name"
                             {...field}
                             className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                        </FormControl>
                        <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                       <FormItem className="relative">
                         <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                        <FormControl>
                          <Input
                             placeholder="Last Name"
                             {...field}
                             className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                        </FormControl>
                        <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                      </FormItem>
                    )}
                  />
                </>
              )}

              {/* Lawyer Specific Fields */}
              {role === 'lawyer' && (
                <>
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                       <FormItem className="relative">
                          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                        <FormControl>
                          <Input
                             placeholder="Full Name (e.g., Dr. Jane Smith, Esq.)"
                             {...field}
                             className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                        </FormControl>
                        <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="barNumber"
                    render={({ field }) => (
                       <FormItem className="relative">
                          <Award className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                        <FormControl>
                          <Input
                             placeholder="Bar Number"
                             {...field}
                             className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                        </FormControl>
                        <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name="specialization"
                    render={({ field }) => (
                      <FormItem className="relative">
                        <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-500" />
                        <FormControl>
                          <Input
                             placeholder="Primary Specialization (e.g., Family Law)"
                             {...field}
                             className="pl-10 bg-neutral-900/70 border-neutral-700/80 placeholder-neutral-500 text-neutral-200 focus:ring-primary/60 focus:border-primary/60 rounded-lg h-11 text-base" />
                        </FormControl>
                        <FormMessage className="text-red-400 text-xs pt-1 pl-2"/>
                      </FormItem>
                    )}
                  />
                </>
              )}

              {/* Submit Button */}
              <Button
                 type="submit"
                 className="w-full !mt-8 bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 rounded-lg text-base transition-all duration-300 transform hover:scale-[1.02]"
                 size="lg"
                 disabled={form.formState.isSubmitting}
                >
                {form.formState.isSubmitting ? 'Registering...' : 'Create Account'}
              </Button>

              {/* Link to Login */}
               <div className="text-center text-sm text-neutral-400 pt-4">
                    Already have an account?{' '}
                    <Button variant="link" asChild className="p-0 h-auto font-semibold text-teal-400 hover:text-teal-300 hover:underline text-sm">
                        <Link href="/login">
                            Login here
                        </Link>
                    </Button>
                </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

