
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function TermsOfServicePage() {
  return (
    <div className="container mx-auto max-w-3xl py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Terms of Service</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-muted-foreground">
           <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

           <p>Please read these Terms of Service ("Terms") carefully before using the LexConnect platform ("Platform") operated by us ("LexConnect", "we", "us", or "our"). Your access to and use of the Platform is conditioned upon your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who wish to access or use the Platform.</p>

            <h2 className="font-semibold text-lg pt-4 text-foreground">1. Acceptance of Terms</h2>
            <p>By accessing or using the Platform, you agree to be bound by these Terms. If you disagree with any part of the terms, then you do not have permission to access the Platform.</p>

             <h2 className="font-semibold text-lg pt-4 text-foreground">2. Platform Service</h2>
             <p>LexConnect provides a platform to connect individuals seeking legal services ("Clients") with independent legal professionals ("Lawyers"). LexConnect is not a law firm, does not provide legal advice, and does not create an attorney-client relationship between users or between any user and LexConnect.</p>
             <p>Any attorney-client relationship formed is strictly between the Client and the Lawyer. LexConnect is not a party to any agreement between Clients and Lawyers.</p>

             <h2 className="font-semibold text-lg pt-4 text-foreground">3. User Accounts</h2>
            <p>You must register for an account to access certain features. You agree to provide accurate, current, and complete information during registration and to update such information to keep it accurate. You are responsible for safeguarding your password and for all activities that occur under your account.</p>


            <h2 className="font-semibold text-lg pt-4 text-foreground">4. User Conduct</h2>
            <p>You agree not to use the Platform to:</p>
             <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Violate any applicable laws or regulations.</li>
                <li>Infringe upon the rights of others, including intellectual property rights.</li>
                 <li>Transmit any harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, or otherwise objectionable material.</li>
                <li>Impersonate any person or entity or misrepresent your affiliation.</li>
                <li>Engage in unauthorized advertising or solicitation.</li>
            </ul>
            <p>Lawyers agree to maintain the highest professional and ethical standards in accordance with their jurisdictional bar requirements.</p>

             <h2 className="font-semibold text-lg pt-4 text-foreground">5. Disclaimers</h2>
            <p>The Platform is provided on an "AS IS" and "AS AVAILABLE" basis. LexConnect makes no warranties, express or implied, regarding the Platform, including the suitability, reliability, availability, timeliness, or accuracy of the information or services provided. We do not guarantee any specific results from the use of the Platform.</p>
             <p>LexConnect does not endorse and is not responsible for the advice, acts, or omissions of any user (Client or Lawyer).</p>

             <h2 className="font-semibold text-lg pt-4 text-foreground">6. Limitation of Liability</h2>
             <p>In no event shall LexConnect, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Platform; any conduct or content of any third party on the Platform; or unauthorized access, use, or alteration of your transmissions or content.</p>

              {/* Placeholder using localStorage */}
            <p className="text-orange-500 font-medium mt-2">Note: This is a demonstration application using browser localStorage for data persistence. It is not intended for real-world use with sensitive data. We are not liable for any data loss or security issues arising from this demonstration setup.</p>


            <h2 className="font-semibold text-lg pt-4 text-foreground">7. Modifications</h2>
            <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms on this page.</p>

             <h2 className="font-semibold text-lg pt-4 text-foreground">8. Governing Law</h2>
            <p>These Terms shall be governed and construed in accordance with the laws of [Your Jurisdiction - Placeholder], without regard to its conflict of law provisions.</p>

            <h2 className="font-semibold text-lg pt-4 text-foreground">9. Contact Us</h2>
             <p>If you have any questions about these Terms, please contact us at [Placeholder Contact Email/Link].</p>
        </CardContent>
      </Card>
    </div>
  );
}
