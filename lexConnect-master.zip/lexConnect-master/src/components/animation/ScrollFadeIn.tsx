
"use client";

import { useRef, useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { cn } from '@/lib/utils';

interface ScrollFadeInProps {
  children: React.ReactNode;
  className?: string;
  delay?: number; // Optional delay in ms
  threshold?: number; // Optional threshold for intersection observer
}

const ScrollFadeIn: React.FC<ScrollFadeInProps> = ({
  children,
  className,
  delay = 0,
  threshold = 0.1, // Trigger when 10% of the element is visible
}) => {
  const { ref, inView } = useInView({
    triggerOnce: true, // Only trigger once
    threshold: threshold,
  });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // This effect ensures the component doesn't animate server-side
    setIsVisible(false); // Start invisible on client mount
  }, []);


  useEffect(() => {
    if (inView) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, delay);
      return () => clearTimeout(timer);
    }
  }, [inView, delay]);

  return (
    <div
      ref={ref}
      className={cn(
        'scroll-fade-in', // Initial state class
        isVisible && 'is-visible', // Active state class
        className
      )}
    >
      {children}
    </div>
  );
};

export default ScrollFadeIn;
