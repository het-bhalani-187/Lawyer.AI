
"use client";

import type { ReactNode } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarTrigger,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarMenuSkeleton
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  LayoutDashboard,
  Briefcase,
  Search,
  MessageSquare,
  User,
  LogOut,
  PlusCircle,
  Settings,
  Bell,
  FileText,
} from 'lucide-react';
import useLocalStorage from '@/hooks/useLocalStorage';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

type User = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
  firstName?: string;
  lastName?: string;
  fullName?: string;
  profilePicUrl?: string;
};

interface DashboardLayoutProps {
  children: ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [currentUser, setCurrentUser] = useLocalStorage<User | null>('user', null);
  const [isClientMounted, setIsClientMounted] = useState(false);
  const pathname = usePathname();
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    setIsClientMounted(true);
  }, []);


  const handleLogout = () => {
    setCurrentUser(null);
    toast({ title: "Logged Out", description: "You have been successfully logged out."});
    router.push('/');
  };

  const sidebarNavItems = [
    { href: '/dashboard', label: 'Overview', icon: LayoutDashboard, roles: ['client', 'lawyer'] },
    { href: '/messages', label: 'Messages', icon: MessageSquare, roles: ['client', 'lawyer'] },
    { href: '/profile', label: 'Profile Settings', icon: Settings, roles: ['client', 'lawyer'] },
    { href: '/my-case', label: 'My Cases', icon: FileText, roles: ['client'] },
    { href: '/post-case', label: 'Post New Case', icon: PlusCircle, roles: ['client'] },
    { href: '/find-lawyer', label: 'Find a Lawyer', icon: Search, roles: ['client'] },
    { href: '/browse-cases', label: 'Browse Cases', icon: Search, roles: ['lawyer'] },
  ];

   const getVisibleNavItems = () => {
     const currentRole = (isClientMounted && currentUser?.role) ? currentUser.role : 'guest';
     if (currentRole === 'guest') return [];
     return sidebarNavItems.filter(item => item.roles.includes(currentRole));
   };

    const displayName = isClientMounted && currentUser
        ? (currentUser.role === 'client' ? `${currentUser.firstName} ${currentUser.lastName}` : currentUser.fullName ?? 'User')
        : ''; // Use empty string before mount

    const initial = isClientMounted && currentUser
        ? (displayName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U')
        : '';

  return (
    <SidebarProvider defaultOpen={true} collapsible="icon">
      <Sidebar className="border-r border-border/40 pt-16"> {/* Keep padding-top */}
         {/* Updated className to flex-row */}
        <SidebarHeader className="flex flex-row p-4 items-center gap-3">
          <Avatar className="h-10 w-10 border rounded-md flex-shrink-0"> {/* Added flex-shrink-0 */}
             {isClientMounted && (
                <AvatarImage src={currentUser?.profilePicUrl || `https://picsum.photos/seed/${currentUser?.id}/40/40`} alt={displayName} data-ai-hint="person profile"/>
             )}
             <AvatarFallback>{initial || 'U'}</AvatarFallback> {/* Provide default fallback */}
           </Avatar>
           <div className="flex flex-col group-data-[collapsible=icon]:hidden overflow-hidden flex-grow"> {/* Added flex-grow and overflow */}
               <span className="font-semibold text-sm truncate">{displayName || 'Loading...'}</span> {/* Placeholder, truncate */}
               {isClientMounted && currentUser && (
                 <span className="text-xs text-muted-foreground capitalize">{currentUser.role}</span>
               )}
           </div>
          <SidebarTrigger className="ml-auto group-data-[collapsible=icon]:hidden flex-shrink-0" /> {/* Added flex-shrink-0 */}
        </SidebarHeader>

        <SidebarContent className="p-2">
          <SidebarMenu>
            {isClientMounted ? getVisibleNavItems().map((item) => (
              <SidebarMenuItem key={item.href}>
                 <SidebarMenuButton
                    asChild
                    isActive={pathname === item.href}
                    tooltip={item.label}
                  >
                   {/* Use Link directly */}
                    <Link href={item.href}>
                      <item.icon />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
              </SidebarMenuItem>
            )) : (
                <>
                    <SidebarMenuItem><SidebarMenuSkeleton showIcon={true} /></SidebarMenuItem>
                    <SidebarMenuItem><SidebarMenuSkeleton showIcon={true} /></SidebarMenuItem>
                    <SidebarMenuItem><SidebarMenuSkeleton showIcon={true} /></SidebarMenuItem>
                </>
            )}
          </SidebarMenu>
        </SidebarContent>

        <SidebarFooter className="p-2 border-t border-border/40">
           <SidebarMenu>
              <SidebarMenuItem>
                 <SidebarMenuButton onClick={handleLogout} tooltip="Logout" disabled={!isClientMounted}>
                    <LogOut />
                    <span>Logout</span>
                  </SidebarMenuButton>
              </SidebarMenuItem>
           </SidebarMenu>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="pt-16"> {/* Adjusted padding */}
         <div className="overflow-y-auto h-full p-4 md:p-6 lg:p-8"> {/* Added wrapper for scrolling */}
           {children}
         </div>
       </SidebarInset>

    </SidebarProvider>
  );
}
