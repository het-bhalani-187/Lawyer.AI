
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="border-t border-border/40 bg-background">
      <div className="container mx-auto px-4 py-6 flex flex-col sm:flex-row justify-between items-center text-sm text-muted-foreground">
        <p>&copy; {new Date().getFullYear()} LexConnect. All rights reserved.</p>
        <nav className="flex gap-4 mt-4 sm:mt-0">
          <Link href="/privacy" className="hover:text-primary">Privacy Policy</Link>
          <Link href="/terms" className="hover:text-primary">Terms of Service</Link>
           <Link href="/contact" className="hover:text-primary">Contact Us</Link>
        </nav>
      </div>
    </footer>
  );
}
