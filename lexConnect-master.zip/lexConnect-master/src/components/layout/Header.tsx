
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'; // Added SheetTitle
import { Menu, Briefcase, Search, MessageSquare, UserPlus, LogIn, User, LayoutDashboard, FileText, Settings } from 'lucide-react'; // Added FileText, Settings
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import useLocalStorage from '@/hooks/useLocalStorage';
import { cn } from '@/lib/utils'; // Import cn

type User = {
  id: string;
  email: string;
  role: 'lawyer' | 'client';
};

export default function Header() {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useLocalStorage<User | null>('user', null);
  const [isMounted, setIsMounted] = useState(false); // State to track client mount
  const router = useRouter(); // Initialize useRouter

  // Set mounted state after initial render
  useEffect(() => {
    setIsMounted(true);
  }, []);


  const handleLogout = () => {
    setUser(null); // Clear user from localStorage and state
    router.push('/'); // Redirect to home page
    setMobileMenuOpen(false); // Close mobile menu if open
  };

  // Define nav items structure - consolidated profile settings link
   const navItems = [
    // Common
    { href: '/dashboard', label: 'Overview', icon: LayoutDashboard, roles: ['client', 'lawyer'] },
    { href: '/messages', label: 'Messages', icon: MessageSquare, roles: ['client', 'lawyer'] },
     { href: '/profile', label: 'Profile Settings', icon: Settings, roles: ['client', 'lawyer'] }, // Common settings link
    // Client Specific
    { href: '/my-case', label: 'My Cases', icon: FileText, roles: ['client'] },
    { href: '/post-case', label: 'Post New Case', icon: Briefcase, roles: ['client'] },
    { href: '/find-lawyer', label: 'Find a Lawyer', icon: Search, roles: ['client'] },
    // Lawyer Specific
    { href: '/browse-cases', label: 'Browse Cases', icon: Search, roles: ['lawyer'] },
    // Guest-only visible items (only shown if not logged in)
    { href: '/find-lawyer', label: 'Find a Lawyer', icon: Search, roles: ['guest'] },
  ];

  // Function to get visible nav items based on role and mount status
   const getVisibleNavItems = () => {
     // Default to guest items until hydration is complete AND user is known
     const currentRole = (isMounted && user) ? user.role : 'guest';
     return navItems.filter(item => item.roles.includes(currentRole));
   };

   // Separate function for Auth Buttons to handle mount state
   const AuthButtons = () => {
     if (!isMounted) {
       // Render placeholder or guest buttons before mount
       return (
         <div className="flex items-center gap-2"> {/* Wrap in div to prevent layout shift */}
            <Button variant="ghost" size="sm" disabled>
                <LogIn className="mr-2 h-4 w-4" /> Login
            </Button>
            <Button size="sm" disabled>
                <UserPlus className="mr-2 h-4 w-4" /> Register
            </Button>
         </div>
       );
     }

     // Render actual buttons after mount
     return user ? (
       <>
         {/* Profile link removed from here, added to main nav */}
         <Button variant="outline" size="sm" onClick={handleLogout}>Logout</Button>
       </>
     ) : (
       <>
         <Button variant="ghost" size="sm" asChild>
           <Link href="/login"><LogIn className="mr-2 h-4 w-4" /> Login</Link>
         </Button>
         <Button size="sm" asChild>
           <Link href="/register"><UserPlus className="mr-2 h-4 w-4" /> Register</Link>
         </Button>
       </>
     );
   };

    // Auth buttons for mobile menu
    const MobileAuthButtons = () => {
        if (!isMounted) {
            // Render placeholders
            return (
                <div className="flex flex-col gap-2">
                    <Button variant="ghost" className="w-full justify-start" disabled>
                        <LogIn className="mr-2 h-4 w-4" /> Login
                    </Button>
                    <Button className="w-full justify-start" disabled>
                        <UserPlus className="mr-2 h-4 w-4" /> Register
                    </Button>
                </div>
            );
        }
        return user ? (
             <Button variant="outline" className="w-full" onClick={handleLogout}>Logout</Button>
         ) : (
             <div className="flex flex-col gap-2">
                 <Button variant="ghost" className="w-full justify-start" asChild onClick={() => setMobileMenuOpen(false)}>
                     <Link href="/login"><LogIn className="mr-2 h-4 w-4" /> Login</Link>
                 </Button>
                 <Button className="w-full justify-start" asChild onClick={() => setMobileMenuOpen(false)}>
                     <Link href="/register"><UserPlus className="mr-2 h-4 w-4" /> Register</Link>
                 </Button>
             </div>
         );
    };


  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between">
        <Link href="/" className="mr-6 flex items-center space-x-2">
          <Briefcase className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg sm:inline-block">
            LexConnect
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex flex-grow items-center justify-end gap-6"> {/* Changed nav to div, added flex-grow and justify-end */}
          <nav className="flex gap-6 items-center"> {/* Added inner nav */}
             {getVisibleNavItems().map((item) => (
                <Link
                key={item.href}
                href={item.href}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary" // Removed flex stuff, simplified
                >
                 {item.label}
                </Link>
             ))}
          </nav>
           <AuthButtons /> {/* Use the component here */}
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden">
          <Sheet open={isMobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full max-w-xs sm:max-w-sm flex flex-col"> {/* Added flex flex-col */}
             {/* Add a visually hidden title for accessibility */}
              <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
              <div className="border-b pb-4 mb-4">
                 <Link href="/" className="flex items-center space-x-2" onClick={() => setMobileMenuOpen(false)}>
                    <Briefcase className="h-6 w-6 text-primary" />
                    <span className="font-bold text-lg">LexConnect</span>
                </Link>
              </div>
              <nav className="flex-grow flex flex-col gap-4"> {/* Kept flex-grow */}
                {getVisibleNavItems().map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn( // Use cn for potential future conditional classes
                        "flex items-center gap-3 rounded-md p-2 text-muted-foreground hover:text-primary hover:bg-accent"
                    )}
                     onClick={() => setMobileMenuOpen(false)}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.label}
                  </Link>
                ))}
                 {/* Profile link moved to navItems */}
              </nav>
              <div className="mt-auto border-t pt-4"> {/* Kept mt-auto */}
                  <MobileAuthButtons /> {/* Use the component here */}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
